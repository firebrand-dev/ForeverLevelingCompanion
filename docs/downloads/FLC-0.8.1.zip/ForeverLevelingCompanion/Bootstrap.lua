-- Bootstrap: client events -> engines, the throttled ticker, and slash commands.
-- Every client entry point is wrapped in Diag:Guard so one failure cannot break the rest.
local ADDON_NAME, ns = ...
local L = ns.L
local API = ns.API

local Boot = { dirty = true, lastRefresh = -1, lastFlush = -1, lastSlow = -1, lastArrow = -1 }
ns.Boot = Boot

local frame = CreateFrame("Frame", "FLC_EventFrame")
ns.clock = function() return GetTime() end

----------------------------------------------------------------------
-- Refresh of the local character / roster (logic lives in Engine/Sync.lua)
----------------------------------------------------------------------
function Boot:RefreshSelf(now)
  ns.Sync:RefreshSelf(now)
  self.dirty = false
  self.lastRefresh = now
  ns.UI:Refresh()
end

function Boot:RefreshRoster()
  ns.Sync:RefreshRoster(ns.Now())
end

----------------------------------------------------------------------
-- Notices -> UI
----------------------------------------------------------------------
local NOTICES = {
  ["target-offline"] = "%s disconnected. Your progress is saved",
  ["target-online"] = "%s is back online. Recalculate the route from the Party panel",
  ["target-left"] = "%s left the group. Your progress is saved",
  ["target-back"] = "%s rejoined the group",
  ["target-declined"] = "%s does not share quest data; help is limited to manual steps",
  ["help-finished"] = "%s no longer needs help. Return to your guide when ready",
  ["leader-changed"] = "The group leader changed; the current group route stays until you end it",
}
ns.Bus:On("SESSION_NOTICE", Boot, function(kind, arg)
  local text = NOTICES[kind]
  if text then
    local msg = string.format(L[text], ns.U.shortName(arg))
    ns.UI:Toast(msg)
    API.Print(msg)
  end
end)
ns.Bus:On("HELP_REQUESTED", Boot, function(m)
  ns.UI:Toast(string.format(L["%s asks for help"], m.name))
end)
ns.Bus:On("HELP_NOTICE", Boot, function(m, action)
  if action == "start" then ns.UI:Toast(string.format(L["%s is helping you"], m.name)) end
end)
ns.Bus:On("ROUTE_PROPOSED", Boot, function(p)
  -- in chat too, and on screen for as long as the proposal can be answered (it expires after 120 s)
  local msg = string.format(L["%s proposes a group route: open the Party panel to answer"], ns.U.shortName(p.from))
  ns.UI:Toast(msg, math.max(8, (p.expires or 0) - (p.at or 0)))
  API.Print(msg .. " (/flc party)")
end)

----------------------------------------------------------------------
-- Client events
----------------------------------------------------------------------
local handlers = {}

function handlers.ADDON_LOADED(name)
  if name ~= ADDON_NAME then return end
  local account, char = ns.Config:Load(FLC_DB, FLC_CharDB)
  FLC_DB, FLC_CharDB = account, char
  local loc = account.settings.locale
  ns:SetLocale(loc == "auto" and API.GetLocale() or loc)
  API.Probe()
  ns.Protocol.NewSession((time and time() or 0) + math.floor(GetTime() * 1000))
  API.RegisterPrefix(ns.Protocol.prefix)
  ns.Diag:Info("boot", "loaded " .. ns.version)
  local runner = API.TestRunner()
  if runner then ns.Diag:Guard("testrunner", runner.Attach, ns) end
  frame:UnregisterEvent("ADDON_LOADED")
end

function handlers.PLAYER_LOGIN()
  ns.selfKey = API.UnitKey("player")
  ns.Session:Init(ns.Config.char)
  ns.Travel:Attach(ns.Config.char.travel)
  ns.Travel.farYards = ns.Config:Get("nav.travelYards") or ns.Travel.farYards
  ns.Travel:CheckBind(API.GetBindLocation())
  Boot:RefreshSelf(GetTime())
  Boot:RefreshRoster()
  ns.UI:Build()
  if #ns.Config.repairs > 0 then API.Print(L["Saved data was repaired; see /flc diag"]) end
  for _, r in ipairs(ns.Packs.rejected) do
    API.Print(string.format(L["Guide pack %s was not loaded: %s"], r.id, r.reason))
  end
  if #ns.Packs.order == 0 and not ns.Config:Get("notices.noPack") then
    -- once: the addon works with its sample guides; the catalog pack adds routes for most zones
    API.Print(L["Only the sample guides are installed. Install FLC_Guides_Catalog (same download) for routes in most zones."])
    ns.Config:Set("notices.noPack", true)
  end
  ns.Updates:Login()
  if not ns.Config:Get("notices.questFlow") then
    -- once: what 0.8.1 does by itself, and how to stop it
    API.Print(L["FLC accepts and turns in the guide's quests by itself (hold Shift to do it yourself; /flc auto off turns it off). "
      .. "On a reward choice it only marks its recommendation."])
    ns.Config:Set("notices.questFlow", true)
  end
  if API.caps.questie and not ns.Config:Get("notices.questie") then
    API.Print(L["Questie detected: keep only one quest announcer enabled to avoid duplicate party messages"])
    ns.Config:Set("notices.questie", true)
  end
end

function handlers.PLAYER_ENTERING_WORLD()
  Boot.dirty = true
  Boot:RefreshRoster()
  API.CalibrateWorld()
  ns.UI:SetupOnWorld()   -- the welcome setup, on a new install only (UI/SetupFrame.lua)
  ns.UI:MinimapSoon()     -- the minimap button's free place, once other addons made their buttons
end

function handlers.QUEST_LOG_UPDATE() Boot.dirty = true end
function handlers.QUEST_REMOVED() Boot.dirty = true end
function handlers.QUEST_WATCH_UPDATE() Boot.dirty = true end
function handlers.UNIT_QUEST_LOG_CHANGED(unit)
  if unit == "player" then Boot.dirty = true end
end

-- Mainline: (questID). Classic Era: (questLogIndex, questID).
function handlers.QUEST_ACCEPTED(a, b)
  local qid = b or a
  Boot.dirty = true
  local st = ns.Session.selfState
  local q = st and st.log[qid]
  ns.Recorder:OnAccepted(qid, q and q.title, q and q.level)
end

-- NPC windows: the data recorder remembers whose window it was (the quest can be accepted after it closed)
-- then the quest flow accepts and turns in the guide's quests by itself (Engine/QuestFlow.lua)
function handlers.GOSSIP_SHOW() ns.Recorder:OnNpcWindow(); ns.QuestFlow:OnNpc("gossip", GetTime()) end
function handlers.QUEST_GREETING() ns.Recorder:OnNpcWindow(); ns.QuestFlow:OnNpc("greeting", GetTime()) end
function handlers.QUEST_DETAIL() ns.Recorder:OnNpcWindow(); ns.QuestFlow:OnDetail() end
function handlers.QUEST_PROGRESS() ns.Recorder:OnNpcWindow(); ns.QuestFlow:OnProgress() end
function handlers.QUEST_COMPLETE() ns.QuestFlow:OnComplete() end
function handlers.QUEST_FINISHED() ns.QuestFlow:OnClosed() end

function handlers.QUEST_TURNED_IN(qid, xp, money)
  if type(qid) ~= "number" then return end
  ns.Sync:OnQuestTurnedIn(qid, GetTime())
  ns.Recorder:OnReward(qid, xp, money)
  Boot.dirty = true
end

function handlers.PLAYER_LEVEL_UP(level)
  ns.Sync:OnLevelUp(level)
  ns.UI.advisorRead = nil   -- the advisor reads the character again
  Boot.dirty = true
end

function handlers.PLAYER_EQUIPMENT_CHANGED()
  ns.UI.advisorRead = nil
  Boot.dirty = true
end

function handlers.GROUP_ROSTER_UPDATE() Boot:RefreshRoster(); ns.UI:Refresh() end
function handlers.UNIT_CONNECTION() Boot:RefreshRoster(); ns.UI:Refresh() end
function handlers.PARTY_LEADER_CHANGED() Boot:RefreshRoster(); ns.UI:Refresh() end

function handlers.CHAT_MSG_ADDON(prefix, text, channel, sender)
  if prefix ~= ns.Protocol.prefix then return end
  if API.IsSecret(sender) or API.IsSecret(text) then return end
  sender = API.SenderKey(sender)
  if not sender or sender == ns.selfKey then return end
  ns.Protocol:Receive(sender, text, GetTime())
end

-- The flight map is the only place the client tells which flight masters the character knows.
function handlers.TAXIMAP_OPENED()
  local nodes = API.GetTaxiNodes()
  if ns.Travel:LearnTaxiNodes(nodes, API.GetPlayerWorldPosition()) > 0 then ns.UI:Refresh() end
end

function handlers.HEARTHSTONE_BOUND()
  ns.Travel:SetBind(API.GetBindLocation(), API.GetPlayerWorldPosition())
  ns.UI:Refresh()
end

-- a dungeon guide's boss step is done when the game reports the encounter won (Engine/DungeonGuide.lua)
-- the Boss Guide's card follows the fight (Engine/BossGuide.lua)
function handlers.ENCOUNTER_START(encounterID)
  ns.BossGuide:OnEncounterStart(encounterID)
  ns.UI:Refresh()
end

function handlers.ENCOUNTER_END(encounterID, _, _, _, success)
  ns.BossGuide:OnEncounterEnd(encounterID)
  ns.DungeonGuide:OnEncounterEnd(encounterID, success)
  Boot.dirty = true
  ns.UI:Refresh()
end

function handlers.BOSS_KILL(encounterID)
  ns.BossGuide:OnEncounterEnd(encounterID)
  ns.DungeonGuide:OnEncounterEnd(encounterID, true)
  Boot.dirty = true
  ns.UI:Refresh()
end

-- an item the Loot Atlas asked the client for: its name in the player's language, at the next slow tick
function handlers.GET_ITEM_INFO_RECEIVED() ns.UI.atlasNames = true; ns.QuestFlow:OnItemInfo() end

function handlers.PLAYER_REGEN_DISABLED() ns.UI:SetCombat(true) end
function handlers.PLAYER_REGEN_ENABLED()
  ns.UI:SetCombat(false)
  if ns.UI.blizzardPending then ns.UI:ApplyBlizzardTracker() end
end

Boot.handlers = handlers

frame:SetScript("OnEvent", function(_, event, ...)
  local h = handlers[event]
  if h then ns.Diag:Guard("event:" .. event, h, ...) end
end)
-- An event this client does not know must not stop the others from registering.
for event in pairs(handlers) do
  local ok = pcall(frame.RegisterEvent, frame, event)
  if not ok then ns.Diag:Warn("boot", "event not available: " .. event) end
end

----------------------------------------------------------------------
-- Ticker
----------------------------------------------------------------------
local function tick()
  local now = GetTime()
  if not ns.UI.built then return end
  if ns.Tracker:NeedsRecheck(now) then Boot.dirty = true end
  if Boot.dirty and now - Boot.lastRefresh > 0.2 then Boot:RefreshSelf(now) end
  ns.Tracker:Tick(now)
  if now - Boot.lastFlush >= 0.25 then
    Boot.lastFlush = now
    ns.Protocol:Flush(now)
    ns.Announcer:Flush(now)
  end
  if now - Boot.lastSlow >= 1 then
    Boot.lastSlow = now
    ns.Party:Tick(now)
    local a = ns.Session:Active()
    local where = ns.UI.playerWorld or ns.UI.playerPos
    if a.guide and where then
      if ns.Guide:CheckArrival(a.guide, a.track, where, ns.Config:Get("nav.arrivalYards")) then ns.UI.dirty = true end
    end
    if ns.DungeonGuide:CheckInside(API.GetInstanceMapID()) then ns.UI.dirty = true end
    if ns.UI.dirty then
      ns.UI.dirty = false
      ns.UI:Refresh()
    end
    if ns.UI.atlasNames then
      ns.UI.atlasNames = false
      ns.UI:RefreshLootAtlas()
    end
    ns.UI:TickToast(now)
    ns.UI:TickMinimap(now)
  end
  if now - Boot.lastArrow >= 0.05 then
    Boot.lastArrow = now
    ns.UI:UpdateArrow()
  end
end

frame:SetScript("OnUpdate", function()
  ns.Diag:Guard("ticker", tick)
end)

----------------------------------------------------------------------
-- Slash commands
----------------------------------------------------------------------
local function findMember(name)
  name = string.lower(name or "")
  for _, m in ipairs(ns.Party:List()) do
    if string.lower(m.name) == name or string.lower(m.key) == name then return m end
  end
end

local function usage()
  for _, line in ipairs({
    "/flc - toggle the guide window",
    "/flc party | tracker | options | diag",
    "/flc help <name> - help a party member   /flc return - back to your guide",
    "/flc together | catchup | dungeon - group modes",
    "/flc next | prev | skip | resume",
    "/flc guide [auto | <id>] - show, re-pick from where you stand, or choose the guide",
    "/flc guides - the Guides window: choose the route, dungeon or raid guide to follow",
    "/flc minimap [show | hide] - FLC's minimap button: click for FLC, right click for its windows",
    "/flc path - the leveling path 1-60 for your race",
    "/flc mode [quests | optimized | dungeons] - leveling mode (your progress is kept)",
    "/flc boss [basic | detailed | off] - the boss card of dungeon guides",
    "/flc upgrades [dungeon id] - dungeon items better than yours (estimate)",
    "/flc atlas [text] - the Loot Atlas: dungeon loot by dungeon, boss or for you, with your wishlist",
    "/flc lootweights stat=weight, ... | reset - your own stat priorities for the upgrades",
    "/flc advisor - class quests and important rewards for your character",
    "/flc appearance - adapt FLC's look to your interface",
    "/flc setup - the welcome setup: adapt FLC's look, configure it or keep it",
    "/flc version - the installed version and where to download a newer one",
    "/flc auto [guide | all | off] - accept and turn in quests by themselves (Shift: do it yourself)",
    "/flc announce off|objectives|pct25|pct50|every|default",
    "/flc review - what you see now, to tell us when the game shows something else",
    "/flc bug - the same report with FLC's latest errors, to tell us about one",
    "/flc share yes|no   /flc record on|off|export   /flc reset ui",
  }) do API.Print(L[line]) end
end

local commands = {}
commands[""] = function() ns.UI:TogglePanel("main") end
commands.show = function() ns.UI.main:Show() end
commands.hide = function() ns.UI.main:Hide() end
commands.party = function() ns.UI:TogglePanel("party") end
commands.tracker = function() ns.UI:TogglePanel("tracker") end
commands.options = function() ns.UI:TogglePanel("options") end
commands.diag = function() ns.UI:ShowReport(ns.Diag:BuildReport(ns.UI:StateLines())) end
-- /flc review: the step on screen (and its abilities in review) as text to copy and send to FLC's authors
commands.review = function() ns.UI:ShowReport(ns.UI:ReviewReport()) end
commands.bug = commands.review
commands.setup = function() ns.UI:ShowSetup() end
commands.version = function() for _, line in ipairs(ns.Updates:Lines()) do API.Print(line) end end
commands.auto = function(arg)
  if arg and arg ~= "" and not ns.QuestFlow:SetMode(arg) then return API.Print(L["/flc auto [guide | all | off] - accept and turn in quests by themselves (Shift: do it yourself)"]) end
  API.Print(L[ns.UI.QUEST_FLOW_LABELS[ns.QuestFlow:Mode()]])
  ns.UI:Refresh()
end
commands.help = function(arg)
  if not arg or arg == "" then return usage() end
  local m = findMember(arg)
  if not m then return API.Print(string.format(L["%s is not in your party"], arg)) end
  ns.UI:HelpMember(m.key)
end
commands["return"] = function() ns.UI:ReturnToGuide() end
commands.together = function() ns.UI:StartGroup("together") end
commands.catchup = function() ns.UI:StartGroup("catchup") end
commands.dungeon = function() ns.UI:ShowDungeons(); ns.UI.party:Show(); ns.UI:Refresh() end
commands.next = function() ns.UI:Step("next") end
commands.skip = commands.next
commands.prev = function() ns.UI:Step("prev") end
commands.resume = function()
  local p = ns.Session:Personal()
  local g = p.guideID and ns.Guide:Get(p.guideID)
  if g and ns.Session.selfState then
    local i, step = ns.Guide:FindResumePoint(g, p, ns.Session.selfState, ns.Session.ctx)
    p.cursors[g.id] = { index = i, stepID = step and step.id }
    ns.UI:Refresh()
  end
end
-- The personal guide is chosen once and saved; "auto" picks it again from where the character stands
-- (0.1.0 read UnitPosition with swapped axes and could have saved a far-away starting route).
-- Choosing one is the Guides window's Follow (UI/GuidesFrame.lua UI:ChooseGuide): it also says how to get there.
commands.guide = function(arg)
  if arg and arg ~= "" and arg ~= "auto" then return ns.UI:ChooseGuide(arg) end
  if arg == "auto" then ns.UI:AutoGuide() end
  local p = ns.Session:Personal()
  local g = p.guideID and ns.Guide:Get(p.guideID)
  API.Print(L["Guide"] .. ": " .. (g and string.format("%s (%s)", g.title, g.id) or "-"))
  ns.UI:Refresh()
  -- a guide that starts far away: say how to get there (the arrow and the window show it too)
  local route = ns.UI:TravelGuidance()
  if route then API.Print(L["How to get there"] .. ": " .. route.summary) end
end
-- /flc guides: the Guides window
commands.guides = function() ns.UI:ShowGuides() end
-- /flc minimap [show | hide]: FLC's minimap button (UI/MinimapButton.lua)
commands.minimap = function(arg)
  local show = (arg == "show" and true) or (arg == "hide" and false) or nil
  ns.UI:SetMinimapButtonShown(show)
end
-- /flc advisor: the Class Quest Advisor window
commands.advisor = function() ns.UI:ShowAdvisor() end
-- /flc appearance: Adapt to my interface, skins, preview and apply
commands.appearance = function() ns.UI:ShowAppearance() end

-- /flc mode [quests | optimized | dungeons]: the leveling mode (Engine/Modes.lua); without an argument, the current one
commands.mode = function(arg)
  if arg and arg ~= "" then
    if not ns.Modes:Set(arg) then return usage() end
    ns.UI:Refresh()
  end
  API.Print(L["Leveling mode"] .. ": " .. L[ns.Modes.LABEL[ns.Modes:Get()]])
end
-- /flc boss [basic | detailed | off]: the Boss Guide's card (Engine/BossGuide.lua); without an argument, the current one
commands.boss = function(arg)
  if arg and arg ~= "" then
    if not ns.BossGuide:SetMode(arg) then return usage() end
    ns.UI:Refresh()
  end
  API.Print(L["Boss card"] .. ": " .. L[ns.BossGuide:Mode()])
end
-- /flc upgrades [dungeon id]: the Loot Advisor's upgrades among the bosses' own items, all dungeons or one
commands.upgrades = function(arg)
  local st = ns.Session.selfState
  if not st then return end
  local gear, spec = ns.UI:AdvisorInputs(true)
  if not gear then return API.Print(L["Your equipment could not be read: no upgrade list"]) end
  local ups = ns.LootAdvisor:Upgrades(st, gear, spec, arg ~= "" and arg or nil, 8)
  API.Print(L["Upgrades for you here (estimate from stat weights)"] .. (ns.LootAdvisor:CustomWeights() and
    (" - " .. L["your own stat priorities"]) or ""))
  if #ups == 0 then return API.Print(L["None found for your level"]) end
  for _, u in ipairs(ups) do
    local d = u.dungeon and ns.Route.dungeons and u.dungeon
    for _, x in ipairs(ns.Route.dungeons or {}) do if x.id == u.dungeon then d = L[x.name] or x.name end end
    API.Print(ns.UI.LootLine(u) .. (d and (" - " .. d) or ""))
  end
end
-- /flc atlas [text]: the Loot Atlas window, searched for `text` when given
commands.atlas = function(arg) ns.UI:ShowLootAtlas(arg) end
-- /flc lootweights strength=1, stamina=0.5 | reset: the player's own stat priorities for the upgrades
commands.lootweights = function(arg)
  if arg == "reset" then
    ns.LootAdvisor:SetCustomWeights(nil)
    return API.Print(L["Stat priorities: your class's"])
  end
  local w = ns.LootAdvisor.ParseWeights(arg)
  if not w then return usage() end
  ns.LootAdvisor:SetCustomWeights(w)
  local parts = {}
  for k, v in pairs(w) do parts[#parts + 1] = k .. "=" .. v end
  table.sort(parts)
  API.Print(L["Stat priorities"] .. ": " .. table.concat(parts, ", "))
end
-- /flc path: the leveling path of this character's race, with where it stands
commands.path = function()
  local subject = ns.Session.selfState
  local pos = subject and ns.Path:Position(subject, ns.Session:Personal().guideID)
  if not pos then return API.Print(L["No leveling path for this character"]) end
  API.Print(string.format(L["Leveling path (%d%% of the XP from quests, estimate):"], math.floor((pos.path.questShare or 0) * 100 + 0.5)))
  for i, s in ipairs(pos.path.segments) do
    local header = ns.Guide.guides[s.guide]
    -- >> what the path says to do now; * the route you follow (when it is another part of the path); -> next
    local mark = (i == pos.targetIndex and ">> ") or (i == pos.currentIndex and " * ") or (i == pos.nextIndex and "-> ") or "   "
    API.Print(string.format("%s%d-%d  %s", mark, s.from, s.to, header and ns.UI.GuideTitle(header) or s.guide))
  end
end
commands.announce = function(arg)
  if ns.U.contains(ns.Config.ANNOUNCE_MODES, arg) then
    ns.Config:Set("announce.mode", arg)
    API.Print(L[ns.UI.ANNOUNCE_LABELS[arg]])
  else
    usage()
  end
end
commands.share = function(arg)
  if arg == "yes" or arg == "no" then ns.Party:SetShare(arg == "yes") end
  API.Print(L["Share progress"] .. ": " .. tostring(ns.Config:Get("sync.share")))
end
commands.record = function(arg)
  if arg == "on" or arg == "off" then ns.Config:Set("recorder", arg == "on") end
  if arg == "export" then return ns.UI:ShowReport(ns.Recorder:Export()) end
  API.Print(L["Data recorder"] .. ": " .. tostring(ns.Config:Get("recorder")))
end
commands.reset = function(arg)
  if arg == "ui" then
    ns.W.ResetLayout()
    API.Print(L["Frame positions reset; /reload to apply"])
  end
end

SLASH_FOREVERLEVELINGCOMPANION1 = "/flc"
SlashCmdList.FOREVERLEVELINGCOMPANION = function(msg)
  local cmd, arg = string.match(msg or "", "^%s*(%S*)%s*(.-)%s*$")
  cmd = string.lower(cmd or "")
  local fn = commands[cmd]
  if fn then ns.Diag:Guard("slash:" .. cmd, fn, arg) else usage() end
end
