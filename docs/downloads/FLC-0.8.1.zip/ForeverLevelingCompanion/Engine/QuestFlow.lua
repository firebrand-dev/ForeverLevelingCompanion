-- Quest flow (docs/QUEST_FLOW.md): the guide's quests are accepted and turned in by themselves when their window
-- opens, so a chain goes on without clicking through it. When a reward must be chosen FLC never picks it: it marks
-- the recommended one (an upgrade for the character, else the one a vendor pays most for). Nothing in combat; holding
-- Shift leaves that window to the player; a turn-in that asks for money is never done by itself.
-- settings.questFlow.mode: "guide" (the quests of the guide being followed), "all" or "off".
local _, ns = ...

local QF = {}
ns.QuestFlow = QF

QF.MODES = { "guide", "all", "off" }
QF.RETRY = 10   -- seconds before the same quest of an NPC's list is opened again (a full quest log, a declined one)

QF.tried = {}

function QF:Mode()
  local m = ns.Config:Get("questFlow.mode")
  for _, v in ipairs(self.MODES) do if v == m then return m end end
  return "guide"
end

function QF:SetMode(m)
  for _, v in ipairs(self.MODES) do if v == m then ns.Config:Set("questFlow.mode", m); return true end end
  return false
end

-- Why a window is left alone, or nil
function QF:Held()
  if self:Mode() == "off" then return "off" end
  if ns.API.InCombat() then return "combat" end
  if ns.API.ShiftDown() then return "shift" end
  return nil
end

local function guideOf() local a = ns.Session:Active(); return a and a.guide end

-- Does the guide being followed have this quest (to accept or to turn in)?
function QF:InGuide(qid)
  local g = guideOf()
  return qid ~= nil and g ~= nil and g.index ~= nil
    and (g.index["accept:" .. qid] ~= nil or g.index["turnin:" .. qid] ~= nil)
end

-- The guide's quests by their name in the player's language, for the windows that give only titles
function QF:ByTitle(title)
  local g = guideOf()
  if not (g and title) then return nil end
  for _, s in ipairs(g.steps) do
    if s.quest and (s.type == "accept" or s.type == "turnin") and ns.Quest:Name(s.quest) == title then return s.quest end
  end
  return nil
end

function QF:Wants(qid, title)
  local mode = self:Mode()
  if mode == "off" then return false end
  if mode == "all" then return true end
  qid = qid or self:ByTitle(title)
  return self:InGuide(qid)
end

-- QUEST_DETAIL: a quest offered
function QF:OnDetail()
  if self:Held() then return false end
  local qid = ns.API.QuestWindowID()
  if not self:Wants(qid) then return false end
  return ns.API.QuestAccept() == true
end

-- QUEST_PROGRESS: "Complete Quest" once it is ready, and never when it asks for money
function QF:OnProgress()
  if self:Held() then return false end
  local qid = ns.API.QuestWindowID()
  if not self:Wants(qid) or not ns.API.QuestCompletable() or ns.API.QuestMoneyToGet() > 0 then return false end
  return ns.API.QuestComplete() == true
end

-- QUEST_COMPLETE: the reward, taken by itself only when there is nothing to choose
function QF:OnComplete()
  local n = ns.API.QuestChoices()
  if n > 1 then
    if self:Mode() ~= "off" then self:Recommend() end
    return false
  end
  if self:Held() then return false end
  if not self:Wants(ns.API.QuestWindowID()) then return false end
  return ns.API.QuestReward(n == 1 and 1 or 0) == true
end

-- GOSSIP_SHOW / QUEST_GREETING: opens one quest of the list (a ready turn-in first); its own window does the rest
function QF:OnNpc(kind, now)
  if self:Held() then return false end
  local list = ns.API.NpcQuests(kind)
  local function try(which, i, q)
    local key = (q.id or q.title or "?")
    if (self.tried[key] or -math.huge) + self.RETRY > now then return false end
    self.tried[key] = now
    return ns.API.NpcSelect(kind, which, i, q.id) == true
  end
  for i, q in ipairs(list.active) do
    if q.complete and self:Wants(q.id, q.title) then return try("active", i, q) end
  end
  for i, q in ipairs(list.available) do
    if (not q.trivial or self:Mode() == "guide") and self:Wants(q.id, q.title) then return try("available", i, q) end
  end
  return false
end

----------------------------------------------------------------------
-- Reward recommendation
----------------------------------------------------------------------
-- The reward to take, or nil: { index, link, why = "upgrade" | "sell", sell }; pending = true while an item's data is
-- not loaded yet (GET_ITEM_INFO_RECEIVED asks again).
function QF.Pick(items, gear, class, spec, custom)
  local AD = ns.Advisor
  local best, bestGain, pending
  for i, it in ipairs(items) do
    if it.usable and it.slot then
      local verdict, reward, mine = AD.CompareItem({ slot = it.slot, dps = it.dps, stats = it.stats }, gear, class, spec,
        custom)
      if verdict == "better" then
        -- an empty slot (mine nil) gains everything the item scores
        local gain = (mine and mine > 0) and (reward - mine) / mine or (reward or 0) + 1000
        if not bestGain or gain > bestGain then best, bestGain = i, gain end
      end
    end
  end
  if best then return { index = best, link = items[best].link, why = "upgrade" } end
  local top, topValue
  for i, it in ipairs(items) do
    if not it.link or it.sell == nil then pending = true
    elseif not topValue or it.sell * it.count > topValue then top, topValue = i, it.sell * it.count end
  end
  if pending then return nil, true end
  if top and topValue > 0 then return { index = top, link = items[top].link, why = "sell", sell = topValue } end
  return nil
end

function QF:Recommend()
  local items = {}
  for i = 1, ns.API.QuestChoices() do items[i] = ns.API.QuestChoiceItem(i) end
  local gear, spec = nil, nil
  if ns.UI.AdvisorInputs then gear, spec = ns.UI:AdvisorInputs(true) end
  local st = ns.Session.selfState
  local pick, pending = QF.Pick(items, gear, st and st.class, spec, ns.LootAdvisor and ns.LootAdvisor:CustomWeights())
  self.pending = pending or nil
  if not pick then return nil end
  self.pending = nil
  if self.shown and self.shown.index == pick.index and self.shown.qid == ns.API.QuestWindowID() then return pick end
  pick.qid = ns.API.QuestWindowID()
  self.shown = pick
  local L = ns.L
  local why = pick.why == "upgrade" and L["an upgrade for you"]
    or string.format(L["sells for the most: %s"], ns.U.money(pick.sell))
  ns.API.Print(string.format(L["Reward: FLC recommends %s (%s)"], pick.link or "?", why))
  ns.UI:MarkReward(pick.index, pick.why)
  return pick
end

-- an item's data arrived: the recommendation that waited for it
function QF:OnItemInfo()
  if self.pending then self:Recommend() end
end

-- QUEST_FINISHED: the window closed
function QF:OnClosed()
  self.pending, self.shown = nil, nil
  ns.UI:MarkReward(nil)
end
