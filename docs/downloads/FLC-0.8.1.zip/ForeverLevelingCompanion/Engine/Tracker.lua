-- Quest Tracker: diffs successive quest-log snapshots from the client into progress events.
-- Values always come from the client's quest log; a kill is never assumed to count.
-- Events (fired on the Bus):
--   TRACKER_QUEST_ADDED(qid, q)            TRACKER_OBJECTIVE_PROGRESS(qid, idx, old, new, need, label)
--   TRACKER_OBJECTIVE_COMPLETE(qid, idx)   TRACKER_OBJECTIVE_REGRESS(qid, idx, old, new)
--   TRACKER_QUEST_READY(qid)               TRACKER_QUEST_TURNED_IN(qid)    TRACKER_QUEST_ABANDONED(qid)
local _, ns = ...

local T = {
  prev = nil,
  emptyStrikes = 0,
  removed = {},        -- [qid] = { at, title } removals waiting to be classified
  turnedIn = {},       -- [qid] = time of QUEST_TURNED_IN
  titles = {},
  removalGrace = 2.0,  -- seconds to wait for QUEST_TURNED_IN before calling a removal an abandon
}
ns.Tracker = T

local function fire(events, name, ...)
  events[#events + 1] = { name, ... }
  ns.Bus:Fire(name, ...)
end

function T:Reset()
  self.prev, self.emptyStrikes, self.removed, self.turnedIn, self.titles, self.recheckAt = nil, 0, {}, {}, {}, nil
end

-- Returns the list of events produced by this snapshot.
function T:Update(log, now)
  local events = {}
  now = now or ns.Now()
  if not self.prev then
    -- First snapshot after login or /reload is a baseline: nothing is announced.
    self.prev = log
    for qid, q in pairs(log) do self.titles[qid] = q.title end
    return events
  end
  -- The client can briefly report an empty log while loading; require it twice in a row.
  -- NeedsRecheck() asks the caller for that second snapshot, so abandoning the last quest
  -- is still detected even if the client sends no further update.
  if next(log) == nil and next(self.prev) ~= nil and self.emptyStrikes < 1 then
    self.emptyStrikes = self.emptyStrikes + 1
    self.recheckAt = now + 0.5
    return events
  end
  self.emptyStrikes = 0
  self.recheckAt = nil

  for qid, q in pairs(log) do
    self.titles[qid] = q.title or self.titles[qid]
    local old = self.prev[qid]
    if not old then
      self.removed[qid] = nil
      fire(events, "TRACKER_QUEST_ADDED", qid, q)
    else
      for i, o in ipairs(q.objectives) do
        local oo = old.objectives[i]
        if oo then
          if (o.have or 0) > (oo.have or 0) then
            fire(events, "TRACKER_OBJECTIVE_PROGRESS", qid, i, oo.have or 0, o.have, o.need, o.text)
          elseif (o.have or 0) < (oo.have or 0) then
            fire(events, "TRACKER_OBJECTIVE_REGRESS", qid, i, oo.have, o.have)
          end
          if o.done and not oo.done then fire(events, "TRACKER_OBJECTIVE_COMPLETE", qid, i, o.have, o.need, o.text) end
        end
      end
      if q.complete and not old.complete then fire(events, "TRACKER_QUEST_READY", qid, q.title) end
    end
  end
  for qid, old in pairs(self.prev) do
    if not log[qid] then
      if self.turnedIn[qid] then
        self.turnedIn[qid] = nil
      else
        self.removed[qid] = { at = now, title = old.title }
      end
    end
  end
  self.prev = log
  return events
end

-- QUEST_TURNED_IN from the client. It may arrive before or after the log update.
function T:OnTurnedIn(qid, now)
  now = now or ns.Now()
  local events = {}
  if self.removed[qid] then
    self.removed[qid] = nil
  else
    self.turnedIn[qid] = now
  end
  fire(events, "TRACKER_QUEST_TURNED_IN", qid, self.titles[qid])
  return events
end

-- Classifies removals that never got a turn-in event as abandons.
function T:Tick(now)
  local events = {}
  for qid, r in pairs(self.removed) do
    if now - r.at >= self.removalGrace then
      self.removed[qid] = nil
      fire(events, "TRACKER_QUEST_ABANDONED", qid, r.title)
    end
  end
  for qid, at in pairs(self.turnedIn) do
    if now - at > 30 then self.turnedIn[qid] = nil end
  end
  return events
end

function T:Title(qid) return self.titles[qid] end

function T:NeedsRecheck(now)
  return self.recheckAt ~= nil and now >= self.recheckAt
end
