-- Navigation math: distances, bearings and travel time between map-percent locations.
-- In the client, map sizes and world positions come from C_Map; offline the fallbacks below are used
-- and results are flagged as approximate.
local _, ns = ...

local Nav = {
  mapSizes = {},                -- [uiMapID] = { width, height } in yards; filled from the client or tests
  defaultSize = { 3000, 2000 }, -- rough zone size used only when nothing better is known
  crossMapPenalty = 2500,       -- yards charged for an unknown zone change (route ordering only)
  runSpeed = 7,                 -- yards per second, unmounted run speed
}
ns.Nav = Nav

function Nav.MapSize(mapID)
  local s = Nav.mapSizes[mapID]
  if s then return s[1], s[2], false end
  if ns.API and ns.API.GetMapSize then
    local w, h = ns.API.GetMapSize(mapID)
    if w then
      Nav.mapSizes[mapID] = { w, h }
      return w, h, false
    end
  end
  return Nav.defaultSize[1], Nav.defaultSize[2], true
end

-- Any loc in world form { cont, wx, wy } (server convention), converting map-percent locs via the client.
function Nav.World(loc)
  if not loc then return nil end
  if loc.cont ~= nil then return loc end
  if loc.map and loc.x and ns.API and ns.API.MapToWorld then return ns.API.MapToWorld(loc.map, loc.x, loc.y) end
  return nil
end

local function worldDistance(a, b)
  local wa, wb = Nav.World(a), Nav.World(b)
  if not wa or not wb or wa.cont ~= wb.cont then return nil, true end
  local dn, dw = wb.wx - wa.wx, wb.wy - wa.wy
  return math.sqrt(dn * dn + dw * dw), false
end

-- Returns distance in yards (or nil), approximate flag.
function Nav.Distance(a, b)
  if not a or not b then return nil, true end
  if a.cont ~= nil or b.cont ~= nil then return worldDistance(a, b) end
  if not a.map or not b.map or not a.x or not b.x then return nil, true end
  if a.map == b.map then
    local w, h, approx = Nav.MapSize(a.map)
    local dx = (b.x - a.x) / 100 * w
    local dy = (b.y - a.y) / 100 * h
    return math.sqrt(dx * dx + dy * dy), approx
  end
  if ns.API and ns.API.ToWorld then
    local ca, ax, ay = ns.API.ToWorld(a.map, a.x, a.y)
    local cb, bx, by = ns.API.ToWorld(b.map, b.x, b.y)
    if ca and cb and ca == cb then
      local dx, dy = bx - ax, by - ay
      return math.sqrt(dx * dx + dy * dy), false
    end
  end
  return nil, true
end

-- Cost used by route ordering: never nil, unknown zone changes get a flat penalty.
function Nav.Cost(a, b)
  if not a or not b then return 0 end
  local d = Nav.Distance(a, b)
  if d then return d end
  return Nav.crossMapPenalty
end

-- Bearing to target, counter-clockwise from north, in radians; matches GetPlayerFacing().
-- Map coordinates grow east (x) and south (y).
function Nav.Bearing(from, to)
  if not from or not to then return nil end
  if from.cont ~= nil or to.cont ~= nil then
    -- World axes: wx grows north, wy grows west, so atan2(west, north) is already CCW from north.
    local wa, wb = Nav.World(from), Nav.World(to)
    if not wa or not wb or wa.cont ~= wb.cont then return nil end
    local dn, dw = wb.wx - wa.wx, wb.wy - wa.wy
    if dn == 0 and dw == 0 then return nil end
    return math.atan2(dw, dn)
  end
  if from.map ~= to.map then return nil end
  local w, h = Nav.MapSize(from.map)
  local east = (to.x - from.x) / 100 * w
  local south = (to.y - from.y) / 100 * h
  if east == 0 and south == 0 then return nil end
  return math.atan2(-east, -south)
end

-- Arrow rotation relative to the player's facing, normalized to [0, 2pi).
function Nav.RelativeAngle(from, to, facing)
  local b = Nav.Bearing(from, to)
  if not b or not facing then return nil end
  local r = (b - facing) % (2 * math.pi)
  return r
end

function Nav.TravelSeconds(yards, speed)
  if not yards then return nil end
  return yards / (speed or Nav.runSpeed)
end

-- Inside the area of a kill/loot step (loc.r = radius of the targets' spawn area): no yards to its centre.
function Nav.InArea(pos, loc)
  if not (pos and loc and loc.r) then return false end
  local d = Nav.Distance(pos, loc)
  return d ~= nil and d <= loc.r
end

function Nav.FormatDistance(yards)
  if not yards then return "?" end
  if yards >= 1000 then return string.format("%.1fk yd", yards / 1000) end
  return string.format("%d yd", math.floor(yards + 0.5))
end
