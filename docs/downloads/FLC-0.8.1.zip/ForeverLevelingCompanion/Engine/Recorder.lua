-- Data recorder (opt-in, local only): captures quest givers, turn-in NPCs and objective locations
-- observed in the live client so guides can be validated against WoW Forever instead of guessed.
-- Nothing is transmitted; /flc record export shows a text block the user may copy voluntarily.
local _, ns = ...
local U = ns.U

local R = { maxSamples = 15 }
ns.Recorder = R

function R:Enabled() return ns.Config:Get("recorder") == true end

function R:Store()
  return ns.Config.account and ns.Config.account.recorded or {}
end

local function entry(store, qid)
  local e = store[qid]
  if not e then
    e = { id = qid, samples = {} }
    store[qid] = e
  end
  return e
end

local function here()
  local map, x, y = ns.API.GetUnitPosition("player")
  if not map or not x then return nil end
  return { map = map, x = U.round(x, 1), y = U.round(y, 1) }
end

-- The NPC whose window opened last (gossip, greeting or quest details). Measured in the client: a quest taken straight
-- from its details window is accepted after the window closed, when the "npc" unit no longer exists.
function R:OnNpcWindow()
  if not self:Enabled() then return end
  -- gossip windows use the "npc" unit; quest windows may use "questnpc"
  local npcID, npcName = ns.API.GetNpcInfo("npc")
  if not npcID then npcID, npcName = ns.API.GetNpcInfo("questnpc") end
  if npcID then self.lastNpc = { npc = npcID, npcName = npcName, pos = here(), at = ns.API.Time() } end
end

local function giver(self)
  local npcID, npcName = ns.API.GetNpcInfo("npc")
  if npcID then return npcID, npcName, here() end
  local l = self.lastNpc
  if l and l.at and ns.API.Time() - l.at <= 60 then return l.npc, l.npcName, l.pos end
  return nil, nil, here()
end

function R:OnAccepted(qid, title, level)
  if not self:Enabled() then return end
  local e = entry(self:Store(), qid)
  e.title, e.level = title or e.title, level or e.level
  local npcID, npcName, pos = giver(self)
  e.start = { pos = pos, npc = npcID, npcName = npcName }
  e.build = ns.API.GetClientInfo().build
end

function R:OnTurnedIn(qid)
  if not self:Enabled() then return end
  local e = entry(self:Store(), qid)
  local npcID, npcName, pos = giver(self)
  e.finish = { pos = pos, npc = npcID, npcName = npcName }
end

-- The experience and money the game gave for a turn-in (QUEST_TURNED_IN carries them) and the character's level then:
-- measured quest XP, which on the official realm replaces the estimated dungeon-quest ranges (docs/research/DUNGEON_XP.md)
function R:OnReward(qid, xp, money)
  if not self:Enabled() or type(xp) ~= "number" then return end
  local e = entry(self:Store(), qid)
  e.reward = { xp = xp, money = type(money) == "number" and money or nil, level = ns.API.GetPlayerInfo().level,
    build = ns.API.GetClientInfo().build }
end

function R:OnProgress(qid, idx)
  if not self:Enabled() then return end
  local e = entry(self:Store(), qid)
  e.samples[idx] = e.samples[idx] or {}
  local list = e.samples[idx]
  if #list >= self.maxSamples then return end
  local p = here()
  if p then list[#list + 1] = p end
end

local function fmtPos(p)
  if not p then return "nil" end
  return string.format("{map=%d,x=%.1f,y=%.1f}", p.map, p.x, p.y)
end

function R:Export()
  local lines = { "-- FLC recorded quest data (client build " .. tostring(ns.API.GetClientInfo().build) .. ")" }
  local store = self:Store()
  for _, qid in ipairs(U.keys(store)) do
    local e = store[qid]
    local s, f = e.start or {}, e.finish or {}
    local rw = e.reward or {}
    lines[#lines + 1] = string.format("{id=%d,title=%q,level=%s,start=%s,startNpc=%s,finish=%s,finishNpc=%s,xp=%s,xpAt=%s,samples={",
      qid, e.title or "", tostring(e.level), fmtPos(s.pos), tostring(s.npc), fmtPos(f.pos), tostring(f.npc),
      tostring(rw.xp), tostring(rw.level))
    for idx, list in pairs(e.samples or {}) do
      local pts = {}
      for _, p in ipairs(list) do pts[#pts + 1] = fmtPos(p) end
      lines[#lines + 1] = string.format("  [%d]={%s},", idx, table.concat(pts, ","))
    end
    lines[#lines + 1] = "}},"
  end
  return table.concat(lines, "\n")
end

ns.Bus:On("TRACKER_OBJECTIVE_PROGRESS", R, function(qid, idx) R:OnProgress(qid, idx) end)
