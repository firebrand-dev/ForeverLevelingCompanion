-- Party Engine: roster, per-member knowledge, consent and the protocol handlers that feed it.
-- Direct client data (level, class, online, leader, IsUnitOnQuest) is used for everyone; quest logs,
-- guide progress and objectives only exist for members running the addon who agreed to share.
local _, ns = ...
local U = ns.U
local QE = ns.Quest
local P = ns.Protocol

local PE = {
  members = {},     -- [key] = member (current group only)
  departed = {},    -- [key] = member, kept for a while so a quick rejoin restores data
  requests = {},    -- incoming help requests, newest last
  proposals = {},   -- [routeID] = route proposal received from the leader
  answers = {},     -- [routeID] = { [memberKey] = true/false } for proposals we sent
  departedTTL = 900,
  maxQuery = 40,
}
ns.Party = PE

PE.SYNC = {
  none = "No addon detected",
  pending = "Waiting for data",
  synced = "Synced",
  stale = "Data is outdated",
  declined = "Not sharing",
  incompatible = "Incompatible version",
  offline = "Offline",
  left = "Left the group",
}

local function newMember(r, now)
  return {
    key = r.key, name = r.name or U.shortName(r.key), unit = r.unit,
    level = r.level, class = r.class, connected = r.connected ~= false, leader = r.leader and true or false,
    hasAddon = false, share = nil, syncState = "none", lastSeen = now,
    state = QE.NewState({ key = r.key, name = r.name, level = r.level, class = r.class, source = "api" }),
  }
end

----------------------------------------------------------------------
-- Consent
----------------------------------------------------------------------
-- true = share, false = never share, nil = not decided yet (nothing but HELLO is sent).
function PE:GetShare()
  local v = ns.Config:Get("sync.share")
  if v == "yes" then return true end
  if v == "no" then return false end
  return nil
end

function PE:SetShare(value)
  ns.Config:Set("sync.share", value and "yes" or "no")
  self:SendHello(false)
  if value then self:BroadcastAll() end
end

----------------------------------------------------------------------
-- Roster
----------------------------------------------------------------------
function PE:UpdateRoster(roster, now)
  now = now or ns.Now()
  local seen = {}
  local oldLeader = self:Leader()
  local joined, askData = {}, false
  for _, r in ipairs(roster) do
    seen[r.key] = true
    local m = self.members[r.key]
    if not m then
      joined[#joined + 1] = r.key
      m = self.departed[r.key]
      if m then
        self.departed[r.key] = nil
        m.syncState = m.hasAddon and "pending" or "none"
        askData = askData or m.hasAddon
      else
        m = newMember(r, now)
      end
      self.members[r.key] = m
      ns.Bus:Fire("PARTY_MEMBER_JOINED", m)
    end
    local wasConnected = m.connected
    m.unit, m.name = r.unit, r.name or m.name
    if r.level then m.level = r.level; m.state.level = r.level end
    if r.class then m.class = r.class; m.state.class = r.class end
    m.leader = r.leader and true or false
    m.connected = r.connected ~= false
    if wasConnected and not m.connected then
      m.offlineAt = now
      ns.Bus:Fire("PARTY_MEMBER_OFFLINE", m)
    elseif not wasConnected and m.connected then
      m.offlineAt = nil
      if m.hasAddon then
        m.syncState = "pending"
        askData = true
      end
      ns.Bus:Fire("PARTY_MEMBER_ONLINE", m)
    end
  end
  for key, m in pairs(self.members) do
    if not seen[key] then
      self.members[key] = nil
      m.leftAt, m.syncState = now, "left"
      self.departed[key] = m
      ns.Bus:Fire("PARTY_MEMBER_LEFT", m)
    end
  end
  -- what they sent before the roster listed them (usually their hello): handled now
  for _, key in ipairs(joined) do P:Replay(key, now) end
  -- a member marked "pending" again (back online, or rejoining) is asked for its data: a hello that is not a reply
  -- makes every FLC in the group answer with its state and quest log. Without it the member stayed "pending" until
  -- their next quest change (seen in a two-client run).
  if askData then self:SendHello(false) end
  local newLeader = self:Leader()
  if newLeader ~= oldLeader then ns.Bus:Fire("PARTY_LEADER_CHANGED", newLeader, oldLeader) end
  ns.Bus:Fire("PARTY_CHANGED")
end

function PE:Leader()
  if ns.API.IsPlayerLeader and ns.API.IsPlayerLeader() and next(self.members) then return ns.selfKey end
  for key, m in pairs(self.members) do if m.leader then return key end end
  return nil
end

function PE:Get(key) return self.members[key] or self.departed[key] end

function PE:List()
  local list = {}
  for _, m in pairs(self.members) do list[#list + 1] = m end
  table.sort(list, function(a, b) return a.key < b.key end)
  return list
end

function PE:Size() return U.count(self.members) + 1 end

PE.askEvery, PE.askMax = 5, 5   -- seconds between data requests to a member still "pending", and how many

function PE:Tick(now)
  -- Self-repair: a member that shares but whose data never came (its answer was sent while its client did not count
  -- itself grouped yet, and dropped: measured with two clients) is asked again, a few times.
  local ask = false
  for _, m in pairs(self.members) do
    if m.syncState == "pending" and m.connected and m.hasAddon and m.share
        and now - (m.askedAt or m.lastSeen or now) >= self.askEvery and (m.asks or 0) < self.askMax then
      m.askedAt, m.asks = now, (m.asks or 0) + 1
      ask = true
    end
  end
  if ask then self:SendHello(false) end
  local staleAfter = ns.Config:Get("party.staleAfter") or 180
  for _, m in pairs(self.members) do
    if m.syncState == "synced" and m.lastData and now - m.lastData > staleAfter then
      m.syncState = "stale"
      ns.Bus:Fire("PARTY_MEMBER_STALE", m)
    end
  end
  for key, m in pairs(self.departed) do
    if now - (m.leftAt or now) > self.departedTTL then self.departed[key] = nil end
  end
  for id, p in pairs(self.proposals) do
    if p.expires and now > p.expires and p.status == "pending" then
      p.status = "expired"
      ns.Bus:Fire("ROUTE_PROPOSAL_EXPIRED", p)
    end
  end
end

function PE:Reset()
  self.members, self.departed, self.requests, self.proposals, self.answers = {}, {}, {}, {}, {}
end

-- Only members are handled by the protocol; messages from others wait for the roster (Protocol early).
P.isKnown = function(sender) return PE.members[sender] ~= nil end

-- What is known about a member's progress, and where it came from.
function PE:Knowledge(m)
  if m.hasAddon and m.share and m.syncState ~= "incompatible" then
    return m.syncState == "stale" and "addon-stale" or "addon"
  end
  if ns.API.caps and ns.API.caps.unitOnQuest then return "api" end
  return "manual"
end

----------------------------------------------------------------------
-- Non-addon knowledge: client probes and manual input
----------------------------------------------------------------------
function PE:ProbeQuests(key, questIDs)
  local m = self.members[key]
  if not m or not m.unit then return 0 end
  local found = 0
  for _, qid in ipairs(questIDs) do
    local on = ns.API.IsUnitOnQuest(m.unit, qid)
    if on ~= nil then
      m.state.onQuest[qid] = on
      if on then found = found + 1 end
    end
  end
  return found
end

-- The user tells us the member has this quest. Objective progress stays unknown.
function PE:SetManualQuest(key, questID, onQuest)
  local m = self:Get(key)
  if not m then return false end
  m.state.onQuest[questID] = onQuest and true or false
  m.manual = m.manual or {}
  m.manual[questID] = onQuest and true or nil
  ns.Bus:Fire("PARTY_MEMBER_DATA", m, "manual")
  return true
end

----------------------------------------------------------------------
-- Outgoing
----------------------------------------------------------------------
function PE:SendHello(reply)
  local share = self:GetShare()
  P:Queue("H", { ns.version, ns.protocolMin, ns.protocolVersion, share == true and 1 or 0, reply and 1 or 0 }, "H")
end

function PE:BroadcastState()
  if self:GetShare() ~= true then return end
  local s = ns.Session and ns.Session:DescribeSelf() or {}
  P:Queue("S", {
    s.level or 0, s.class or "", s.guideID or "", s.index or 0, s.stepID or "", s.total or 0,
    s.mode or "solo", s.assisting or "", s.map or 0,
    s.x and U.round(s.x, 1) or "", s.y and U.round(s.y, 1) or "",
  }, "S")
end

function PE:BroadcastLog(state)
  if self:GetShare() ~= true or not state then return end
  local entries = {}
  for _, qid in ipairs(U.keys(state.log)) do entries[#entries + 1] = P.EncodeQuestEntry(state.log[qid]) end
  local snap = tostring(P:NextSeq())
  local chunks = P.Chunk(entries, 40)
  -- Drop any older snapshot still waiting in the queue.
  for i = #P.queue, 1, -1 do if P.queue[i].type == "L" then table.remove(P.queue, i) end end
  for part, chunk in ipairs(chunks) do
    local fields = { snap, part, #chunks }
    for _, e in ipairs(chunk) do fields[#fields + 1] = e end
    P:Queue("L", fields)
  end
end

function PE:BroadcastAll()
  self:BroadcastState()
  if ns.Session and ns.Session.selfState then self:BroadcastLog(ns.Session.selfState) end
end

function PE:SendObjective(questID, index, o)
  if self:GetShare() ~= true then return end
  P:Queue("O", { questID, index, o.have or 0, o.need or 0, o.done and 1 or 0 }, "O:" .. questID .. ":" .. index)
end

function PE:SendTurnin(questID)
  if self:GetShare() ~= true then return end
  P:Queue("T", { questID })
end

function PE:SendAbandon(questID)
  if self:GetShare() ~= true then return end
  P:Queue("A", { questID })
end

function PE:QueryCompletion(questIDs)
  local ids = {}
  for i = 1, math.min(#questIDs, self.maxQuery) do ids[i] = tostring(questIDs[i]) end
  if #ids == 0 then return end
  P:Queue("Q", { P:NextSeq(), table.concat(ids, ",") })
end

function PE:SendHelp(action, targetKey)
  P:Queue("K", { action, targetKey or "" })
end

function PE:RequestRefresh()
  P:Queue("F", {}, "F")
end

----------------------------------------------------------------------
-- Incoming
----------------------------------------------------------------------
local function member(sender)
  return PE.members[sender]
end

local function touch(m, now)
  m.lastSeen = now
  m.lastData = now
  m.asks, m.askedAt = 0, nil
  if m.share and m.syncState ~= "incompatible" then m.syncState = "synced" end
end

P:On("H", function(sender, f, msg, now)
  local m = member(sender)
  if not m then return end
  m.hasAddon = true
  m.addonVersion = f[1]
  ns.Updates:Seen(f[1])   -- a newer FLC in the group: said once (Engine/Updates.lua)
  local pmin, pmax = tonumber(f[2]) or 1, tonumber(f[3]) or msg.version
  m.proto = pmax
  m.share = f[4] == "1"
  m.lastSeen = now
  if pmin > ns.protocolVersion or pmax < ns.protocolMin then
    m.syncState = "incompatible"
  elseif not m.share then
    m.syncState = "declined"
    -- Forget data they stopped sharing.
    m.state = QE.NewState({ key = m.key, name = m.name, level = m.level, class = m.class, source = "api" })
    m.guide = nil
  else
    m.syncState = m.lastData and "synced" or "pending"
    m.state.source = "addon"
  end
  if f[5] ~= "1" then
    PE:SendHello(true)
    PE:BroadcastAll()
  end
  ns.Bus:Fire("PARTY_MEMBER_DATA", m, "hello")
end)

P:On("S", function(sender, f, _, now)
  local m = member(sender)
  if not m or not m.share then return end
  m.level = tonumber(f[1]) or m.level
  m.state.level = m.level
  if f[2] ~= "" then m.class = f[2]; m.state.class = f[2] end
  m.guide = {
    guideID = f[3] ~= "" and f[3] or nil, index = tonumber(f[4]) or 0,
    stepID = f[5] ~= "" and f[5] or nil, total = tonumber(f[6]) or 0,
  }
  m.mode = f[7]
  m.assisting = f[8] ~= "" and f[8] or nil
  local map = tonumber(f[9])
  if map and map > 0 then
    m.map = map
    m.pos = (tonumber(f[10]) and tonumber(f[11])) and { map = map, x = tonumber(f[10]), y = tonumber(f[11]) } or nil
  end
  touch(m, now)
  ns.Bus:Fire("PARTY_MEMBER_DATA", m, "state")
end)

P:On("L", function(sender, f, _, now)
  local m = member(sender)
  if not m or not m.share then return end
  local snap, part, total = f[1], tonumber(f[2]), tonumber(f[3])
  if not part or not total or part < 1 or part > total or total > 20 then return end
  local entries = {}
  for i = 4, #f do
    local q = P.DecodeQuestEntry(f[i])
    if q then entries[#entries + 1] = q end
  end
  local all = P:Assemble(sender, snap, part, total, entries, now)
  if not all then return end
  local log = {}
  for _, q in ipairs(all) do
    local old = m.state.log[q.questID]
    q.title = old and old.title
    log[q.questID] = q
    m.state.completion[q.questID] = false
  end
  m.state.log = log
  m.state.logKnown = true
  m.state.source = "addon"
  m.state.updatedAt = now
  touch(m, now)
  ns.Bus:Fire("PARTY_MEMBER_DATA", m, "log")
end)

P:On("O", function(sender, f, _, now)
  local m = member(sender)
  if not m or not m.share then return end
  local qid, idx = tonumber(f[1]), tonumber(f[2])
  if not qid or not idx or idx < 1 or idx > 20 then return end
  local q = m.state.log[qid]
  if not q then
    q = { questID = qid, objectives = {}, complete = false }
    m.state.log[qid] = q
  end
  q.objectives[idx] = { have = tonumber(f[3]) or 0, need = tonumber(f[4]) or 0, done = f[5] == "1" }
  local all = #q.objectives > 0
  for i = 1, #q.objectives do if not (q.objectives[i] and q.objectives[i].done) then all = false end end
  q.complete = all
  touch(m, now)
  ns.Bus:Fire("PARTY_OBJECTIVE", m, qid, idx, q.objectives[idx])
end)

P:On("T", function(sender, f, _, now)
  local m = member(sender)
  local qid = tonumber(f[1])
  if not m or not m.share or not qid then return end
  m.state:MarkTurnedIn(qid)
  touch(m, now)
  ns.Bus:Fire("PARTY_TURNIN", m, qid)
end)

P:On("A", function(sender, f, _, now)
  local m = member(sender)
  local qid = tonumber(f[1])
  if not m or not m.share or not qid then return end
  m.state.log[qid] = nil
  touch(m, now)
  ns.Bus:Fire("PARTY_MEMBER_DATA", m, "abandon")
end)

P:On("Q", function(sender, f)
  if PE:GetShare() ~= true or not member(sender) then return end
  local state = ns.Session and ns.Session.selfState
  if not state then return end
  local pairsOut = {}
  local ids = U.split(f[2] or "", ",")
  for i = 1, math.min(#ids, PE.maxQuery) do
    local qid = tonumber(ids[i])
    if qid then
      local c = state:IsCompleted(qid)
      pairsOut[#pairsOut + 1] = qid .. ":" .. (c == true and "1" or "0")
    end
  end
  local chunks = P.Chunk(pairsOut, 40)
  for _, chunk in ipairs(chunks) do P:Queue("R", { f[1] or "0", table.concat(chunk, ",") }) end
end)

P:On("R", function(sender, f, _, now)
  local m = member(sender)
  if not m or not m.share then return end
  for _, item in ipairs(U.split(f[2] or "", ",")) do
    local qid, bit = string.match(item, "^(%d+):([01])$")
    if qid then m.state.completion[tonumber(qid)] = bit == "1" end
  end
  touch(m, now)
  ns.Bus:Fire("PARTY_MEMBER_DATA", m, "completion")
end)

P:On("K", function(sender, f, _, now)
  local m = member(sender)
  if not m then return end
  local action, target = f[1], f[2]
  if action == "request" then
    for i = #PE.requests, 1, -1 do if PE.requests[i].from == sender then table.remove(PE.requests, i) end end
    PE.requests[#PE.requests + 1] = { from = sender, at = now }
    ns.Bus:Fire("HELP_REQUESTED", m)
  elseif action == "cancel" then
    for i = #PE.requests, 1, -1 do if PE.requests[i].from == sender then table.remove(PE.requests, i) end end
    ns.Bus:Fire("HELP_REQUEST_CANCELLED", m)
  elseif action == "start" or action == "stop" then
    m.assisting = action == "start" and target or nil
    if target == ns.selfKey then ns.Bus:Fire("HELP_NOTICE", m, action) end
  end
end)

P:On("F", function(sender)
  if not member(sender) then return end
  PE:BroadcastAll()
end)

P:On("B", function(sender)
  local m = member(sender)
  if not m then return end
  m.hasAddon, m.share, m.syncState = false, nil, "none"
  ns.Bus:Fire("PARTY_MEMBER_DATA", m, "bye")
end)

-- Route proposals: only the current leader may propose; members must answer explicitly.
P:On("P", function(sender, f, _, now)
  local m = member(sender)
  if not m then return end
  if PE:Leader() ~= sender then
    ns.Diag:Warn("party", "ignored route proposal from non-leader " .. sender)
    return
  end
  local id = f[1]
  local quests = {}
  for _, s in ipairs(U.split(f[4] or "", ",")) do
    local q = tonumber(s)
    if q then quests[#quests + 1] = q end
  end
  PE.proposals[id] = {
    id = id, from = sender, mode = f[2], preset = f[3], quests = quests,
    target = f[5] ~= "" and f[5] or nil, at = now, expires = now + 120, status = "pending",
  }
  ns.Bus:Fire("ROUTE_PROPOSED", PE.proposals[id])
end)

P:On("Y", function(sender, f)
  local id = f[1]
  if not PE.answers[id] then return end
  PE.answers[id][sender] = f[2] == "1"
  ns.Bus:Fire("ROUTE_ANSWERED", id, sender, f[2] == "1")
end)

function PE:ProposeRoute(id, mode, preset, questIDs, target)
  if self:Leader() ~= ns.selfKey then return false, "not-leader" end
  local ids = {}
  for i = 1, math.min(#questIDs, 30) do ids[i] = tostring(questIDs[i]) end
  self.answers[id] = {}
  P:Queue("P", { id, mode, preset, table.concat(ids, ","), target or "" })
  return true
end

function PE:AnswerProposal(id, accept)
  local p = self.proposals[id]
  if not p or p.status ~= "pending" then return false end
  p.status = accept and "accepted" or "declined"
  P:Queue("Y", { id, accept and 1 or 0 })
  return true
end

-- A leader change invalidates proposals that are still waiting for an answer.
ns.Bus:On("PARTY_LEADER_CHANGED", PE, function(newLeader)
  for _, p in pairs(PE.proposals) do
    if p.status == "pending" and p.from ~= newLeader then
      p.status = "invalidated"
      ns.Bus:Fire("ROUTE_PROPOSAL_EXPIRED", p)
    end
  end
end)

ns.Bus:On("PROTO_INCOMPATIBLE", PE, function(sender)
  local m = PE.members[sender]
  if m then
    m.hasAddon = true
    m.syncState = "incompatible"
    ns.Bus:Fire("PARTY_MEMBER_DATA", m, "incompatible")
  end
end)
