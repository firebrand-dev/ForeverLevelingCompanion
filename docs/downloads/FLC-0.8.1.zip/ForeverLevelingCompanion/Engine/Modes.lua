-- Leveling modes (docs/LEVELING_MODES.md): Quests only, Optimized leveling, Dungeons first. The mode is a setting of
-- the character: it never moves a guide's cursor (progress stays in FLC_CharDB.personal) and never waits for a group.
-- A dungeon is a suggestion next to the route, which goes on; "Later" and "Skip" are remembered per dungeon. Pure
-- logic: no client calls.
local _, ns = ...
local U = ns.U

local M = {}
ns.Modes = M

M.MODES = { "quests", "optimized", "dungeons" }
M.DEFAULT = "quests"
M.LABEL = { quests = "Quests only", optimized = "Optimized leveling", dungeons = "Dungeons first" }
-- Pending quests a dungeon needs to be suggested. Optimized: a trip worth making (more than one quest, or the first
-- visit's quest). Dungeons first: any pending quest. No mode suggests a dungeon for its creatures alone
-- (docs/research/DUNGEON_XP.md: dungeon kill XP was cut on the official realm, by an unknown amount).
M.MIN_PENDING = { optimized = 2, dungeons = 1 }
-- "Later" hides a dungeon until the character is this many levels higher.
M.LATER_LEVELS = 2

local function store()
  local char = ns.Session and ns.Session.char
  if not char then return nil end
  char.leveling = type(char.leveling) == "table" and char.leveling or {}
  local l = char.leveling
  if not U.contains(M.MODES, l.mode) then l.mode = M.DEFAULT end
  l.dungeons = type(l.dungeons) == "table" and l.dungeons or {}
  return l
end

function M:Get()
  local l = store()
  return l and l.mode or M.DEFAULT
end

-- Changes the mode only: guide cursors, the active guide and the dungeon decisions stay as they are.
function M:Set(mode)
  local l = store()
  if not l or not U.contains(M.MODES, mode) then return false end
  l.mode = mode
  if ns.Bus then ns.Bus:Fire("LEVELING_MODE_CHANGED", mode) end
  return true
end

function M:Cycle()
  local cur = self:Get()
  local i = 1
  for k, v in ipairs(M.MODES) do if v == cur then i = k end end
  local mode = M.MODES[i % #M.MODES + 1]
  self:Set(mode)
  return mode
end

-- The player's decision on a dungeon: "later" (at this level) or "skip"; nil clears it.
function M:Decide(dungeonID, what, level)
  local l = store()
  if not l or type(dungeonID) ~= "string" then return false end
  if what == nil then
    l.dungeons[dungeonID] = nil
  elseif what == "later" or what == "skip" then
    l.dungeons[dungeonID] = { state = what, level = level }
  else
    return false
  end
  return true
end

function M:Decision(dungeonID)
  local l = store()
  return l and l.dungeons[dungeonID] or nil
end

local function hidden(d, level)
  local dec = M:Decision(d.id)
  if not dec then return false end
  if dec.state == "skip" then return true end
  return dec.state == "later" and level < (dec.level or 0) + M.LATER_LEVELS
end

-- The dungeon this mode suggests for the character now, or nil:
--   { dungeon = <RE.dungeons entry>, pending = <quests the character can do there now>, done = <dungeon quests
--     already turned in>, firstVisit = <no dungeon quest turned in yet> }
-- A dungeon fits when the level is within its range (Dungeons first: from one level below), its faction allows the
-- character, the player did not skip or postpone it, and it has enough pending quests for the mode.
function M:Dungeon(state, mode)
  mode = mode or self:Get()
  local need = M.MIN_PENDING[mode]
  local RE, QE = ns.Route, ns.Quest
  if not need or not state or not RE or not QE then return nil end
  local level = state.level or 1
  local best
  for _, d in ipairs(RE.dungeons or {}) do
    local lo = d.minLevel - (mode == "dungeons" and 1 or 0)
    local fits = level >= lo and level <= d.maxLevel and not (d.faction and state.faction and d.faction ~= state.faction)
    if fits and not hidden(d, level) then
      local pending, done = 0, 0
      for _, qid in ipairs(RE.DungeonQuests(d)) do
        local status = QE:Availability(state, qid)
        if status == "completed" then done = done + 1
        elseif QE:IsPending(status) then pending = pending + 1 end
      end
      -- a dungeon that drops an item the character wants (Loot Atlas wishlist) is worth an optional detour even
      -- with fewer quests
      local wanted = 0
      if ns.LootAtlas then
        for _, w in ipairs(ns.LootAtlas:WishlistIn(d.id)) do if w.state == "want" then wanted = wanted + 1 end end
      end
      if pending >= need or wanted > 0 then
        local c = { dungeon = d, pending = pending, done = done, firstVisit = done == 0, wanted = wanted }
        -- more pending quests first; then the dungeon whose range is closer to the level
        local mid = (d.minLevel + d.maxLevel) / 2
        c.rank = pending * 10 + wanted * 15 - math.abs(level - mid)
        if not best or c.rank > best.rank then best = c end
      end
    end
  end
  return best
end
