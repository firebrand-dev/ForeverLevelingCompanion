-- New version notice (docs/UPDATES.md). FLC never looks anything up outside the game and never downloads or runs
-- anything: it learns of a newer version only from the version other FLC players in the group announce (their HELLO,
-- Engine/PartyEngine.lua), says so once with where to download it, and remembers it for the next logins until this
-- FLC is updated. /flc version says the installed version, the newest seen and the download page.
local _, ns = ...

local Up = {}
ns.Updates = Up

-- "0.8.0", "0.8.0-rc3", "1.2": its numbers and an optional pre-release tag; nil for anything else (a version is a
-- stranger's text: nothing but digits, dots, letters and one dash is ever shown)
function Up.Parse(v)
  if type(v) ~= "string" or #v > 24 then return nil end
  local core, pre = string.match(v, "^(%d+%.%d+[%.%d]*)%-?(%w*)$")
  if not core or string.find(core, "%.%.") or string.sub(core, -1) == "." then return nil end
  local nums = {}
  for n in string.gmatch(core, "%d+") do nums[#nums + 1] = tonumber(n) end
  return { nums = nums, pre = pre ~= "" and pre or nil }
end

-- Is a older than b? A release is newer than its candidates ("0.8.0-rc3" < "0.8.0") and rc2 < rc10.
function Up.Less(a, b)
  local pa, pb = Up.Parse(a), Up.Parse(b)
  if not (pa and pb) then return false end
  for i = 1, math.max(#pa.nums, #pb.nums) do
    local x, y = pa.nums[i] or 0, pb.nums[i] or 0
    if x ~= y then return x < y end
  end
  if pa.pre == pb.pre or not pa.pre then return false end
  if not pb.pre then return true end
  local ta, na = string.match(pa.pre, "^(%a*)(%d*)$")
  local tb, nb = string.match(pb.pre, "^(%a*)(%d*)$")
  if ta and tb and ta == tb then return (tonumber(na) or 0) < (tonumber(nb) or 0) end
  return pa.pre < pb.pre
end

function Up:Store() return ns.Config.settings.updates end

local function tell(self, version)
  self.told = version
  ns.API.Print(string.format(ns.L["A newer Forever Leveling Companion is out: %s (yours: %s). Download it from %s"],
    version, ns.version, ns.DOWNLOAD_URL))
end

-- A version another FLC player announced: newer than this one, it is remembered and said once per session.
function Up:Seen(version)
  if not Up.Parse(version) or not Up.Less(ns.version, version) then return false end
  local s = self:Store()
  if s and (not s.newest or Up.Less(s.newest, version)) then s.newest = version end
  if self.told and not Up.Less(self.told, version) then return false end
  tell(self, version)
  return true
end

-- At login: a newer version seen in an earlier session is said again until this FLC is that new; then forgotten.
function Up:Login()
  local s = self:Store()
  if not (s and s.newest) then return false end
  if not Up.Less(ns.version, s.newest) then s.newest = nil; return false end
  tell(self, s.newest)
  return true
end

function Up:Lines()
  local s = self:Store() or {}
  local out = { string.format(ns.L["Forever Leveling Companion %s"], ns.version) }
  if s.newest and Up.Less(ns.version, s.newest) then
    out[#out + 1] = string.format(ns.L["Newer version seen in your group: %s"], s.newest)
  end
  out[#out + 1] = ns.L["Downloads and news:"] .. " " .. ns.DOWNLOAD_URL
  return out
end
