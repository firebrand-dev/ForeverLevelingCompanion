-- Boss Guide (B1, docs/BOSS_GUIDE.md): a short card for the next boss of a dungeon guide (Engine/DungeonGuide.lua),
-- before the pull and during the fight: its abilities by who they go at, with their source, in a basic or a
-- detailed form, or nothing (off). The fight is followed only through events the client really sends:
-- ENCOUNTER_START, ENCOUNTER_END and BOSS_KILL. The boss's casts reach addons with a secret spell in this client
-- (client run 20261029-010425), so there is no cast alert, and no timer anywhere: nothing here predicts when an
-- ability comes. Nothing plays: no targeting, casting or movement. Pure logic.
local _, ns = ...

local BG = {}
ns.BossGuide = BG

BG.MODES = { "basic", "detailed", "off" }
BG.DEFAULT = "basic"

function BG:Mode()
  local m = ns.Config and ns.Config:Get("bossGuide")
  for _, v in ipairs(BG.MODES) do if v == m then return m end end
  return BG.DEFAULT
end

function BG:SetMode(mode)
  for _, v in ipairs(BG.MODES) do
    if v == mode then
      ns.Config:Set("bossGuide", mode)
      return true
    end
  end
  return false
end

-- The boss step of an encounter: the active dungeon guide's first, then any registered dungeon guide's.
function BG:StepFor(encounterID)
  local DG = ns.DungeonGuide
  local function find(g)
    for _, s in ipairs(g and g.steps or {}) do
      if s.type == "boss" and s.encounter == encounterID then return s, g end
    end
  end
  local s, g = find(DG:Active())
  if s then return s, g end
  for _, id in pairs(DG.byDungeon) do
    s, g = find(ns.Guide:Get(id))
    if s then return s, g end
  end
  return nil
end

-- ENCOUNTER_START: the fight of this boss is on (kept until it ends, a reload forgets it).
function BG:OnEncounterStart(encounterID)
  if type(encounterID) ~= "number" then return false end
  local step = self:StepFor(encounterID)
  self.fight = { encounter = encounterID, step = step, at = ns.Now() }
  return step ~= nil
end

-- ENCOUNTER_END (won or not) or BOSS_KILL: the fight is over.
function BG:OnEncounterEnd(encounterID)
  if self.fight and (encounterID == nil or self.fight.encounter == encounterID) then
    self.fight = nil
    return true
  end
  return false
end

-- What the card shows now: { step, fighting, encounter } or nil. During a fight, its boss; otherwise the current step
-- of the active dungeon guide when it is a boss step. Off shows nothing.
function BG:Card(current)
  if self:Mode() == "off" then return nil end
  if self.fight then
    return { step = self.fight.step, fighting = true, encounter = self.fight.encounter }
  end
  local s = current and current.step
  if s and s.type == "boss" and current.guide and current.guide.kind == "dungeon" then
    return { step = s, fighting = false, encounter = s.encounter }
  end
  return nil
end

-- "Taragaman the Hungerer", or "Infurnus (Magmatus)" when the game's encounter and the server's creature differ.
function BG.Name(step)
  local npc = step.npc and ((step.npc.id and ns.Quest:SourceName("npc", step.npc.id)) or step.npc.name) or "?"
  if step.encounterName and step.encounterName ~= npc then return string.format("%s (%s)", step.encounterName, npc) end
  return npc
end

-- The abilities of an encounter of several creatures by creature, in the data's order: { { name, abilities } }, or
-- nil when the abilities are one boss's (they carry no `by`).
function BG.ByCreature(step)
  local out, at = {}, {}
  for _, a in ipairs(step.abilities or {}) do
    if not a.by then return nil end
    local key = a.byId or a.by
    if not at[key] then
      local name = (a.byId and ns.Quest and ns.Quest:SourceName("npc", a.byId)) or a.by
      at[key] = { name = name, abilities = {} }
      out[#out + 1] = at[key]
    end
    local list = at[key].abilities
    list[#list + 1] = a
  end
  return #out > 0 and out or nil
end

-- The target groups (DungeonGuide.TARGET_GROUPS) that are the player's own for a role, only from what the data says
-- of who an ability goes at: the tank is the boss's current target and stands next to it; a random player can be
-- anyone. Nothing here says how to play a role.
BG.ROLE_GROUPS = {
  TANK = { tank = true, around = true },
  HEALER = { anyone = true },
  DAMAGER = { anyone = true },
}

-- The player's role ("TANK", "HEALER", "DAMAGER") or nil when the client cannot say: then nothing is highlighted.
function BG:Role()
  local r = ns.API and ns.API.GetPlayerRole and ns.API.GetPlayerRole()
  return BG.ROLE_GROUPS[r or ""] and r or nil
end

-- The card's lines for a boss step. Basic: one line per target group ("Tank: Uppercut"); detailed: one line per
-- ability with who it goes at in the data's words. Then, when some are in review, what "(?)" means, and that the game
-- shows no casts. Words come through `L`. With a role, `mark` (text -> text) highlights what is that role's own (the whole
-- line, or an ability's name in an encounter of several creatures); the second result lists those abilities' names.
function BG.Lines(step, detailed, L, role, mark)
  local lines, marked = {}, {}
  if not step then return lines, marked end
  local DG = ns.DungeonGuide
  local groups, review = DG.AbilityGroups(step)
  local by = BG.ByCreature(step)
  local own = BG.ROLE_GROUPS[role or ""] or {}
  mark = mark or function(t) return t end
  local function mine(a)
    if own[DG.TARGET_GROUPS[a.target or ""] or "other"] then
      marked[#marked + 1] = DG.AbilityName(a)
      return true
    end
    return false
  end
  if #(step.abilities or {}) == 0 then
    lines[#lines + 1] = L["No ability known for this boss"]
  elseif by then
    -- an encounter of several creatures (The Seven, the Ring of Law): one line per creature, the ones met one by one
    for _, c in ipairs(by) do
      local names = {}
      for _, a in ipairs(c.abilities) do
        local n = detailed and string.format("%s (%s)", DG.AbilityName(a), L[a.target or "?"] or (a.target or "?"))
          or DG.AbilityName(a)
        names[#names + 1] = mine(a) and mark(n) or n
      end
      lines[#lines + 1] = c.name .. ": " .. table.concat(names, ", ")
    end
  elseif detailed then
    for _, a in ipairs(step.abilities) do
      local l = string.format("%s: %s", DG.AbilityName(a), L[a.target or "?"] or (a.target or "?"))
      lines[#lines + 1] = mine(a) and mark(l) or l
    end
  else
    local words = { tank = L["Tank"], around = L["Around it"], anyone = L["Anyone"], other = L["Other"] }
    for _, g in ipairs(groups) do
      local l = words[g.group] .. ": " .. table.concat(g.names, ", ")
      if own[g.group] then
        for _, n in ipairs(g.names) do marked[#marked + 1] = n end
        l = mark(l)
      end
      lines[#lines + 1] = l
    end
  end
  if review > 0 then
    lines[#lines + 1] = L["(?) in review: tell us if the game shows something else (/flc review)"]
  end
  if detailed then
    lines[#lines + 1] = L["The game does not show this boss's casts to addons: no alerts, no timers"]
  end
  return lines, marked
end
