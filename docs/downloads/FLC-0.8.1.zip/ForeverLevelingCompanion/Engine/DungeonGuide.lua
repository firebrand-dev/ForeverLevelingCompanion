-- Dungeon guides (D1, docs/DUNGEON_GUIDE.md): a guide per dungeon from the pack (tools/catalog/dungeon_guides.py):
-- the way in, the quest objectives inside (for characters on those quests), the bosses in the client's order with
-- their abilities, the way out. Started from the dungeon's preparation (Engine/DungeonAdvisor.lua); the route's guide
-- is remembered and comes back when the dungeon guide ends. A boss step is done when the game reports the encounter
-- won (ENCOUNTER_END), or by hand. Nothing here plays: no targeting, no casting, no movement.
local _, ns = ...

local DG = { byDungeon = {} }
ns.DungeonGuide = DG

-- Who an ability goes at (the dungeon catalog's words) -> the group it is listed under in the boss step.
DG.TARGET_GROUPS = {
  ["at its current target (usually the tank)"] = "tank", ["the attacker"] = "tank",
  ["on itself / around it"] = "around", ["players in range"] = "around",
  ["a random player"] = "anyone", ["a stored target"] = "anyone",
}
DG.GROUP_ORDER = { "tank", "around", "anyone", "other" }

function DG:Register(guide)
  if type(guide) ~= "table" or type(guide.dungeon) ~= "string" then return false end
  guide.suggest = false     -- never picked as a leveling route
  local ok, errs = ns.Guide:Register(guide)
  if ok then self.byDungeon[guide.dungeon] = guide.id end
  return ok, errs
end

function DG:For(dungeonID)
  local id = dungeonID and self.byDungeon[dungeonID]
  return id and ns.Guide:Get(id) or nil
end

local function personal()
  return ns.Session and ns.Session.char and ns.Session:Personal()
end

function DG:Active()
  local p = personal()
  local g = p and p.guideID and ns.Guide:Get(p.guideID)
  return g and g.kind == "dungeon" and g or nil
end

-- The dungeon guide becomes the active guide from its first step; what an earlier visit left (won encounters, steps
-- done or skipped by hand) is forgotten. The route's guide is remembered for the end.
function DG:Start(dungeonID)
  local g, p = self:For(dungeonID), personal()
  if not g or not p then return false end
  if p.guideID ~= g.id then p.dungeonReturn = p.guideID end
  p.encounters = {}
  p.cursors[g.id] = { index = 1 }
  for _, s in ipairs(g.steps) do
    p.skipped[s.id], p.manual[s.id], p.reached[s.id] = nil, nil, nil
  end
  p.guideID = g.id
  if ns.Bus then ns.Bus:Fire("DUNGEON_GUIDE_CHANGED", g.id) end
  return true
end

-- Back to the route's guide (or to FLC's suggestion when there was none).
function DG:End()
  local p = personal()
  if not p or not self:Active() then return false end
  p.guideID = p.dungeonReturn
  p.dungeonReturn = nil
  if ns.Bus then ns.Bus:Fire("DUNGEON_GUIDE_CHANGED", nil) end
  return true
end

-- The way in of the active dungeon guide is reached when the character is inside the dungeon's map (by the door, the
-- dungeon finder or a teleport): GetInstanceInfo, since inside dungeons the client gives no position.
function DG:CheckInside(mapID)
  local g = self:Active()
  local p = personal()
  if not g or not p or not mapID then return false end
  local c = ns.Guide:Cursor(p, g)
  local s = g.steps[c.index]
  if s and s.insideMap == mapID and not p.reached[s.id] then
    p.reached[s.id] = true
    return true
  end
  return false
end

-- ENCOUNTER_END(encounterID, name, difficulty, size, success) with success, or BOSS_KILL(encounterID, name): the
-- encounter was won and its boss step is done. An ENCOUNTER_END can come with success 0 even when the boss died,
-- followed by BOSS_KILL; a step the game does not report is done by hand (Done).
function DG:OnEncounterEnd(encounterID, success)
  if not (success == 1 or success == true) or type(encounterID) ~= "number" then return false end
  local p = personal()
  if not p then return false end
  p.encounters = type(p.encounters) == "table" and p.encounters or {}
  p.encounters[encounterID] = true
  return true
end

-- An ability's name as shown: "(?)" after it while it is in review (no independent source of the official game names
-- it for this boss yet: tools/catalog/ability_check.py).
function DG.AbilityName(a)
  return a.review and (a.name .. " (?)") or a.name
end

-- A boss step's abilities grouped by who they go at: { { group = "tank", names = { ... } }, ... }, and how many of
-- them are in review.
function DG.AbilityGroups(step)
  local by, review = {}, 0
  for _, a in ipairs(step.abilities or {}) do
    local g = DG.TARGET_GROUPS[a.target or ""] or "other"
    by[g] = by[g] or {}
    by[g][#by[g] + 1] = DG.AbilityName(a)
    if a.review then review = review + 1 end
  end
  local out = {}
  for _, g in ipairs(DG.GROUP_ORDER) do
    if by[g] then out[#out + 1] = { group = g, names = by[g] } end
  end
  return out, review
end
