-- Guide packs: guides, routes and quest data shipped as separate addons (format: docs/GUIDE_PACKS.md).
-- The core ships only original sample content. A pack registers its manifest once (FLC_Packs:Register), then its
-- files add content through the pack's handle (FLC_Packs:Open). Every call is isolated and counted, so a broken pack
-- cannot break the addon, and every quest and guide remembers which pack it came from.
local _, ns = ...
local U = ns.U

local PK = { FORMAT = 1, packs = {}, order = {}, rejected = {} }
ns.Packs = PK

local REQUIRED = { "id", "title", "version", "author", "license" }

function PK:Validate(m)
  local errs = {}
  if type(m) ~= "table" then return false, { "manifest is not a table" } end
  for _, k in ipairs(REQUIRED) do
    if type(m[k]) ~= "string" or m[k] == "" then errs[#errs + 1] = "missing " .. k end
  end
  if type(m.id) == "string" and (not string.find(m.id, "^[%w][%w%._%-]*$") or #m.id > 64) then
    errs[#errs + 1] = "bad id " .. m.id
  end
  if type(m.format) ~= "number" then
    errs[#errs + 1] = "missing format"
  elseif m.format > self.FORMAT then
    errs[#errs + 1] = "format " .. m.format .. " is newer than this addon reads (" .. self.FORMAT .. "): update FLC"
  end
  if m.provenance ~= nil and type(m.provenance) ~= "table" then errs[#errs + 1] = "provenance is not a table" end
  if m.minFLC ~= nil and U.versionLess(ns.version, m.minFLC) then
    errs[#errs + 1] = "needs Forever Leveling Companion " .. tostring(m.minFLC) .. " or newer (this is " .. ns.version .. "): update FLC"
  end
  if type(m.id) == "string" and self.packs[m.id] then errs[#errs + 1] = "pack " .. m.id .. " is already registered" end
  return #errs == 0, errs
end

local function guarded(pack, what, fn, ...)
  local ok, a, b = pcall(fn, ...)
  if not ok then
    pack.errors[#pack.errors + 1] = what .. ": " .. tostring(a)
    ns.Diag:Error("pack:" .. pack.id, what .. ": " .. tostring(a))
    return nil
  end
  return a, b
end

-- The handle a pack's files use. Content is tagged with the pack id ("pack:<id>" as the quest source).
local function handle(pack)
  local source = "pack:" .. pack.id
  local h = { id = pack.id }
  function h:Quests(list)
    local accepted, rejected = guarded(pack, "quests", function() return ns.Quest:RegisterQuests(list, source) end)
    pack.counts.quests = pack.counts.quests + (accepted or 0)
    pack.counts.rejected = pack.counts.rejected + (rejected or 0)
  end
  function h:Names(names, locale)
    if guarded(pack, "names", function() return ns.Quest:RegisterNames(names, locale) end) then
      pack.counts.names = pack.counts.names + 1
    end
  end
  function h:Guide(guide)
    if type(guide) == "table" then guide.pack = pack.id end
    if guarded(pack, "guide", function() return ns.Guide:Register(guide) end) then
      pack.counts.guides = pack.counts.guides + 1
    else
      pack.counts.rejected = pack.counts.rejected + 1
    end
  end
  function h:LazyGuide(header, loader)
    if type(header) == "table" then header.pack = pack.id end
    if guarded(pack, "guide", function() return ns.Guide:RegisterLazy(header, loader) end) then
      pack.counts.guides = pack.counts.guides + 1
    else
      pack.counts.rejected = pack.counts.rejected + 1
    end
  end
  function h:Advisor(list)
    guarded(pack, "advisor", function() return ns.Advisor:Register(list) end)
  end
  function h:LevelingPaths(list)
    guarded(pack, "paths", function() return ns.Path:Register(list) end)
  end
  function h:Dungeons(list)
    guarded(pack, "dungeons", function() return ns.Route.RegisterDungeons(list) end)
  end
  function h:DungeonQuests(map)
    guarded(pack, "dungeons", function() return ns.Route.AttachDungeonQuests(map, source) end)
  end
  -- Dungeon Quest Advisor data (tools/catalog/dungeon_pack.py): entrance, finder, quest XP at the quest's level
  function h:DungeonInfo(map)
    guarded(pack, "dungeons", function() return ns.DungeonAdvisor:Register(map, source) end)
  end
  -- the bosses' own loot (tools/catalog/loot_pack.py), built on first use by the Loot Advisor
  function h:DungeonLoot(loader)
    guarded(pack, "loot", function() return ns.LootAdvisor:Register(loader) end)
  end
  -- the Loot Atlas (tools/catalog/atlas_pack.py), built on first use
  function h:LootAtlas(loader)
    guarded(pack, "loot", function() return ns.LootAtlas:Register(loader) end)
  end
  -- a dungeon guide (tools/catalog/dungeon_guides.py)
  function h:DungeonGuide(guide)
    if type(guide) == "table" then guide.pack = pack.id end
    if guarded(pack, "guide", function() return ns.DungeonGuide:Register(guide) end) then
      pack.counts.guides = pack.counts.guides + 1
    else
      pack.counts.rejected = pack.counts.rejected + 1
    end
  end
  return h
end

function PK:Register(manifest)
  local ok, errs = self:Validate(manifest)
  if not ok then
    local id = type(manifest) == "table" and tostring(manifest.id) or "?"
    ns.Diag:Warn("pack", "rejected " .. id .. ": " .. table.concat(errs, "; "))
    self.rejected[#self.rejected + 1] = { id = id, reason = errs[1] }
    return nil, errs
  end
  local pack = {
    id = manifest.id, manifest = U.deepcopy(manifest), errors = {},
    counts = { quests = 0, guides = 0, names = 0, rejected = 0 },
  }
  pack.handle = handle(pack)
  self.packs[pack.id] = pack
  self.order[#self.order + 1] = pack.id
  return pack.handle
end

-- A registered pack's handle, for its other files; nil when the pack was rejected (its files then add nothing).
function PK:Open(id)
  local pack = self.packs[id]
  return pack and pack.handle or nil
end

-- One line per pack, for /flc diag and the options window.
function PK:Summary()
  local out = {}
  for _, id in ipairs(self.order) do
    local p = self.packs[id]
    local m = p.manifest
    out[#out + 1] = string.format("%s %s (%s; license: %s): %d quests, %d guides%s%s", id, m.version, m.author, m.license,
      p.counts.quests, p.counts.guides, p.counts.rejected > 0 and (", " .. p.counts.rejected .. " rejected") or "",
      #p.errors > 0 and (", " .. #p.errors .. " errors") or "")
  end
  return out
end

-- The public API other addons see as the global FLC_Packs (methods take the table itself: FLC_Packs:Register(m)).
PK.public = {
  API_VERSION = 1,
  FORMAT = PK.FORMAT,
  Register = function(_, manifest) return PK:Register(manifest) end,
  Open = function(_, id) return PK:Open(id) end,
  List = function() return PK:Summary() end,
}

-- Guide-pack addons load after FLC (## Dependencies: ForeverLevelingCompanion) and find the API as a global.
ns.API.Export("FLC_Packs", PK.public)
