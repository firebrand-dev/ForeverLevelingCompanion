-- Class Quest Advisor (docs/CLASS_QUEST_ADVISOR.md): quest chains whose reward matters for the character's class (an
-- ability, a pet, a form, a weapon or item well above what quests of that level give), from the catalog pack
-- (tools/catalog/advisor.py rates them from the quest catalog and the client's own item and spell tables).
--
-- At run time this module:
--   * keeps the chains the character can take now (class, race, faction, level, not done);
--   * lowers a reward to "superseded" when what the character wears is already as good (when the client lets us read
--     the equipped items; otherwise the generator's tier stands and the UI says it could not compare);
--   * remembers the player's decision per chain: now, later or skip (FLC_CharDB.advisor, survives /reload);
--   * says which one chain is worth a notice now, weighing the tier against the detour.
-- Pure logic: gear and position come in as arguments (UI and Compat read them).
local _, ns = ...
local U = ns.U

local AD = { entries = {}, byId = {} }
ns.Advisor = AD

AD.TIERS = { superseded = 0, optional = 1, recommended = 2, ["very-recommended"] = 3, critical = 4 }
AD.LATER_LEVELS = 2       -- a postponed chain comes back this many levels later ...
AD.NEAR_YARDS = 800       -- ... or when the player is this close to where it starts ...
AD.DETOUR_YARDS = 1500    -- a "recommended" chain is offered only this close (same continent)
AD.OUTGROWN = 10          -- an item reward from a quest this many levels below the character is outgrown

-- The same weights as tools/catalog/advisor.py (per point; generic, refined by specialisation below).
AD.WEIGHTS = {
  WARRIOR = { strength = 1.0, agility = 0.7, stamina = 0.6, ["attack-power"] = 0.5, defense = 0.5 },
  PALADIN = { strength = 1.0, intellect = 0.7, stamina = 0.6, agility = 0.4, spirit = 0.3, healing = 0.5,
    ["spell-power"] = 0.5, ["attack-power"] = 0.4 },
  HUNTER = { agility = 1.0, stamina = 0.6, intellect = 0.4, ["attack-power"] = 0.4, ["ranged-attack-power"] = 0.5 },
  ROGUE = { agility = 1.0, strength = 0.5, stamina = 0.6, ["attack-power"] = 0.5 },
  PRIEST = { intellect = 1.0, spirit = 0.8, stamina = 0.5, healing = 0.8, ["spell-damage"] = 0.8, ["spell-power"] = 0.8,
    ["school-spell-damage"] = 0.5 },
  SHAMAN = { intellect = 0.9, strength = 0.6, agility = 0.5, stamina = 0.6, spirit = 0.4, healing = 0.6,
    ["spell-power"] = 0.6, ["attack-power"] = 0.4 },
  MAGE = { intellect = 1.0, spirit = 0.5, stamina = 0.5, ["spell-damage"] = 1.0, ["spell-power"] = 1.0,
    ["school-spell-damage"] = 0.7 },
  WARLOCK = { intellect = 0.8, stamina = 0.8, spirit = 0.4, ["spell-damage"] = 1.0, ["spell-power"] = 1.0,
    ["school-spell-damage"] = 0.7 },
  DRUID = { intellect = 0.8, spirit = 0.6, stamina = 0.6, strength = 0.5, agility = 0.6, healing = 0.7,
    ["spell-power"] = 0.7 },
}
-- Specialisations that change what a hybrid wants (talent tab with the most points; classic tab order).
AD.CASTER_SPEC = { DRUID = { [1] = true, [3] = true }, SHAMAN = { [1] = true, [3] = true }, PALADIN = { [1] = true } }
AD.CASTER_WEIGHTS = { intellect = 1.0, spirit = 0.6, stamina = 0.5, healing = 0.9, ["spell-power"] = 0.9,
  ["spell-damage"] = 0.8 }
-- whose weapon DPS counts (tools/catalog/advisor.py): melee classes but druids (forms) and hunters (their ranged
-- weapon counts instead); casters count a wand's DPS
AD.MELEE = { WARRIOR = true, PALADIN = true, ROGUE = true, SHAMAN = true }
AD.WAND_CLASSES = { PRIEST = true, MAGE = true, WARLOCK = true }
AD.WEAPON_STATS = { strength = true, agility = true, ["attack-power"] = true }
AD.STAT_DPS = 2 / 14
-- Equipment slot of each reward slot (the inventory slot ids of the client).
AD.SLOTS = { head = { 1 }, neck = { 2 }, shoulder = { 3 }, chest = { 5 }, waist = { 6 }, legs = { 7 }, feet = { 8 },
  wrist = { 9 }, hands = { 10 }, finger = { 11, 12 }, trinket = { 13, 14 }, back = { 15 }, ["main-hand"] = { 16 },
  ["one-hand"] = { 16 }, ["two-hand"] = { 16 }, ["off-hand"] = { 17 }, shield = { 17 }, ["held-in-off-hand"] = { 17 },
  ranged = { 18 }, thrown = { 18 } }

-- Chains that give the same thing (the racial variants of a class quest, exclusive alternatives) share a group:
-- one notice and one decision for all of them. The group is the taught spells, else the reward items.
function AD.GroupKey(e)
  local ids = {}
  for _, sp in ipairs(e.spells or {}) do
    for _, id in ipairs(sp.teachIDs or {}) do ids[#ids + 1] = "s" .. id end
  end
  if #ids == 0 then
    for _, c in pairs(e.classes or {}) do
      for _, it in ipairs(c.items or {}) do if it.id then ids[#ids + 1] = "i" .. it.id end end
    end
  end
  if #ids == 0 then return e.id end
  table.sort(ids)
  local out, last = {}, nil
  for _, v in ipairs(ids) do if v ~= last then out[#out + 1] = v end last = v end
  return table.concat(out, ",")
end

function AD:Register(list)
  local n = 0
  self.groups = self.groups or {}
  for _, e in ipairs(type(list) == "table" and list or {}) do
    if type(e) == "table" and type(e.id) == "string" and type(e.quest) == "number" and type(e.classes) == "table" then
      if not self.byId[e.id] then self.entries[#self.entries + 1] = e end
      self.byId[e.id] = e
      local key = AD.GroupKey(e)
      e.groupKey = key
      self.groups[key] = self.groups[key] or {}
      local g = self.groups[key]
      local seen = false
      for _, id in ipairs(g) do if id == e.id then seen = true end end
      if not seen then g[#g + 1] = e.id end
      n = n + 1
    end
  end
  self.cache = nil
  return n
end

-- Decisions per chain id: { state = "now" | "later" | "skip", level = <character level then>, at = <time> }.
function AD:Decisions()
  local char = ns.Session and ns.Session.char
  if not char then return {} end
  char.advisor = type(char.advisor) == "table" and char.advisor or {}
  char.advisor.decisions = type(char.advisor.decisions) == "table" and char.advisor.decisions or {}
  return char.advisor.decisions
end

-- A decision covers the chain's whole group (its variants). ctx.waiting is kept: "Later" said while the guide waits
-- does not come back merely because the guide still waits.
function AD:Decide(id, state, level, ctx)
  local e = self.byId[id]
  if not e then return false end
  local d = self:Decisions()
  for _, gid in ipairs((self.groups or {})[e.groupKey or ""] or { id }) do
    d[gid] = state and { state = state, level = level, at = ns.Now and ns.Now() or 0,
      waiting = ctx and ctx.waiting or false } or nil
  end
  self.cache = nil
  if ns.Bus then ns.Bus:Fire("ADVISOR_CHANGED", id, state) end
  return true
end

function AD.Weights(class, spec)
  if spec and AD.CASTER_SPEC[class] and AD.CASTER_SPEC[class][spec] then return AD.CASTER_WEIGHTS, true end
  return AD.WEIGHTS[class] or {}, false
end

function AD.StatScore(weights, stats)
  local s = 0
  for k, v in pairs(stats or {}) do s = s + (weights[k] or 0) * v end
  return s
end

-- What an item is worth to the character: weapons by DPS plus stats (melee), everything else by weighted stats.
-- `custom` (optional): the player's own stat priorities ({ stat = weight }) instead of the class's (Loot Advisor).
function AD.ItemScore(item, class, spec, custom)
  local w, caster = AD.Weights(class, spec)
  if custom then w = custom end
  local stats = AD.StatScore(w, item.stats)
  if item.dps and AD.MELEE[class] and not caster then
    local offensive = 0
    for k, v in pairs(item.stats or {}) do if AD.WEAPON_STATS[k] then offensive = offensive + (w[k] or 0) * v end end
    return item.dps + offensive * AD.STAT_DPS, "weapon"
  end
  if item.dps and AD.WAND_CLASSES[class] and (item.weapon == "wand" or item.slot == "ranged") then
    return item.dps + stats * AD.STAT_DPS, "weapon"
  end
  return stats, "stats"
end

-- Compares an item reward with what is equipped in its slot. gear[slotId] = { dps = n, stats = {...} } or false
-- (empty slot) or nil (not readable). Returns "better", "superseded" or nil (cannot tell).
AD.OFF_HAND = { ["off-hand"] = true, shield = true, ["held-in-off-hand"] = true }

function AD.CompareItem(item, gear, class, spec, custom)
  local slots = AD.SLOTS[item.slot or ""]
  if not slots or not gear then return nil end
  local mainHand = gear[16]
  if AD.OFF_HAND[item.slot] and mainHand and mainHand.equipLoc == "INVTYPE_2HWEAPON" then
    return nil       -- the off-hand is empty because a two-hander is worn: not a free slot, and not comparable
  end
  local mine, any = nil, false
  for _, sid in ipairs(slots) do
    local g = gear[sid]
    if g == nil then return nil end                  -- one slot not readable: no verdict
    if g == false then return "better" end           -- an empty slot: anything usable helps
    any = true
    local sc = AD.ItemScore(g, class, spec, custom)
    if mine == nil or sc < mine then mine = sc end    -- two rings or trinkets: the weaker one would be replaced
  end
  if not any then return nil end
  if item.slot == "two-hand" and gear[17] then       -- a two-hander replaces the main hand and the off-hand
    mine = mine + AD.ItemScore(gear[17], class, spec, custom)
  elseif item.slot == "two-hand" and gear[17] == nil and not (mainHand and mainHand.equipLoc == "INVTYPE_2HWEAPON") then
    return nil
  end
  local reward = AD.ItemScore(item, class, spec, custom)
  if reward <= 0 and mine <= 0 then return nil end
  return reward > mine * 1.05 and "better" or "superseded", reward, mine
end

-- The chain's evaluation for a subject (or nil when it does not apply): { entry, tier, base, reasons, items, compared }.
-- known(spellName) -> true/false/nil tells whether the character already has a spell.
function AD:Evaluate(e, subject, gear, spec, known)
  local cls = e.classes[subject.class or ""]
  if not cls then return nil end
  if e.faction and subject.faction and e.faction ~= subject.faction then return nil end
  if e.raceIDs and subject.raceID and not U.contains(e.raceIDs, subject.raceID) then return nil end
  local level = subject.level or 1
  if level < (e.minLevel or 1) then return nil end
  -- a chain whose quest this catalog does not have (removed, disabled or another catalog version) is not offered
  if ns.Quest and not ns.Quest:Meta(e.quest) then return nil end
  if subject.IsCompleted and subject:IsCompleted(e.quest) == true then return nil end
  -- an exclusive alternative already done or taken (the same reward from another giver)
  local meta = ns.Quest and ns.Quest:Meta(e.quest)
  for _, x in ipairs(meta and meta.exclusive or {}) do
    if (subject.IsCompleted and subject:IsCompleted(x) == true) or (subject.IsOnQuest and subject:IsOnQuest(x) == true) then
      return nil
    end
  end
  local out = { entry = e, base = cls.tier, tier = cls.tier, reasons = cls.reasons or {}, items = {}, compared = false }
  -- abilities the character already has (a racial or trainer version) make a spell reward superseded
  local spells, haveAll = 0, true
  for _, sp in ipairs(e.spells or {}) do
    for i, name in ipairs(sp.teaches or {}) do
      spells = spells + 1
      if known and known(name, sp.teachIDs and sp.teachIDs[i]) ~= true then haveAll = false end
    end
  end
  local itemVerdicts, better, unknown = 0, 0, 0
  for _, it in ipairs(cls.items or {}) do
    local outgrown = level - (e.level or level) >= AD.OUTGROWN
    local v = outgrown and "outgrown" or AD.CompareItem(it, gear, subject.class, spec)
    out.items[#out.items + 1] = { item = it, verdict = v }
    if it.tier and it.tier ~= "optional" then
      itemVerdicts = itemVerdicts + 1
      if v == "better" then better = better + 1 elseif v == nil then unknown = unknown + 1 end
      if v ~= "outgrown" and v ~= nil then out.compared = true end
    end
  end
  out.outgrown = itemVerdicts > 0 and better == 0 and unknown == 0 and true or nil
  local spellsDone = spells > 0 and known ~= nil and haveAll
  if (spells == 0 or spellsDone) and itemVerdicts > 0 and better == 0 and unknown == 0 then out.tier = "superseded" end
  if spells > 0 and spellsDone and itemVerdicts == 0 then out.tier = "superseded" end
  return out
end

-- Every chain that applies to the subject, best first.
-- Every chain that applies to the subject, best first; ties go to the nearest start. Of a group (variants of the same
-- reward) only the best placed one is kept.
function AD:Candidates(subject, gear, spec, known, pos)
  local all = {}
  for _, e in ipairs(self.entries) do
    local ev = self:Evaluate(e, subject, gear, spec, known)
    if ev then
      ev.distance = AD.Distance(e, pos)
      all[#all + 1] = ev
    end
  end
  table.sort(all, function(a, b)
    local ta, tb = AD.TIERS[a.tier] or 0, AD.TIERS[b.tier] or 0
    if ta ~= tb then return ta > tb end
    local da, db = a.distance or math.huge, b.distance or math.huge
    if da ~= db then return da < db end
    if (a.entry.minLevel or 0) ~= (b.entry.minLevel or 0) then return (a.entry.minLevel or 0) < (b.entry.minLevel or 0) end
    return a.entry.id < b.entry.id
  end)
  local out, seen = {}, {}
  for _, ev in ipairs(all) do
    local k = ev.entry.groupKey or ev.entry.id
    if not seen[k] then
      seen[k] = true
      out[#out + 1] = ev
    end
  end
  return out
end

-- Distance in yards from the player to where the chain starts (same continent), or nil.
function AD.Distance(e, pos)
  local l = e.start and e.start.loc
  if not (pos and l and l.cont ~= nil and pos.cont == l.cont) then return nil end
  local dx, dy = (pos.wx or 0) - l.wx, (pos.wy or 0) - l.wy
  return math.sqrt(dx * dx + dy * dy)
end

-- The one chain worth telling the player about now, or nil. ctx = { pos = world position, waiting = true when the
-- guide waits for a level or is complete }. Weighs the tier against the detour; a decision of the player wins.
function AD:Notice(subject, gear, spec, known, ctx)
  ctx = ctx or {}
  local decisions = self:Decisions()
  for _, ev in ipairs(self:Candidates(subject, gear, spec, known, ctx.pos)) do
    local e, rank = ev.entry, AD.TIERS[ev.tier] or 0
    local d = decisions[e.id]
    local dist = ev.distance
    local ok = rank >= AD.TIERS.recommended
    if ok and d then
      if d.state == "skip" or d.state == "now" then ok = false
      elseif d.state == "later" then
        -- near the start again only counts once the player went away (postponed next to the NPC: not again at
        -- once); with no position at all (loading screen, instance) nothing is known, so nothing changes
        if ctx.pos and (dist == nil or dist > AD.NEAR_YARDS * 1.5) then d.away = true end
        -- the guide waiting counts only when it started waiting after the decision
        if not ctx.waiting then d.waiting = false end
        ok = (subject.level or 0) >= (d.level or 0) + AD.LATER_LEVELS or (d.away and dist and dist <= AD.NEAR_YARDS)
          or (ctx.waiting and d.waiting == false and d.away) or false
      end
    end
    if ok and rank == AD.TIERS.recommended then
      ok = (dist ~= nil and dist <= AD.DETOUR_YARDS) or ctx.waiting
    end
    if ok and rank == AD.TIERS["very-recommended"] and dist == nil and not ctx.waiting then
      -- another continent: worth saying when the guide pauses (a level to wait for, a finished route)
      ok = (subject.level or 0) >= (e.minLevel or 0) + 2
    end
    if ok then return ev, dist end
  end
  return nil
end

-- The detour route for a chain: every quest of the chain the subject has not done, in chain order (accept, the
-- objectives, turn in), with the catalog's locations. Returns a guide for a Session detour.
function AD:BuildRoute(e, subject, guides)
  local RE = ns.Route
  local steps = {}
  -- a class can have its own chain (its alternative of an "any of" prerequisite)
  local own = e.classes and e.classes[subject.class or ""]
  for _, qid in ipairs((own and own.chain) or e.chain or { e.quest }) do
    if not (subject.IsCompleted and subject:IsCompleted(qid) == true) then
      local onQuest = subject.IsOnQuest and subject:IsOnQuest(qid)
      if onQuest ~= true then
        steps[#steps + 1] = { id = "q" .. qid .. ":accept", type = "accept", quest = qid, loc = RE.LocFor(qid, "accept", guides), status = "generated" }
      end
      local meta = ns.Quest:Meta(qid)
      if meta and meta.objectives and #meta.objectives > 0 then
        steps[#steps + 1] = { id = "q" .. qid .. ":work", type = "complete", quest = qid, loc = RE.LocFor(qid, "complete", guides), status = "generated" }
      end
      steps[#steps + 1] = { id = "q" .. qid .. ":turnin", type = "turnin", quest = qid, loc = RE.LocFor(qid, "turnin", guides), status = "generated" }
    end
  end
  if #steps == 0 then return nil end
  for _, s in ipairs(steps) do
    if s.loc and not ns.Guide.ValidLoc(s.loc) then s.loc = nil end
  end
  local g = { id = "advisor." .. e.id, title = e.title or ("Quest " .. e.quest), kind = "detour", status = "generated", steps = steps }
  return ns.Guide:Prepare(g)
end
