-- Party quest announcements. Distinguishes objective complete / all objectives complete / turned in.
-- Off by default for single kills; deduplicated; rate limited; respects chat lockdown.
-- Modes: off | objectives | pct25 | pct50 | every | default (objectives + ready to turn in)
local _, ns = ...
local L = ns.L

local A = {
  queue = {},
  sent = {},            -- dedupe keys already announced
  lastSent = nil,
  burst = 3,
  tokens = 3,
  lastRefill = nil,
  everyInterval = 5,    -- "every" mode: minimum seconds between messages for the same objective
  lastEvery = {},
  maxAge = 30,          -- drop queued lines older than this (e.g. stuck in a lockdown)
}
ns.Announcer = A

local READY_MODES = { default = true, pct25 = true, pct50 = true, every = true }

function A:Mode() return ns.Config:Get("announce.mode") or "default" end

local function label(text, qid)
  if text and text ~= "" then return text end
  return ns.Quest:Name(qid)
end

local function prefixed(msg)
  local p = ns.Config:Get("announce.prefix")
  if p and p ~= "" then return p .. " " .. msg end
  return msg
end

-- Queues a line once per dedupe key. coalesce replaces older queued lines with the same key.
function A:Push(key, msg, now, coalesce, notBefore)
  if key and self.sent[key] then return false end
  if coalesce then
    for i = #self.queue, 1, -1 do if self.queue[i].coalesce == coalesce then table.remove(self.queue, i) end end
  end
  self.queue[#self.queue + 1] = { key = key, text = prefixed(msg), at = now, coalesce = coalesce, notBefore = notBefore }
  if key then self.sent[key] = true end
  return true
end

-- Forget dedupe keys of a quest when it is accepted again (abandon + re-accept).
function A:ForgetQuest(qid)
  local pat = "^" .. qid .. ":"
  for k in pairs(self.sent) do
    if string.find(k, pat) then self.sent[k] = nil end
  end
  for k in pairs(self.lastEvery) do
    if string.find(k, pat) then self.lastEvery[k] = nil end
  end
end

function A:OnProgress(qid, idx, old, new, need, text, now)
  local mode = self:Mode()
  if mode == "off" or not need or need <= 0 then return end
  if new >= need then return end -- completion has its own message
  local name = label(text, qid)
  if mode == "every" then
    local k = qid .. ":" .. idx
    local last = self.lastEvery[k]
    -- Coalesce: only the newest value per objective waits in the queue, and never more
    -- often than everyInterval for the same objective.
    local notBefore = last and (last + self.everyInterval) or now
    self:Push(nil, string.format(L["%s: %d/%d"], name, new, need), now, "every:" .. k, notBefore)
  elseif mode == "pct25" or mode == "pct50" then
    local step = mode == "pct25" and 25 or 50
    local before = math.floor(old * 100 / need / step)
    local after = math.floor(new * 100 / need / step)
    if after > before and after * step < 100 then
      self:Push(qid .. ":" .. idx .. ":pct" .. after * step,
        string.format(L["%s: %d/%d (%d%%)"], name, new, need, after * step), now)
    end
  end
end

function A:OnObjectiveComplete(qid, idx, have, need, text, now)
  if self:Mode() == "off" then return end
  self:Push(qid .. ":" .. idx .. ":done", string.format(L["%s: %d/%d - objective complete"], label(text, qid), have or need or 0, need or 0), now, "every:" .. qid .. ":" .. idx)
end

function A:OnReady(qid, title, now)
  if not READY_MODES[self:Mode()] then return end
  self:Push(qid .. ":ready", string.format(L["%s - all objectives complete"], title or ns.Quest:Name(qid)), now)
end

function A:OnTurnedIn(qid, title, now)
  if self:Mode() == "off" or not ns.Config:Get("announce.turnIn") then return end
  self:Push(qid .. ":turnin", string.format(L["%s - quest turned in"], title or ns.Quest:Name(qid)), now)
  -- Allows announcing again if the quest is repeatable.
  self:ForgetQuest(qid)
  self.sent[qid .. ":turnin"] = true
end

-- Sends at most one line per call, respecting min interval, burst and lockdown.
-- `send` is injectable for tests.
function A:Flush(now, send)
  send = send or ns.API.SendChat
  if #self.queue == 0 then return 0 end
  local channel = ns.API.GetGroupChannel()
  if not channel then
    self.queue = {}
    return 0
  end
  -- Drop lines that waited too long; they are no longer news.
  for i = #self.queue, 1, -1 do
    if now - self.queue[i].at > self.maxAge then table.remove(self.queue, i) end
  end
  local interval = ns.Config:Get("announce.minInterval") or 2
  if not self.lastRefill then self.lastRefill = now end
  self.tokens = math.min(self.burst, self.tokens + (now - self.lastRefill) / interval)
  self.lastRefill = now
  if self.tokens < 1 then return 0 end
  local pick
  for i, q in ipairs(self.queue) do
    if not q.notBefore or q.notBefore <= now then pick = i; break end
  end
  if not pick then return 0 end
  local line = self.queue[pick]
  local result = send(line.text, channel)
  if result == "lockdown" then
    ns.Diag:Count("announce.lockdown")
    return 0
  end
  table.remove(self.queue, pick)
  if line.coalesce then
    local k = string.match(line.coalesce, "^every:(.+)$")
    if k then self.lastEvery[k] = now end
  end
  self.tokens = self.tokens - 1
  self.lastSent = now
  if result ~= "ok" then ns.Diag:Warn("announce", "send failed: " .. tostring(result)) end
  return 1
end

function A:Reset()
  self.queue, self.sent, self.lastEvery, self.tokens, self.lastRefill = {}, {}, {}, self.burst, nil
end

ns.Bus:On("TRACKER_OBJECTIVE_PROGRESS", A, function(qid, idx, old, new, need, text) A:OnProgress(qid, idx, old, new, need, text, ns.Now()) end)
ns.Bus:On("TRACKER_OBJECTIVE_COMPLETE", A, function(qid, idx, have, need, text) A:OnObjectiveComplete(qid, idx, have, need, text, ns.Now()) end)
ns.Bus:On("TRACKER_QUEST_READY", A, function(qid, title) A:OnReady(qid, title, ns.Now()) end)
ns.Bus:On("TRACKER_QUEST_TURNED_IN", A, function(qid, title) A:OnTurnedIn(qid, title, ns.Now()) end)
ns.Bus:On("TRACKER_QUEST_ADDED", A, function(qid) A:ForgetQuest(qid) end)
