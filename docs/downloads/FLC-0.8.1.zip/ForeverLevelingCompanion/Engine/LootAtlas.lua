-- FLC Loot Atlas (docs/LOOT_ATLAS.md): the dungeons' loot from the pack (tools/catalog/atlas_pack.py) to browse by
-- instance (bosses, rare world drops, quest rewards) or by character (class, specialisation, slot: the items it can
-- use, rated by the Loot Advisor's scoring), searched and filtered, with a wishlist per character: want, interested,
-- got, hidden. The wishlist feeds the Dungeon Quest Advisor (a dungeon holding a wanted item). Built in memory on first
-- use. No drop chance, no need/greed decision; every rating is an estimate from stat weights. Pure logic.
local _, ns = ...

local LT = {}
ns.LootAtlas = LT

LT.STATES = { "want", "interest", "got", "hide" }
LT.QUALITY = { [0] = "poor", "common", "uncommon", "rare", "epic", "legendary" }

function LT:Register(loader)
  if type(loader) == "function" then self.loader, self.data, self.index = loader, nil, nil
  elseif type(loader) == "table" then self.loader, self.data, self.index = nil, loader, nil end
  return true
end

-- The pack's atlas, built on first use, with where each item comes from:
-- index[id] = { { instance, kind = "boss" | "world" | "quest", boss = name, encounter, quest, title }, ... }
function LT:Data()
  if not self.data and self.loader then
    local ok, d = pcall(self.loader)
    self.data = ok and type(d) == "table" and d or nil
    self.loader = nil
  end
  self.data = self.data or { instances = {}, items = {} }
  if not self.index then
    local idx = {}
    local function add(id, src) idx[id] = idx[id] or {}; idx[id][#idx[id] + 1] = src end
    for did, inst in pairs(self.data.instances or {}) do
      for _, b in ipairs(inst.bosses or {}) do
        for _, id in ipairs(b.items or {}) do
          add(id, { instance = did, kind = "boss", boss = self:BossName(b), bossEn = b.name, encounter = b.encounter })
        end
      end
      for _, id in ipairs(inst.world or {}) do add(id, { instance = did, kind = "world" }) end
      for _, q in ipairs(inst.quests or {}) do
        for _, id in ipairs(q.items or {}) do add(id, { instance = did, kind = "quest", quest = q.quest, title = q.title }) end
      end
    end
    self.index = idx
  end
  return self.data
end

-- A boss's name in the player's language: its creature's (LT.localNpc, the pack's names set by the UI) when the pack
-- gives the creature (the encounter has its name), else the game's encounter name in English.
function LT:BossName(b)
  local n = b.npc and self.localNpc and self.localNpc(b.npc)
  return (type(n) == "string" and n ~= "") and n or b.name
end

function LT:Item(id) return self:Data().items[id] end
function LT:Sources(id) self:Data(); return self.index[id] or {} end

-- Instances sorted by tuning level: { { id, inst } }; kind "dungeon" or "raid" keeps only those (nil: all).
function LT:Instances(kind)
  local list = {}
  for did, inst in pairs(self:Data().instances or {}) do
    if not kind or (inst.kind or "dungeon") == kind then list[#list + 1] = { id = did, inst = inst } end
  end
  table.sort(list, function(a, b)
    if (a.inst.tuning or 99) ~= (b.inst.tuning or 99) then return (a.inst.tuning or 99) < (b.inst.tuning or 99) end
    return a.id < b.id
  end)
  return list
end

----------------------------------------------------------------------
-- Wishlist (per character)
----------------------------------------------------------------------
local function wishes()
  local char = ns.Session and ns.Session.char
  if not char then return nil end
  char.wishlist = type(char.wishlist) == "table" and char.wishlist or {}
  return char.wishlist
end

function LT:Wish(id)
  local w = wishes()
  return w and w[id] or nil
end

function LT:SetWish(id, state)
  local w = wishes()
  if not w or type(id) ~= "number" then return false end
  if state ~= nil and not ns.U.contains(LT.STATES, state) then return false end
  w[id] = state
  if ns.Bus then ns.Bus:Fire("WISHLIST_CHANGED", id, state) end
  return true
end

-- The next state of the item's toggle: none -> want -> interest -> got -> hide -> none.
function LT:CycleWish(id)
  local cur, nxt = self:Wish(id), nil
  if cur == nil then nxt = "want" else
    for i, s in ipairs(LT.STATES) do if s == cur then nxt = LT.STATES[i + 1] end end
  end
  self:SetWish(id, nxt)
  return nxt
end

-- Items of a dungeon on the wishlist as wanted or interesting (not got, not hidden): { { id, rec, src } }.
function LT:WishlistIn(dungeonID)
  local w, out = wishes(), {}
  if not w then return out end
  for id, state in pairs(w) do
    if state == "want" or state == "interest" then
      for _, src in ipairs(self:Sources(id)) do
        if src.instance == dungeonID then
          out[#out + 1] = { id = id, rec = self:Item(id), src = src, state = state }
          break
        end
      end
    end
  end
  table.sort(out, function(a, b) return a.id < b.id end)
  return out
end

----------------------------------------------------------------------
-- Search and filters
----------------------------------------------------------------------
local function lower(s) return string.lower(s or "") end

-- The level an item can be had at: its required level, or the level of the easiest place it comes from (the
-- dungeon's tuning level) when that is higher. Many dungeon set pieces and quest rewards have required level 0 in
-- the client's tables (Darkmantle Cap, a Blackrock Spire quest's reward, was offered at level 15: run 20261029-080343).
function LT:ObtainLevel(id, rec)
  local at
  for _, src in ipairs(self:Sources(id)) do
    local inst = self:Data().instances[src.instance]
    local t = inst and inst.tuning
    if t and (not at or t < at) then at = t end
  end
  return math.max(rec.rl or 0, at or 0)
end

-- The item's name in the player's language when the client has it (LT.localName, set from the client by the UI),
-- else the pack's English name.
function LT:Name(id, rec)
  local n = self.localName and self.localName(id)
  return n or (rec and rec.n) or ("#" .. tostring(id))
end

-- q = { text, slot, minQuality, maxLevel (obtainable level at most), class + level (usable by), wish = state | "any" |
-- "none", stat, instance, boss (encounter) }. Hidden items are left out unless q.wish == "hide".
-- Returns { { id, rec } } by quality, then item level (high first), then name.
function LT:Search(q)
  q = q or {}
  local data = self:Data()
  local text = q.text and q.text ~= "" and lower(q.text) or nil
  local out = {}
  for id, rec in pairs(data.items or {}) do
    local ok = true
    local wish = self:Wish(id)
    if wish == "hide" and q.wish ~= "hide" then ok = false end
    if ok and q.wish == "any" and not wish then ok = false end
    if ok and q.wish and q.wish ~= "any" and q.wish ~= "none" and wish ~= q.wish then ok = false end
    if ok and q.slot and rec.slot ~= q.slot then ok = false end
    if ok and q.minQuality and (rec.q or 0) < q.minQuality then ok = false end
    if ok and q.maxLevel and self:ObtainLevel(id, rec) > q.maxLevel then ok = false end
    if ok and q.class and not ns.LootAdvisor.CanUse(rec, q.class, q.level or 60) then ok = false end
    if ok and q.stat and not (rec.st and rec.st[q.stat]) then ok = false end
    if ok and (q.instance or q.boss or text) then
      -- the English name or the player's language's (only items the client has loaded: the search asks for none)
      local localName = text and self.localName and self.localName(id, true)
      local hit = text and (string.find(lower(rec.n or ""), text, 1, true) ~= nil
        or (localName ~= nil and string.find(lower(localName), text, 1, true) ~= nil))
      local inPlace = not (q.instance or q.boss)
      for _, src in ipairs(self:Sources(id)) do
        if (not q.instance or src.instance == q.instance) and (not q.boss or src.encounter == q.boss) then inPlace = true end
        if text and not hit then
          local inst = data.instances[src.instance]
          if (src.boss and string.find(lower(src.boss), text, 1, true)) or (src.bossEn and string.find(lower(src.bossEn), text, 1, true))
            or (inst and string.find(lower(inst.name), text, 1, true)) then
            hit = true
          end
        end
      end
      ok = inPlace and (not text or hit)
    end
    if ok then out[#out + 1] = { id = id, rec = rec } end
  end
  table.sort(out, function(a, b)
    if (a.rec.q or 0) ~= (b.rec.q or 0) then return (a.rec.q or 0) > (b.rec.q or 0) end
    if (a.rec.il or 0) ~= (b.rec.il or 0) then return (a.rec.il or 0) > (b.rec.il or 0) end
    return (a.rec.n or "") < (b.rec.n or "")
  end)
  return out
end

-- By character: the items of a slot the character (or a planned class and specialisation) can use up to `level` +
-- LEVEL_AHEAD, rated by the Loot Advisor's scoring (its stat priorities or the class's) and, with equipment, compared
-- to it. { { id, rec, score, verdict, gain, confidence } } by score.
function LT:ForCharacter(state, gear, spec, slot)
  local LA, AD = ns.LootAdvisor, ns.Advisor
  local level = (state.level or 1) + LA.LEVEL_AHEAD
  local out = {}
  for _, hit in ipairs(self:Search({ slot = slot, class = state.class, level = level, maxLevel = level })) do
    local item = { slot = hit.rec.slot, dps = hit.rec.dps, stats = hit.rec.st, weapon = hit.rec.w }
    local r = { id = hit.id, rec = hit.rec, score = AD.ItemScore(item, state.class, spec, LA:CustomWeights()) }
    if gear then
      local rated = LA:Rate(hit.id, hit.rec, nil, state, gear, spec)
      r.verdict, r.gain, r.confidence = rated.verdict, rated.gain, rated.confidence
    end
    out[#out + 1] = r
  end
  table.sort(out, function(a, b)
    if a.score ~= b.score then return a.score > b.score end
    return a.id < b.id
  end)
  return out
end
