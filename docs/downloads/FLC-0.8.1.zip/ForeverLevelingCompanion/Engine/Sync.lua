-- Glue between client events and engines, kept free of frame code so the offline harness can
-- drive several simulated clients through exactly the same paths as Bootstrap.lua.
local _, ns = ...

local Sync = { inGroup = false }
ns.Sync = Sync

function Sync:RefreshSelf(now)
  local prev = ns.Session.selfState
  local state = ns.Quest:BuildSelfState(prev)
  ns.Session:SetSelfState(state)
  return ns.Tracker:Update(state.log, now)
end

function Sync:OnQuestTurnedIn(qid, now)
  ns.Config.char.turnedIn[qid] = ns.API.WallTime() or true   -- when: it only covers the server's lag window
  if ns.Session.selfState then ns.Session.selfState:MarkTurnedIn(qid) end
  ns.Tracker:OnTurnedIn(qid, now)
  ns.Party:SendTurnin(qid)
  ns.Recorder:OnTurnedIn(qid)
end

function Sync:OnLevelUp(level)
  if ns.Session.selfState then ns.Session.selfState.level = level end
  ns.Party:BroadcastState()
end

function Sync:RefreshRoster(now)
  ns.Party:UpdateRoster(ns.API.GetGroupRoster(), now)
  ns.Session:UpdateContext(ns.Party:Size())
  local inGroup = ns.API.IsInGroup()
  if inGroup and not self.inGroup then
    -- Just joined (or logged in grouped): introduce ourselves; data follows only with consent.
    ns.Party:SendHello(false)
  end
  self.inGroup = inGroup
end

-- Tracker -> party objective sync.
local function myObjective(qid, idx)
  local st = ns.Session.selfState
  local q = st and st.log[qid]
  return q and q.objectives[idx]
end

local function sendObjective(qid, idx)
  local o = myObjective(qid, idx)
  if o then ns.Party:SendObjective(qid, idx, o) end
end

ns.Bus:On("TRACKER_OBJECTIVE_PROGRESS", Sync, sendObjective)
ns.Bus:On("TRACKER_OBJECTIVE_REGRESS", Sync, sendObjective)
ns.Bus:On("TRACKER_OBJECTIVE_COMPLETE", Sync, sendObjective)
ns.Bus:On("TRACKER_QUEST_ADDED", Sync, function() ns.Party:BroadcastLog(ns.Session.selfState) end)
ns.Bus:On("TRACKER_QUEST_READY", Sync, function() ns.Party:BroadcastLog(ns.Session.selfState) end)
ns.Bus:On("TRACKER_QUEST_ABANDONED", Sync, function(qid) ns.Party:SendAbandon(qid) end)
