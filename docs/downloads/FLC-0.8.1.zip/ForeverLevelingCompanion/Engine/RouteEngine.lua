-- Route Engine: quest selection per preset/mode, risk and XP estimates, and travel ordering with
-- precedence (accept -> objectives -> turn in). Output routes are guide-shaped so the Guide Engine
-- can run them like any authored guide.
local _, ns = ...
local U = ns.U
local QE = ns.Quest
local Nav = ns.Nav

local RE = {}
ns.Route = RE

RE.PRESETS = {
  fastxp = { label = "Fast XP", minXP = 1, groupBonus = 0, dangerCap = "high" },
  balanced = { label = "Balanced", minXP = 0, groupBonus = 0.15, dangerCap = "high" },
  completionist = { label = "Completionist", minXP = 0, groupBonus = 0, dangerCap = "deadly" },
  dungeon = { label = "Dungeon Focus", minXP = 0, groupBonus = 0.1, dangerCap = "deadly" },
  hardcore = { label = "Hardcore Safe", minXP = 0, groupBonus = 0.15, dangerCap = "medium" },
}
local DANGER_RANK = { low = 1, medium = 2, high = 3, deadly = 4 }
RE.DANGER_RANK = DANGER_RANK

----------------------------------------------------------------------
-- Ordering
----------------------------------------------------------------------
local function feasible(task, doneSet)
  if not task.after then return true end
  for _, dep in ipairs(task.after) do
    if not doneSet[dep] then return false end
  end
  return true
end

local function validOrder(order, ids)
  local seen = {}
  for _, t in ipairs(order) do
    if t.after then
      for _, dep in ipairs(t.after) do
        if ids[dep] and not seen[dep] then return false end
      end
    end
    seen[t.id] = true
  end
  return true
end

function RE.TotalCost(order, start)
  local cost, pos = 0, start
  for _, t in ipairs(order) do
    if t.loc then
      if pos then cost = cost + Nav.Cost(pos, t.loc) end
      pos = t.loc
    end
  end
  return cost
end

-- Greedy nearest-feasible construction followed by relocate passes that keep precedence valid.
-- Dependencies on tasks that are not in the list are ignored (already satisfied elsewhere).
function RE.Order(tasks, start, opts)
  opts = opts or {}
  local ids = {}
  for _, t in ipairs(tasks) do ids[t.id] = true end
  local done = {}
  for _, t in ipairs(tasks) do
    if t.after then
      for _, dep in ipairs(t.after) do if not ids[dep] then done[dep] = true end end
    end
  end
  local remaining = U.copy(tasks)
  local order, pos = {}, start
  while #remaining > 0 do
    local bestI, bestCost
    for i, t in ipairs(remaining) do
      if feasible(t, done) then
        local c = (pos and t.loc) and Nav.Cost(pos, t.loc) or 0
        if t.priority then c = c - t.priority end
        if not bestCost or c < bestCost then bestI, bestCost = i, c end
      end
    end
    if not bestI then
      -- Dependency cycle in input data: append the rest in input order and report it.
      ns.Diag:Warn("route", "dependency cycle; " .. #remaining .. " tasks appended unordered")
      for _, t in ipairs(remaining) do order[#order + 1] = t end
      break
    end
    local t = table.remove(remaining, bestI)
    order[#order + 1] = t
    done[t.id] = true
    if t.loc then pos = t.loc end
  end

  local best = RE.TotalCost(order, start)
  local passes = opts.passes or 3
  for _ = 1, passes do
    local improved = false
    for i = 1, #order do
      for j = 1, #order do
        if i ~= j then
          local cand = U.copy(order)
          local t = table.remove(cand, i)
          table.insert(cand, j, t)
          if validOrder(cand, ids) then
            local c = RE.TotalCost(cand, start)
            if c + 0.01 < best then
              order, best, improved = cand, c, true
            end
          end
        end
      end
    end
    if not improved then break end
  end
  return order, best
end

----------------------------------------------------------------------
-- Risk and value
----------------------------------------------------------------------
-- Estimated danger for a party of `size` whose lowest level is `minLevel`.
function RE.Danger(meta, minLevel, size)
  if not meta or not minLevel then return "medium", true end
  local qL = meta.level or meta.minLevel or minLevel
  local need = meta.groupSize or (meta.elite and 3 or 1)
  local eff = (qL - minLevel) - (size - 1) * 1.5
  if meta.elite then eff = eff + math.max(0, need - size) * 2.5 + 1 end
  if meta.dungeon then eff = eff + math.max(0, 5 - size) * 1.5 end
  if eff <= 0 then return "low" end
  if eff <= 2 then return "medium" end
  if eff <= 4 then return "high" end
  return "deadly"
end

-- Hardcore Safe: no elite without a full group at level, nothing far above the weakest member.
function RE.HardcoreUnsafe(meta, minLevel, size)
  if not meta or not minLevel then return true end
  local qL = meta.level or meta.minLevel or minLevel
  if qL > minLevel + 2 then return true end
  if meta.elite and (size < (meta.groupSize or 3) or minLevel < qL) then return true end
  if meta.dungeon and size < 5 then return true end
  return false
end

function RE.QuestMinutes(meta)
  if meta and meta.minutes then return meta.minutes, false end
  local n = meta and meta.objectives and #meta.objectives or 1
  return 3 + n * 4, true
end

local function locOf(meta, which)
  if not meta then return nil end
  return meta[which] or meta.area or meta.start
end

-- Location of a quest action, preferring authored guide steps (verified data) over metadata.
function RE.LocFor(questID, stepType, guides)
  for _, g in ipairs(guides or {}) do
    for _, s in ipairs(g.steps) do
      if s.quest == questID and s.loc and (s.type == stepType or (stepType == "complete" and (s.type == "kill" or s.type == "collect"))) then
        return s.loc, s
      end
    end
  end
  local m = QE:Meta(questID)
  if stepType == "accept" then return locOf(m, "start") end
  if stepType == "turnin" then return locOf(m, "finish") end
  -- Generated catalog: objective locations are per objective (world coordinates).
  if m and m.objectives then
    for _, o in ipairs(m.objectives) do
      if o.loc then return o.loc end
    end
  end
  return locOf(m, "area")
end

----------------------------------------------------------------------
-- Group planning (Level Together / Group Catch-Up / Dungeon Focus)
----------------------------------------------------------------------
-- input = { members = { {key, name, state, level, stepsBehind} }, candidates = {questIDs},
--           preset, mode = "together"|"catchup", start = loc, max = n, guides = {guide,...} }
function RE.EvaluateQuest(questID, members, preset, mode, weights)
  local meta = QE:Meta(questID)
  local minLevel, size = 99, #members
  for _, m in ipairs(members) do if m.level and m.level < minLevel then minLevel = m.level end end
  local danger, dangerEstimated = RE.Danger(meta, minLevel, size)
  local soloDanger = RE.Danger(meta, minLevel, 1)
  local entry = {
    questID = questID, meta = meta, danger = danger, dangerEstimated = dangerEstimated,
    soloDanger = soloDanger, roles = {}, xp = {}, xpEstimated = false,
    beneficiaries = {}, unknown = {}, totalXP = 0, weightedXP = 0,
  }
  for _, m in ipairs(members) do
    local status, reasons = QE:Availability(m.state, questID)
    local role
    if QE:IsPending(status) then role = "progress"
    elseif status == "unknown" then role = "unknown"
    elseif status == "completed" then role = "help-completed"
    else role = "help-unavailable" end
    entry.roles[m.key] = { role = role, status = status, reasons = reasons }
    if role == "progress" then
      local xp, est = QE:QuestXP(questID, m.level)
      entry.xp[m.key] = xp
      entry.xpEstimated = entry.xpEstimated or est
      entry.totalXP = entry.totalXP + xp
      entry.weightedXP = entry.weightedXP + xp * ((weights and weights[m.key]) or 1)
      entry.beneficiaries[#entry.beneficiaries + 1] = m.key
    elseif role == "unknown" then
      entry.unknown[#entry.unknown + 1] = m.key
    end
  end
  local minutes, minutesEstimated = RE.QuestMinutes(meta)
  entry.minutes, entry.minutesEstimated = minutes, minutesEstimated
  -- Worth a group: dangerous or slow solo, comfortable with the current party.
  entry.groupWorthy = size > 1 and DANGER_RANK[soloDanger] >= 3 and DANGER_RANK[danger] <= 2
  local p = RE.PRESETS[preset] or RE.PRESETS.balanced
  local score
  if #entry.beneficiaries == 0 then
    score = nil
  elseif DANGER_RANK[danger] > DANGER_RANK[p.dangerCap] then
    score = nil
    entry.excluded = "danger"
  elseif preset == "hardcore" and RE.HardcoreUnsafe(meta, minLevel, size) then
    score = nil
    entry.excluded = "hardcore"
  elseif preset == "completionist" then
    score = 1 + #entry.beneficiaries
  else
    score = entry.weightedXP / minutes * (1 + p.groupBonus * (#entry.beneficiaries - 1))
    if preset == "dungeon" and meta and meta.dungeon then score = score * 3 end
    if preset == "fastxp" and entry.totalXP < p.minXP then score = nil end
    if entry.groupWorthy then score = (score or 0) * 1.25 end
  end
  entry.score = score
  return entry
end

-- Catch-up weights: members further behind count more, so shared routes favour them.
function RE.CatchUpWeights(members)
  local maxLevel = 0
  for _, m in ipairs(members) do if (m.level or 0) > maxLevel then maxLevel = m.level end end
  local w = {}
  for _, m in ipairs(members) do
    w[m.key] = 1 + math.max(0, maxLevel - (m.level or maxLevel)) * 0.5 + (m.stepsBehind or 0) / 20
  end
  return w
end

function RE.Laggards(members)
  local list = U.copy(members)
  table.sort(list, function(a, b)
    if (a.level or 0) ~= (b.level or 0) then return (a.level or 0) < (b.level or 0) end
    return (a.stepsBehind or 0) > (b.stepsBehind or 0)
  end)
  return list
end

local function candidateQuests(input)
  if input.candidates then return input.candidates end
  local set = {}
  for _, m in ipairs(input.members) do
    for qid in pairs(m.state.log) do set[qid] = true end
    if m.window then for _, qid in ipairs(m.window) do set[qid] = true end end
  end
  local list = U.keys(set)
  table.sort(list)
  return list
end

-- Builds the shared route. Returns a guide-shaped table with `plan` metadata.
function RE.PlanGroup(input)
  local preset = input.preset or "balanced"
  local mode = input.mode or "together"
  local weights = mode == "catchup" and RE.CatchUpWeights(input.members) or nil
  local evaluated, selected = {}, {}
  for _, qid in ipairs(candidateQuests(input)) do
    local e = RE.EvaluateQuest(qid, input.members, preset, mode, weights)
    evaluated[#evaluated + 1] = e
    if e.score and e.score > 0 then selected[#selected + 1] = e end
  end
  table.sort(selected, function(a, b)
    if a.score ~= b.score then return a.score > b.score end
    return a.questID < b.questID
  end)
  local max = input.max or 8
  while #selected > max do table.remove(selected) end

  local tasks = RE.TasksForQuests(selected, input)
  local ordered, travel = RE.Order(tasks, input.start)
  local route = RE.ToGuide(ordered, {
    id = "route:" .. mode .. ":" .. preset,
    title = RE.MODE_TITLE[mode] or mode,   -- shown through the locale ("Level together" / "Subir juntos")
    kind = mode,
  })
  local minutes, totals = travel / Nav.runSpeed / 60, {}
  for _, e in ipairs(selected) do
    minutes = minutes + e.minutes
    for key, xp in pairs(e.xp) do totals[key] = (totals[key] or 0) + xp end
  end
  route.plan = {
    preset = preset, mode = mode, quests = selected, evaluated = evaluated,
    travelYards = travel, minutes = minutes, xpByMember = totals, estimate = true,
  }
  return route
end

-- Expands quests into accept / objective / turn-in tasks with precedence.
function RE.TasksForQuests(entries, input)
  local tasks = {}
  local inRoute = {}
  for _, e in ipairs(entries) do inRoute[e.questID] = true end
  for _, e in ipairs(entries) do
    local qid = e.questID
    local needAccept, needWork, needTurnin = {}, {}, {}
    for key, r in pairs(e.roles) do
      if r.status == "available" then needAccept[#needAccept + 1] = key end
      if r.status == "available" or r.status == "active" then needWork[#needWork + 1] = key end
      if r.role == "progress" then needTurnin[#needTurnin + 1] = key end
    end
    table.sort(needAccept); table.sort(needWork); table.sort(needTurnin)
    local base = "q" .. qid
    local prereqAfter = {}
    local m = e.meta
    if m and m.prereq then
      for _, p in ipairs(m.prereq) do
        if inRoute[p] then prereqAfter[#prereqAfter + 1] = "q" .. p .. ":turnin" end
      end
    end
    local after = prereqAfter
    if #needAccept > 0 then
      tasks[#tasks + 1] = { id = base .. ":accept", type = "accept", quest = qid, loc = RE.LocFor(qid, "accept", input.guides), after = prereqAfter, who = needAccept }
      after = { base .. ":accept" }
    end
    if #needWork > 0 then
      tasks[#tasks + 1] = { id = base .. ":work", type = "complete", quest = qid, loc = RE.LocFor(qid, "complete", input.guides), after = after, who = needWork }
      after = { base .. ":work" }
    end
    tasks[#tasks + 1] = { id = base .. ":turnin", type = "turnin", quest = qid, loc = RE.LocFor(qid, "turnin", input.guides), after = after, who = needTurnin }
  end
  return tasks
end

function RE.ToGuide(ordered, info)
  local steps = {}
  for _, t in ipairs(ordered) do
    steps[#steps + 1] = {
      id = t.id, type = t.type, quest = t.quest, objective = t.objective, loc = t.loc,
      who = t.who, help = t.help, note = t.note, label = t.label, status = "generated",
    }
  end
  local g = { id = info.id, title = info.title, kind = info.kind, status = "generated", steps = steps }
  return ns.Guide:Prepare(g)
end

----------------------------------------------------------------------
-- Dungeons
----------------------------------------------------------------------
RE.dungeons = {}
RE.MODE_TITLE = { together = "Level together", catchup = "Group catch-up", dungeon = "Dungeon Focus" }
RE.TANKS = { WARRIOR = true, PALADIN = true, DRUID = true }
RE.HEALERS = { PRIEST = true, PALADIN = true, DRUID = true, SHAMAN = true }

RE.dungeonQuests = {}

function RE.RegisterDungeons(list)
  for _, d in ipairs(list) do RE.dungeons[#RE.dungeons + 1] = d end
end

-- Quests of each dungeon from the generated catalog ({ [dungeon id] = { quest ids } }); hand-written d.quests win.
function RE.AttachDungeonQuests(map, source)
  for id, quests in pairs(map or {}) do RE.dungeonQuests[id] = quests end
  RE.dungeonQuestSource = source
end

function RE.DungeonQuests(d)
  return d.quests or RE.dungeonQuests[d.id] or {}
end

function RE.RecommendDungeons(members, faction)
  local out = {}
  if #members == 0 then return out end
  local minL, maxL, sum = 99, 0, 0
  local tank, healer = false, false
  for _, m in ipairs(members) do
    local l = m.level or 1
    minL, maxL, sum = math.min(minL, l), math.max(maxL, l), sum + l
    if m.class and RE.TANKS[m.class] then tank = true end
    if m.class and RE.HEALERS[m.class] then healer = true end
  end
  local avg = sum / #members
  for _, d in ipairs(RE.dungeons) do
    if not (d.faction and faction and d.faction ~= faction) then
      local fit = minL >= d.minLevel - 2 and avg <= d.maxLevel + 1
      if fit then
        local notes = {}
        local score = 10 - math.abs(avg - (d.minLevel + d.maxLevel) / 2)
        if #members < 3 then notes[#notes + 1] = "small-party"; score = score - 4 end
        if not tank then notes[#notes + 1] = "no-tank"; score = score - 2 end
        if not healer then notes[#notes + 1] = "no-healer"; score = score - 2 end
        local questCount = 0
        for _, qid in ipairs(RE.DungeonQuests(d)) do
          for _, m in ipairs(members) do
            if m.state and QE:IsPending((QE:Availability(m.state, qid))) then questCount = questCount + 1; break end
          end
        end
        score = score + questCount
        out[#out + 1] = { dungeon = d, score = score, notes = notes, quests = questCount, status = d.status or "unverified" }
      end
    end
  end
  table.sort(out, function(a, b) return a.score > b.score end)
  return out
end
