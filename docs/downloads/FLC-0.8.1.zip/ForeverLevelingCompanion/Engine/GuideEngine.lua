-- Guide Engine: guide registry/validation and step evaluation over a "track" (a cursor plus local marks).
-- The engine evaluates any guide-shaped table, so generated routes (Help Player, Level Together)
-- reuse exactly the same rules as authored guides.
local _, ns = ...
local U = ns.U
local QE = ns.Quest

local GE = { guides = {}, order = {} }
ns.Guide = GE

GE.STEP_TYPES = {
  accept = "quest", complete = "quest", turnin = "quest", kill = "quest", collect = "quest",
  ["goto"] = "location", level = "level",
  talk = "manual", note = "manual", train = "manual", hearth = "manual", fly = "manual",
  sethearth = "manual", buy = "manual", grind = "manual", dungeon = "manual",
  -- 0.7 dungeon guides (Engine/DungeonGuide.lua): done when the game reports the encounter won (ENCOUNTER_END)
  boss = "encounter",
}
-- Validation status of data (docs/DATA_FORMAT.md). Only "official-verified" means checked on an
-- official Blizzard realm; everything else is shown "in review".
GE.DATA_STATUS = {
  unverified = true, ["extracted-db"] = true, ["server-simulated"] = true, ["test-server-played"] = true,
  ["static-validated"] = true, ["client-accelerated"] = true, -- 0.6
  ["official-verified"] = true, incomplete = true, ["incompatible-build"] = true, generated = true, fixture = true,
  ["beta-verified"] = true, ["live-verified"] = true, -- 0.1.0 names, read as official-verified
}
GE.CONDITION_FIELDS = {
  class = true, classes = true, race = true, races = true, raceIDs = true, faction = true,
  minLevel = true, maxLevel = true, mode = true, minPlayers = true,
}

----------------------------------------------------------------------
-- Validation / registry
----------------------------------------------------------------------
-- Two location forms: map percent { map, x, y } (hand-written guides) and world yards
-- { cont, wx, wy } (generated from the server database; converted by the client at runtime).
local function validLoc(loc)
  if type(loc) ~= "table" then return false end
  if loc.cont ~= nil then
    return type(loc.cont) == "number" and type(loc.wx) == "number" and type(loc.wy) == "number"
  end
  return type(loc.map) == "number"
    and type(loc.x) == "number" and type(loc.y) == "number"
    and loc.x >= 0 and loc.x <= 100 and loc.y >= 0 and loc.y <= 100
end
GE.ValidLoc = validLoc

function GE:Validate(guide)
  local errs = {}
  local function err(s) errs[#errs + 1] = s end
  if type(guide) ~= "table" then return false, { "guide is not a table" } end
  if type(guide.id) ~= "string" or guide.id == "" then err("missing id") end
  if type(guide.steps) ~= "table" or #guide.steps == 0 then err("no steps") end
  if guide.format and guide.format > ns.dataFormat then err("data format " .. guide.format .. " is newer than engine " .. ns.dataFormat) end
  if guide.status and not GE.DATA_STATUS[guide.status] then err("unknown status " .. tostring(guide.status)) end
  local seen = {}
  for i, s in ipairs(guide.steps or {}) do
    local where = "step " .. i .. " (" .. tostring(s.id) .. ")"
    if type(s.id) ~= "string" then err(where .. ": missing id")
    elseif seen[s.id] then err(where .. ": duplicate id")
    else seen[s.id] = true end
    local kind = GE.STEP_TYPES[s.type or ""]
    if not kind then err(where .. ": unknown type " .. tostring(s.type)) end
    if kind == "quest" and type(s.quest) ~= "number" then err(where .. ": quest id required") end
    if kind == "location" and not validLoc(s.loc) then err(where .. ": goto needs a valid loc") end
    if kind == "level" and type(s.level) ~= "number" then err(where .. ": level step needs level") end
    if kind == "encounter" and type(s.encounter) ~= "number" then err(where .. ": boss step needs its encounter id") end
    if s.loc ~= nil and not validLoc(s.loc) then err(where .. ": invalid loc") end
    if s.objectives ~= nil then
      if type(s.objectives) ~= "table" or #s.objectives == 0 then err(where .. ": objectives must be a non-empty list")
      else
        for _, o in ipairs(s.objectives) do
          if type(o) ~= "number" then err(where .. ": objective indexes must be numbers") break end
        end
      end
    end
    if s.when then
      for k in pairs(s.when) do if not GE.CONDITION_FIELDS[k] then err(where .. ": unknown condition " .. tostring(k)) end end
    end
    if s.status and not GE.DATA_STATUS[s.status] then err(where .. ": unknown status " .. tostring(s.status)) end
  end
  return #errs == 0, errs
end

local function index(guide)
  guide.index = {}
  for i, s in ipairs(guide.steps) do guide.index[s.id] = i end
end

function GE:Register(guide)
  local ok, errs = self:Validate(guide)
  if not ok then
    ns.Diag:Warn("guide", "rejected " .. tostring(guide and guide.id) .. ": " .. table.concat(errs, "; "))
    return false, errs
  end
  index(guide)
  if not self.guides[guide.id] then self.order[#self.order + 1] = guide.id end
  self.guides[guide.id] = guide
  return true
end

-- Generated routes: the header (title, faction, levels, where it starts) at load, the steps the first time the route
-- is used. 95 routes built at load took ~8.6 MB of Lua memory; most of them are never opened.
function GE:RegisterLazy(header, loader)
  if type(header) ~= "table" or type(header.id) ~= "string" or type(loader) ~= "function" then
    ns.Diag:Warn("guide", "rejected lazy guide " .. tostring(header and header.id))
    return false
  end
  header._loader = loader
  if not self.guides[header.id] then self.order[#self.order + 1] = header.id end
  self.guides[header.id] = header
  return true
end

local function materialize(self, g)
  if not (g and g._loader) then return g end
  local loader = g._loader
  g._loader = nil
  local okL, steps = pcall(loader)
  g.steps = okL and steps or nil
  local valid, errs = self:Validate(g)
  if not valid then
    ns.Diag:Warn("guide", "rejected " .. tostring(g.id) .. ": " .. table.concat(errs, "; "))
    self.guides[g.id] = nil
    for i, id in ipairs(self.order) do
      if id == g.id then table.remove(self.order, i) break end
    end
    return nil
  end
  index(g)
  return g
end

function GE:Get(id) return materialize(self, self.guides[id]) end

function GE:IsLoaded(id)
  local g = self.guides[id]
  return g ~= nil and g._loader == nil
end

-- Guides already built (authored ones, and generated routes in use): what group routes read locations from.
function GE:LoadedGuides()
  local out = {}
  for _, id in ipairs(self.order) do
    if self:IsLoaded(id) then out[#out + 1] = self.guides[id] end
  end
  return out
end

-- Generated routes are not registered but still need an index; lazy ones are built first.
function GE:Prepare(guide)
  if guide and guide._loader then guide = self:Get(guide.id) end
  if guide and not guide.index then index(guide) end
  return guide
end

----------------------------------------------------------------------
-- Tracks
----------------------------------------------------------------------
function GE.NewTrack(guideID)
  return { guideID = guideID, cursors = {}, reached = {}, manual = {}, skipped = {} }
end

function GE:Cursor(track, guide)
  local c = track.cursors[guide.id]
  if not c then
    c = { index = 1 }
    track.cursors[guide.id] = c
  end
  -- Prefer the stable step id: guide updates may insert or remove steps before it.
  if c.stepID and guide.index[c.stepID] then
    c.index = guide.index[c.stepID]
  else
    c.index = U.clamp(tonumber(c.index) or 1, 1, #guide.steps + 1)
  end
  return c
end

function GE:SwitchGuide(track, guideID)
  track.guideID = guideID
end

----------------------------------------------------------------------
-- Evaluation
----------------------------------------------------------------------
function GE:Applicable(step, subject, ctx)
  local w = step.when
  if not w then return true end
  ctx = ctx or {}
  if w.class and subject.class and w.class ~= subject.class then return false end
  if w.classes and subject.class and not U.contains(w.classes, subject.class) then return false end
  if w.race and subject.race and w.race ~= subject.race then return false end
  if w.races and subject.race and not U.contains(w.races, subject.race) then return false end
  if w.raceIDs and subject.raceID and not U.contains(w.raceIDs, subject.raceID) then return false end
  if w.faction and subject.faction and w.faction ~= subject.faction then return false end
  if w.minLevel and subject.level and subject.level < w.minLevel then return false end
  if w.maxLevel and subject.level and subject.level > w.maxLevel then return false end
  if w.mode and w.mode ~= (ctx.mode or "solo") then return false end
  if w.minPlayers and (ctx.partySize or 1) < w.minPlayers then return false end
  return true
end

local NOT_APPLICABLE_REASONS = { faction = true, class = true, race = true }

-- Returns status, info. status: done | active | blocked | na | skipped | unknown
function GE:StepStatus(step, track, subject, ctx)
  if track.skipped[step.id] then return "skipped" end
  if not self:Applicable(step, subject, ctx) then return "na" end
  if track.manual[step.id] then return "done", { manual = true } end
  if step.insideMap and track.reached[step.id] then return "done" end
  local kind = GE.STEP_TYPES[step.type]
  if step.requires and step.requires.level and subject.level and subject.level < step.requires.level then
    return "blocked", { reason = "level", need = step.requires.level }
  end
  if kind == "quest" then
    local q = step.quest
    local completed = subject:IsCompleted(q)
    local on = subject:IsOnQuest(q)
    if completed == true then return "done" end
    -- a dungeon guide's objective step is for characters on that quest only (0.7)
    if step.ifOnQuest and on == false then return "na", { reason = "not-on-quest" } end
    if step.type == "accept" then
      if on == true then return "done" end
      local avail, reasons = QE:Availability(subject, q)
      if avail == "unavailable" then
        for _, r in ipairs(reasons) do
          if NOT_APPLICABLE_REASONS[r] or string.find(r, "^exclusive:") then return "na", { reason = r } end
        end
        return "blocked", { reason = reasons[1], reasons = reasons }
      end
      if completed == nil or on == nil then return "unknown" end
      return "active"
    end
    -- complete / kill / collect / turnin
    if step.type ~= "turnin" then
      -- the client's quest is complete: every objective step of it is done, whatever its numbering
      if subject:IsReady(q) == true then return "done" end
      if step.objectives then
        -- Several objectives done in the same place (e.g. meat and feathers from the same beasts): one step.
        local known, open = 0, 0
        for i, idx in ipairs(step.objectives) do
          local o = GE.ObjectiveFor(subject, q, idx, step.labels and step.labels[i])
          if o then
            known = known + 1
            if not o.done then open = open + 1 end
          end
        end
        if known == #step.objectives and open == 0 then return "done" end
        if known > 0 then return "active", { objectivesOpen = open } end
      elseif step.objective then
        local o = GE.ObjectiveFor(subject, q, step.objective, step.label)
        if o and o.done then return "done" end
        if o then return "active", { have = o.have, need = o.need } end
      end
    end
    if on == false and completed == false then return "blocked", { reason = "not-on-quest" } end
    if on == nil or completed == nil then return "unknown" end
    if step.type == "turnin" and subject:IsReady(q) == false then
      return "active", { reason = "not-ready" }
    end
    return "active"
  elseif kind == "location" then
    if track.reached[step.id] then return "done" end
    return "active"
  elseif kind == "level" then
    if subject.level and subject.level >= step.level then return "done" end
    return "active", { have = subject.level, need = step.level }
  elseif kind == "encounter" then
    if track.encounters and track.encounters[step.encounter] then return "done" end
    return "active"
  end
  return "active"
end

local PASSABLE = { done = true, na = true, skipped = true }

-- A step of a quest the player is no longer on (abandoned from the quest log): the first accept step passed before
-- it that is to be done again, so the arrow goes back to the quest giver instead of the old objective.
local function acceptAgain(self, guide, track, subject, ctx, i, st, info)
  if st ~= "blocked" or not info or info.reason ~= "not-on-quest" then return nil end
  for j = 1, i - 1 do
    local a = guide.steps[j]
    if a.type == "accept" then
      local ast, ainfo = self:StepStatus(a, track, subject, ctx)
      if ast == "active" then return j, a, ast, ainfo end
    end
  end
end

-- Moves the cursor past finished / not-applicable steps and returns the current one.
-- Returns index, step (nil when the guide is finished), status, info.
function GE:Current(guide, track, subject, ctx)
  self:Prepare(guide)
  local c = self:Cursor(track, guide)
  local i = c.index
  if c.hold then
    local s = guide.steps[i]
    if s then
      local st, info = self:StepStatus(s, track, subject, ctx)
      return i, s, st, info
    end
  end
  while i <= #guide.steps do
    local s = guide.steps[i]
    local st, info = self:StepStatus(s, track, subject, ctx)
    if not PASSABLE[st] then
      local j, a, ast, ainfo = acceptAgain(self, guide, track, subject, ctx, i, st, info)
      if j then i, s, st, info = j, a, ast, ainfo end
      c.index, c.stepID = i, s.id
      return i, s, st, info
    end
    i = i + 1
  end
  c.index, c.stepID = #guide.steps + 1, nil
  return c.index, nil, "finished"
end

function GE:Next(guide, track, subject, ctx)
  local c = self:Cursor(track, guide)
  c.hold = nil
  local s = guide.steps[c.index]
  if s then
    local st = self:StepStatus(s, track, subject, ctx)
    -- Advancing over an unfinished step is an explicit skip, never a completion.
    if not PASSABLE[st] then track.skipped[s.id] = true end
  end
  return self:Current(guide, track, subject, ctx)
end

function GE:Prev(guide, track)
  local c = self:Cursor(track, guide)
  local i = math.max(1, c.index - 1)
  c.index, c.stepID, c.hold = i, guide.steps[i] and guide.steps[i].id, true
  return i
end

function GE:Jump(guide, track, stepID)
  self:Prepare(guide)
  local i = guide.index[stepID]
  if not i then return false end
  local c = self:Cursor(track, guide)
  c.index, c.stepID, c.hold = i, stepID, true
  track.skipped[stepID] = nil
  return true
end

-- A quest abandoned from the quest log whose accept step the cursor has passed (its other steps already behind too):
-- the cursor goes back to that accept step, at the giver who offers it again. Not when it cannot be taken again.
function GE:Reopen(guide, track, questID, subject, ctx)
  self:Prepare(guide)
  local c = self:Cursor(track, guide)
  for j = 1, c.index - 1 do
    local s = guide.steps[j]
    if s.type == "accept" and s.quest == questID then
      if self:StepStatus(s, track, subject, ctx) ~= "active" then return false end
      c.index, c.stepID, c.hold = j, s.id, nil
      return true
    end
  end
  return false
end

function GE:Release(guide, track)
  local c = self:Cursor(track, guide)
  c.hold = nil
end

function GE:MarkManual(track, stepID, value)
  track.manual[stepID] = value and true or nil
end

function GE:Unskip(track, stepID)
  track.skipped[stepID] = nil
end

-- First mandatory applicable step that is not done, from the start of the guide.
-- Used to resume after reinstalling or when the stored cursor is unusable.
function GE:FindResumePoint(guide, track, subject, ctx)
  self:Prepare(guide)
  for i, s in ipairs(guide.steps) do
    if not s.optional then
      local st = self:StepStatus(s, track, subject, ctx)
      if not PASSABLE[st] then return i, s, st end
    end
  end
  return #guide.steps + 1
end

function GE:Upcoming(guide, track, subject, ctx, count)
  local c = self:Cursor(track, guide)
  local list = {}
  for i = c.index, #guide.steps do
    local s = guide.steps[i]
    local st, info = self:StepStatus(s, track, subject, ctx)
    if st ~= "na" then list[#list + 1] = { index = i, step = s, status = st, info = info } end
    if #list >= count then break end
  end
  return list
end

-- "Also here": the next steps done in the same place as the current one, so the player does them together instead of
-- one after another (two quests' beasts in the same field, a quest giver or a turn-in right there). It looks some
-- steps around the current one, passes the steps elsewhere (a quest already in the log can be done now, wherever the
-- route puts it) and stops at a level wait. Objective steps count when their area meets the current one; accepts and
-- ready turn-ins when they are inside it. Nothing changes order or completion: each step completes by itself, and
-- the cursor passes the ones already done.
GE.ALSO_LOOKAHEAD, GE.ALSO_MAX, GE.ALSO_MARGIN = 20, 4, 30
local ALSO_FROM = { kill = true, collect = true, complete = true }

-- yards between two areas' edges (negative when they overlap); world positions only (map percentages have no yards)
local function areaGap(a, b)
  if not (validLoc(a) and validLoc(b)) or a.cont == nil or a.cont ~= b.cont then return nil end
  local dx, dy = a.wx - b.wx, a.wy - b.wy
  return math.sqrt(dx * dx + dy * dy) - (tonumber(a.r) or 0) - (tonumber(b.r) or 0)
end

GE.ALSO_LOOKBEHIND = 4

function GE:AlsoHere(guide, track, subject, ctx, index)
  local cur = guide and guide.steps[index or 0]
  if not (cur and ALSO_FROM[cur.type] and validLoc(cur.loc)) then return {} end
  local out = {}
  -- the same objective twice in a route (done in two visits) is shown once, and never the current one again
  local seen = { [cur.type .. ":" .. tostring(cur.quest) .. ":" .. tostring(cur.objective)] = true }
  -- one direction: true to go on, false at a level wait (what comes after it is not for this level yet)
  local function consider(i)
    local s = guide.steps[i]
    local st = self:StepStatus(s, track, subject, ctx)
    if PASSABLE[st] then return true end
    if s.type == "level" then return false end
    local gap = areaGap(cur.loc, s.loc)
    local objective = ALSO_FROM[s.type]
    if not gap or gap > (objective and self.ALSO_MARGIN or 0) then return true end
    local key = s.type .. ":" .. tostring(s.quest) .. ":" .. tostring(s.objective)
    if st == "active" and not seen[key]
      and (objective or s.type == "accept" or (s.type == "turnin" and subject:IsReady(s.quest) == true)) then
      seen[key] = true
      out[#out + 1] = { index = i, step = s, status = st, behind = i < index }
    end
    return #out < self.ALSO_MAX
  end
  -- first the unfinished steps just behind (skipped, or left when the player went ahead), then the next ones
  for i = index - 1, math.max(1, index - self.ALSO_LOOKBEHIND), -1 do
    if not consider(i) then break end
  end
  for i = index + 1, math.min(#guide.steps, index + self.ALSO_LOOKAHEAD) do
    if #out >= self.ALSO_MAX or not consider(i) then break end
  end
  return out
end

-- Steps behind the cursor that were left unfinished (e.g. after manual skips).
function GE:Unfinished(guide, track, subject, ctx)
  local c = self:Cursor(track, guide)
  local list = {}
  for i = 1, c.index - 1 do
    local s = guide.steps[i]
    local st = self:StepStatus(s, track, subject, ctx)
    if (st == "active" or st == "skipped" or st == "blocked") and not s.optional then
      list[#list + 1] = { index = i, step = s, status = st }
    end
  end
  return list
end

function GE:Progress(guide, track, subject, ctx)
  local total, done = 0, 0
  for _, s in ipairs(guide.steps) do
    local st = self:StepStatus(s, track, subject, ctx)
    if st ~= "na" then
      total = total + 1
      if st == "done" then done = done + 1 end
    end
  end
  return done, total
end

-- Marks the current goto step reached when the player is close enough.
function GE:CheckArrival(guide, track, position, yards)
  local c = self:Cursor(track, guide)
  local s = guide.steps[c.index]
  -- a dungeon guide's way in is reached once the character is inside the dungeon's map, however it got there (0.7)
  if s and s.insideMap and position and position.cont == s.insideMap then
    track.reached[s.id] = true
    return true
  end
  if not s or s.type ~= "goto" or not position then return false end
  local d = ns.Nav.Distance(position, s.loc)
  if d and d <= (s.radius or yards or 12) then
    track.reached[s.id] = true
    return true
  end
  return false
end

-- Picks the registered guide that best matches the character.
-- Better-validated data wins ties (docs/DATA_FORMAT.md).
GE.STATUS_BONUS = { ["official-verified"] = 20, ["live-verified"] = 20, ["beta-verified"] = 18, ["test-server-played"] = 15,
  ["client-accelerated"] = 13, ["server-simulated"] = 12, ["static-validated"] = 11, ["extracted-db"] = 10, unverified = 0 }

-- First located step of a guide, cached: where the guide starts.
local function anchor(g)
  if g._loader then return g.anchor end   -- generated route not built yet: the header says where it starts
  if g._anchor == nil then
    g._anchor = false
    for _, s in ipairs(g.steps) do
      if s.loc then g._anchor = s.loc break end
    end
  end
  return g._anchor or nil
end

-- Picks the registered guide that best matches the character: faction/race/class, level and, when
-- known, where the character stands (same continent and nearby start beat a level-only match).
-- Guides with suggest = false (city hubs) are never picked automatically.
function GE:SuggestGuide(subject, position)
  -- the character's leveling path first (Engine/LevelingPath.lua): the route it says to follow at this level
  local seg = ns.Path and ns.Path:Suggest(subject)
  local g = seg and self:Get(seg.guide)
  if g then return g end
  local best, bestScore
  for _, id in ipairs(self.order) do
    local g = self.guides[id]
    local score = 0
    local ok = g.suggest ~= false
    if g.faction and subject.faction and g.faction ~= subject.faction then ok = false end
    if g.races and subject.race and not U.contains(g.races, subject.race) then ok = false end
    if g.raceIDs and subject.raceID and not U.contains(g.raceIDs, subject.raceID) then ok = false end
    if g.classes and subject.class and not U.contains(g.classes, subject.class) then ok = false end
    if ok and g.levelRange and subject.level then
      local lo, hi = g.levelRange[1], g.levelRange[2]
      if subject.level < lo then score = score - (lo - subject.level) * 10
      elseif subject.level > hi then score = score - (subject.level - hi) * 10
      else score = score + 100 end
      if g.races or g.raceIDs then score = score + 5 end
      score = score + (GE.STATUS_BONUS[g.trust or g.status or ""] or 0)
    end
    if ok and position then
      local a = anchor(g)
      if a then
        local d = ns.Nav.Distance(position, a)
        if d then score = score - math.min(d / 50, 80)
        else score = score - 150 end -- other continent or map
      end
    end
    if ok and (not bestScore or score > bestScore) then best, bestScore = g, score end
  end
  return best and self:Get(best.id)
end

-- A step's objective in the subject's quest log. The catalog numbers objectives from its own data; the client
-- can list them differently (measured on 91772: the client drops a "provided" item objective, so the tracks the step
-- calls objective 2 are the client's objective 1). When the label is known and the numbered objective does not match
-- it, the objective with that text is used instead.
function GE.ObjectiveFor(subject, questID, index, label)
  local o = subject:Objective(questID, index)
  if not label or label == "" then return o end
  local want = string.lower(label)
  if o and o.text and string.find(string.lower(o.text), want, 1, true) then return o end
  local entry = subject.log and subject.log[questID]
  for _, cand in ipairs(entry and entry.objectives or {}) do
    if cand.text and string.find(string.lower(cand.text), want, 1, true) then return cand end
  end
  return o
end

-- What to do, for newcomers ("Water Pitcher: 0/1" alone did not say to loot the pitcher by the well).
GE.SOURCE_TEXT = {
  kill = "Kill: %s", ["kill-loot"] = "Kill and loot: %s", ["loot-object"] = "Loot the object: %s",
  talk = "Talk to: %s", buy = "Buy from: %s",
}

-- "Plainstrider" or "Kobold Vermin, Kobold Worker" from a step's task, in the client's language when known.
function GE:SourceNames(source)
  local parts = {}
  for _, kind in ipairs({ "npc", "object" }) do
    for _, id in ipairs(source[kind] or {}) do
      local name = QE:SourceName(kind, id)
      if name and not U.contains(parts, name) then parts[#parts + 1] = name end
    end
  end
  if #parts == 0 then return nil end
  return table.concat(parts, ", ")
end

-- "Kill: Plainstrider" or, for steps with several actions, "Kill: Kobold Vermin · Loot the object: Lumber".
-- nil when no name is known (the step keeps its generic text).
function GE:TaskText(task)
  local L = ns.L
  local parts = {}
  for _, part in ipairs(task.parts or { task }) do
    local action = GE.SOURCE_TEXT[part.action]
    local who = action and GE:SourceNames(part)
    if who then parts[#parts + 1] = string.format(L[action], who) end
  end
  if #parts == 0 then return nil end
  return table.concat(parts, " · ")
end

-- Progress of a step's objectives as the quest log words it: "Water Pitcher: 0/1" (several joined with " · ").
-- nil when the quest is not in the log.
function GE:ObjectiveProgress(step, subject)
  local list = step.objectives or (step.objective and { step.objective })
  if not list or not subject or not step.quest then return nil end
  local parts = {}
  for i, idx in ipairs(list) do
    local o = subject:Objective(step.quest, idx)
    if o then
      local label = o.text or (step.labels and step.labels[i]) or step.label or "?"
      parts[#parts + 1] = (o.have and o.need) and string.format("%s: %d/%d", label, o.have, o.need) or label
    end
  end
  if #parts == 0 then return nil end
  return table.concat(parts, " · ")
end

-- Display text for a step (localized templates; data may provide its own text).
function GE:StepText(step, subject)
  local L = ns.L
  if step.text then return L[step.text] end
  local qname = step.quest and QE:Name(step.quest, subject) or nil
  local npc = step.npc and step.npc.name
  local t = step.type
  if t == "accept" then return npc and string.format(L["Accept %s from %s"], qname, npc) or string.format(L["Accept %s"], qname) end
  if t == "turnin" then return npc and string.format(L["Turn in %s to %s"], qname, npc) or string.format(L["Turn in %s"], qname) end
  if type(step.task) == "table" and (t == "complete" or t == "kill" or t == "collect" or t == "buy") then
    local text = GE:TaskText(step.task)
    if text then return text end
  end
  if t == "complete" or t == "kill" or t == "collect" then
    if step.objectives then
      -- Every objective with its own count: "Plainstrider Meat 3/7, Plainstrider Feather 2/7".
      local parts, seen = {}, {}
      for i, idx in ipairs(step.objectives) do
        local o = subject and subject:Objective(step.quest, idx)
        local label = (o and o.text) or (step.labels and step.labels[i]) or qname
        if o and o.have and o.need then label = string.format("%s %d/%d", label, o.have, o.need) end
        -- objectives without a name of their own fall back to the quest's: said once, not once per objective
        if not seen[label] then
          seen[label] = true
          parts[#parts + 1] = label
        end
      end
      return string.format(L["Complete: %s"], table.concat(parts, ", "))
    end
    if step.objective then
      local o = subject and subject:Objective(step.quest, step.objective)
      local label = (o and o.text) or step.label or qname
      return string.format(L["Complete: %s"], label)
    end
    return string.format(L["Complete %s"], qname)
  end
  if t == "goto" then return step.label and string.format(L["Go to %s"], L[step.label]) or L["Go to the marked location"] end
  if t == "boss" then
    local name = step.npc and ((step.npc.id and QE:SourceName("npc", step.npc.id)) or step.npc.name)
    -- the game's encounter name first when the creature has another one ("Infurnus (Magmatus)")
    if step.encounterName and step.encounterName ~= name then
      return string.format(L["Boss: %s (%s)"], step.encounterName, name or "?")
    end
    return string.format(L["Boss: %s"], name or "?")
  end
  if t == "level" then return string.format(L["Reach level %d"], step.level) end
  return L[step.label or t]
end
