-- Contextual party suggestions. Every line says whether it is based on synced/client data
-- ("verified") or on our estimates, and nothing is produced from unknown data.
local _, ns = ...
local U, L = ns.U, ns.L
local QE = ns.Quest

local I = {}
ns.Insights = I

local function questMap(qid)
  local m = QE:Meta(qid)
  local loc = m and (m.area or m.start or m.finish)
  return loc and loc.map
end

function I:Compute(myMap, currentQuest)
  local out = {}
  local function add(text, basis) out[#out + 1] = { text = text, basis = basis } end
  local members = ns.Party:List()

  -- "Nico has 4 pending quests in this zone"
  if myMap then
    for _, m in ipairs(members) do
      if m.state.logKnown then
        local n = 0
        for qid, q in pairs(m.state.log) do
          if not q.complete and questMap(qid) == myMap then n = n + 1 end
        end
        if n > 0 then add(string.format(L["%s has %d pending quests in this zone"], m.name, n), "verified") end
      end
    end
  end

  -- "Two players need to defeat the same elite"
  local eliteNeed = {}
  local states = { { name = ns.Session.selfState and ns.Session.selfState.name, state = ns.Session.selfState } }
  for _, m in ipairs(members) do states[#states + 1] = { name = m.name, state = m.state } end
  for _, s in ipairs(states) do
    if s.state then
      for qid, q in pairs(s.state.log) do
        local meta = QE:Meta(qid)
        if meta and meta.elite and not q.complete then
          eliteNeed[qid] = (eliteNeed[qid] or 0) + 1
        end
      end
    end
  end
  for qid, n in pairs(eliteNeed) do
    if n >= 2 then add(string.format(L["%d players need the same elite quest: %s"], n, QE:Name(qid)), "verified") end
  end

  -- "Gustavo already completed this quest, but can accompany you"
  if currentQuest then
    for _, m in ipairs(members) do
      if m.state:IsCompleted(currentQuest) == true then
        add(string.format(L["%s already completed this quest, but can accompany you"], m.name), "verified")
      end
    end
  end

  -- Group route value
  local session = ns.Session:GetSession()
  if session and session.route and session.route.plan then
    local shared = 0
    for _, e in ipairs(session.route.plan.quests) do if #e.beneficiaries >= 2 then shared = shared + 1 end end
    if shared > 0 then add(string.format(L["This route completes %d objectives for several players at once"], shared), "estimate") end
  end
  if session and session.status == "finished" then
    add(L["Your personal guide is saved. You can resume it now"], "verified")
  end
  -- Members whose data we cannot verify are listed explicitly instead of guessed.
  for _, m in ipairs(members) do
    if not m.hasAddon then
      add(string.format(L["%s does not use FLC: quest progress cannot be verified"], m.name), "verified")
    end
  end
  return out
end
