-- Fixed travel connections for the travel planner (Engine/Travel.lua): boats, zeppelins, airships, the Deeprun Tram
-- and the Darnassus portal. Hand-curated; see docs/TRAVEL_GUIDANCE.md for provenance.
--
-- Positions use FLC's world convention (Engine/Navigation.lua): cont = the instance/continent id UnitPosition returns
-- (0 Eastern Kingdoms, 1 Kalimdor, 2991 Zephras Isle), wx = server position_x (north), wy = server position_y (west),
-- rounded to whole yards. Each entry names its source:
--   path N/i  = stop node i (the one with a departure delay) of transport path N, and
--   trigger N = area trigger N (the portal or tram entrance itself),
--               both read once from the client data the server runs on (client-data/dbc/enUS/TaxiPathNode.db2 and
--               AreaTrigger.db2, Blizzard's files; only these rounded positions are kept, nothing is shipped).
-- No position comes from the GPL-2.0 world database; it was only used to find which transports exist
-- (world.transports, noted per link) and which triggers teleport where (world.areatrigger_teleport).
-- Ride and wait times are our own estimates (half a typical cycle as the wait), not measured.
local _, ns = ...

local D = {}
ns.TravelData = D

-- id = { name (English; shown through the locale tables), cont, wx, wy }
D.docks = {
  menethil_theramore = { "Menethil Harbor", 0, -3905, -586 },   -- path 292/8
  theramore          = { "Theramore Isle", 1, -4016, -4741 },   -- path 292/21
  menethil_auberdine = { "Menethil Harbor", 0, -3709, -575 },   -- path 295/7
  auberdine_menethil = { "Auberdine", 1, 6406, 823 },           -- path 295/24
  auberdine_teldrassil = { "Auberdine", 1, 6594, 760 },         -- path 293/17
  rutheran_dock      = { "Rut'theran Village", 1, 8532, 1024 }, -- path 293/5
  booty_bay          = { "Booty Bay", 0, -14278, 583 },         -- path 241/29
  ratchet            = { "Ratchet", 1, -1006, -3842 },          -- path 241/11
  feathermoon        = { "Feathermoon Stronghold", 1, -4197, 3287 }, -- path 303/1
  forgotten_coast    = { "Forgotten Coast", 1, -4348, 2444 },   -- path 303/6
  org_gromgol        = { "Orgrimmar", 1, 1361, -4631 },         -- path 285/20
  gromgol_org        = { "Grom'gol Base Camp", 0, -12464, 232 }, -- path 285/4
  org_undercity      = { "Orgrimmar", 1, 1318, -4658 },         -- path 302/7
  undercity_org      = { "Undercity", 0, 2062, 293 },           -- path 302/28
  undercity_gromgol  = { "Undercity", 0, 2063, 235 },           -- path 301/21
  gromgol_undercity  = { "Grom'gol Base Camp", 0, -12407, 212 }, -- path 301/5
  -- WoW: Forever's Skyborne start (Zephras Isle, map 2991): two airships, both in world.transports
  lordamere          = { "Lordamere Lake", 0, 545, 424 },       -- path 11398/13 (Dalaran Skycutter)
  zephras_high_order = { "Zephras Isle", 2991, 1848, 569 },     -- path 11398/31 (High Order Dockmaster nearby)
  mulgore            = { "Mulgore", 1, -802, 367 },             -- path 11457/5 (Mulgore Skycutter)
  zephras_windshapers = { "Zephras Isle", 2991, 1953, 1019 },   -- path 11457/17 (Windshapers Dockmaster nearby)
  -- Deeprun Tram (instance map 369): its two city exits
  tram_stormwind     = { "Stormwind City", 0, -8346, 514 },     -- trigger 2173
  tram_ironforge     = { "Ironforge", 0, -4840, -1330 },        -- trigger 2175
  -- Rut'theran Village <-> Darnassus portal
  rutheran_portal    = { "Rut'theran Village", 1, 8799, 970 },  -- trigger 542
  darnassus_portal   = { "Darnassus", 1, 9947, 2630 },          -- trigger 527
}

-- Two-way connections. faction = who can use it safely (nil: anyone). wait + ride = estimated seconds.
-- transport = world.transports entry (for reference only).
D.links = {
  { kind = "boat", a = "menethil_theramore", b = "theramore", faction = "Alliance", wait = 150, ride = 120 },     -- transport 4
  { kind = "boat", a = "menethil_auberdine", b = "auberdine_menethil", faction = "Alliance", wait = 150, ride = 120 }, -- 50
  { kind = "boat", a = "auberdine_teldrassil", b = "rutheran_dock", faction = "Alliance", wait = 120, ride = 90 }, -- 51
  { kind = "boat", a = "booty_bay", b = "ratchet", wait = 150, ride = 120 },                                     -- 7
  { kind = "boat", a = "feathermoon", b = "forgotten_coast", faction = "Alliance", wait = 60, ride = 45 },       -- 54
  { kind = "zeppelin", a = "org_gromgol", b = "gromgol_org", faction = "Horde", wait = 150, ride = 120 },        -- 5
  { kind = "zeppelin", a = "org_undercity", b = "undercity_org", faction = "Horde", wait = 150, ride = 120 },     -- 53
  { kind = "zeppelin", a = "undercity_gromgol", b = "gromgol_undercity", faction = "Horde", wait = 150, ride = 120 }, -- 52
  -- TODO(owner): which factions the Skycutters serve is not in the data we read; both are offered to everyone.
  { kind = "airship", a = "lordamere", b = "zephras_high_order", wait = 150, ride = 120 },                       -- 56
  { kind = "airship", a = "mulgore", b = "zephras_windshapers", wait = 150, ride = 120 },                        -- 57
  { kind = "tram", a = "tram_stormwind", b = "tram_ironforge", faction = "Alliance", wait = 30, ride = 70 },
  { kind = "portal", a = "rutheran_portal", b = "darnassus_portal", faction = "Alliance", wait = 0, ride = 5 },
}

-- Land separated from the rest of its continent by deep water: walking in or out means swimming, which the planner
-- charges extra. Boxes in world coordinates (our own approximation from the dock positions above).
D.islands = {
  { name = "Teldrassil", cont = 1, minX = 7900, maxX = 11500, minY = -500, maxY = 3500 },
  { name = "Feathermoon", cont = 1, minX = -4500, maxX = -3900, minY = 3000, maxY = 3600 },
}
