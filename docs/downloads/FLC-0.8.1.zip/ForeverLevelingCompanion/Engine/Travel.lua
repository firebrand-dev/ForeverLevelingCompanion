-- Travel planner: how to get to a far-away step (another continent, the other end of a zone, the start of a guide).
-- Pure logic over a small graph, in estimated seconds (Dijkstra):
--   * walking between any two places on the same continent (distance / run speed; swimming to an island costs more);
--   * flights between flight masters the character knows (learned from the flight map, kept per character);
--   * the fixed boats, zeppelins, airships, tram and portal of Engine/TravelData.lua;
--   * the Hearthstone to the bind location, when its position is known and its cooldown allows it.
-- The result is an ordered list of legs { kind, from, to, secs, yards } with one-line instructions.
-- Nothing here touches the client: the UI and Bootstrap hand in positions, flight nodes and the Hearthstone state.
local _, ns = ...
local L = ns.L

local T = {
  runSpeed = 7,         -- yards per second (unmounted)
  flySpeed = 32,        -- taxi speed, yards per second (estimate)
  flyDetour = 1.3,      -- flight paths are not straight lines
  flyOverhead = 20,     -- talk to the flight master, take off, land
  hearthSecs = 25,      -- cast (10 s) + loading screen (estimate)
  hearthTownWalk = 120, -- after a name-only hearth: walking in the bind town (estimate)
  swimFactor = 3,       -- walking that crosses deep water to or from an island
  farYards = 1500,      -- same continent, closer than this: the arrow points at the step as before
  replanYards = 100,    -- re-plan when the player moved this far since the last plan
  replanSecs = 15,      -- ... or this long ago
  version = 0,          -- bumped when known nodes or the bind change, invalidates cached plans
  store = { nodes = {}, bind = {} },
}
ns.Travel = T

T.KINDS = { walk = true, fly = true, boat = true, zeppelin = true, airship = true, tram = true, portal = true, hearth = true }

----------------------------------------------------------------------
-- Character knowledge (FLC_CharDB.travel)
----------------------------------------------------------------------
function T:Attach(store)
  if type(store) ~= "table" then store = {} end
  if type(store.nodes) ~= "table" then store.nodes = {} end
  if type(store.bind) ~= "table" then store.bind = {} end
  self.store = store
  self.version = self.version + 1
  return store
end

local function validLoc(l)
  return type(l) == "table" and l.cont ~= nil and type(l.wx) == "number" and type(l.wy) == "number"
end

-- nodes: list from API.GetTaxiNodes() { id, name, known, current, loc }; here: the player's world position (the
-- player stands at the "current" flight master, so it gets that position when the client gives none).
-- Returns how many nodes were learned or moved.
function T:LearnTaxiNodes(nodes, here)
  local learned = 0
  for _, n in ipairs(nodes or {}) do
    local key = n.id ~= nil and tostring(n.id) or n.name
    if key and (n.known or n.current) then
      local loc = validLoc(n.loc) and n.loc or (n.current and validLoc(here) and here) or nil
      local old = self.store.nodes[key]
      if loc then
        if not old or old.cont ~= loc.cont or math.abs((old.wx or 0) - loc.wx) > 5 or math.abs((old.wy or 0) - loc.wy) > 5 then
          learned = learned + 1
        end
        self.store.nodes[key] = { name = n.name or (old and old.name) or key, cont = loc.cont, wx = loc.wx, wy = loc.wy }
      elseif not old then
        self.store.nodes[key] = { name = n.name or key } -- known, position unknown: not used for flights
      end
    end
  end
  if learned > 0 then self.version = self.version + 1 end
  return learned
end

-- The player bound the Hearthstone here (HEARTHSTONE_BOUND): they stand next to the innkeeper.
function T:SetBind(name, here)
  local b = { name = name }
  if validLoc(here) then b.cont, b.wx, b.wy = here.cont, here.wx, here.wy end
  self.store.bind = b
  self.version = self.version + 1
end

-- Login: the client's bind name. A different name than the recorded one means the position is stale.
function T:CheckBind(name)
  local b = self.store.bind
  if name == nil then return end
  if b.name ~= name then
    self.store.bind = { name = name }
    self.version = self.version + 1
  end
end

function T:KnownNodes()
  local out = {}
  for key, n in pairs(self.store.nodes) do
    if validLoc(n) then out[#out + 1] = { id = key, name = n.name, cont = n.cont, wx = n.wx, wy = n.wy } end
  end
  table.sort(out, function(a, b) return tostring(a.id) < tostring(b.id) end)
  return out
end

----------------------------------------------------------------------
-- Planner
----------------------------------------------------------------------
local function dist(a, b)
  local dn, dw = b.wx - a.wx, b.wy - a.wy
  return math.sqrt(dn * dn + dw * dw)
end

local function island(p)
  for _, i in ipairs(ns.TravelData and ns.TravelData.islands or {}) do
    if p.cont == i.cont and p.wx >= i.minX and p.wx <= i.maxX and p.wy >= i.minY and p.wy <= i.maxY then return i.name end
  end
  return nil
end

local function walkSecs(self, a, b, speed)
  local f = island(a) == island(b) and 1 or self.swimFactor
  return dist(a, b) * f / speed
end

-- from, to: world locs { cont, wx, wy }. opts (all optional):
--   faction  "Alliance" | "Horde" (nil: every connection);
--   nodes    known flight nodes (default: the character's);
--   hearth   { has = bool|nil, remaining = seconds|nil, name, cont, wx, wy } (default: none);
--   goalZone the target's zone name, for a hearth whose position is unknown but whose name is that zone;
--   speed    run speed (default T.runSpeed).
-- Returns plan { legs, secs } or nil when nothing connects the two places.
function T:Plan(from, to, opts)
  if not validLoc(from) or not validLoc(to) then return nil end
  opts = opts or {}
  local speed = opts.speed or self.runSpeed
  local data = ns.TravelData or { docks = {}, links = {} }
  local nodes = {
    { kind = "start", cont = from.cont, wx = from.wx, wy = from.wy },
    { kind = "goal", cont = to.cont, wx = to.wx, wy = to.wy, name = opts.goalName },
  }
  local links = {} -- [i] = list of { j, secs, kind }
  local function link(i, j, secs, kind)
    links[i] = links[i] or {}
    links[i][#links[i] + 1] = { j, secs, kind }
  end
  local dockIndex = {}
  for id, d in pairs(data.docks) do
    nodes[#nodes + 1] = { kind = "dock", id = id, name = L[d[1]], cont = d[2], wx = d[3], wy = d[4] }
    dockIndex[id] = #nodes
  end
  for _, c in ipairs(data.links) do
    local a, b = dockIndex[c.a], dockIndex[c.b]
    if a and b and (not c.faction or not opts.faction or c.faction == opts.faction) then
      local secs = (c.wait or 0) + (c.ride or 0)
      link(a, b, secs, c.kind)
      link(b, a, secs, c.kind)
    end
  end
  local first = #nodes + 1
  for _, n in ipairs(opts.nodes or self:KnownNodes()) do
    nodes[#nodes + 1] = { kind = "flight", id = n.id, name = n.name, cont = n.cont, wx = n.wx, wy = n.wy }
  end
  for i = first, #nodes do
    for j = first, #nodes do
      if i ~= j and nodes[i].cont == nodes[j].cont then
        link(i, j, self.flyOverhead + self.flyDetour * dist(nodes[i], nodes[j]) / self.flySpeed, "fly")
      end
    end
  end
  local h = opts.hearth
  if h and h.has ~= false and h.remaining ~= nil then
    local secs = self.hearthSecs + h.remaining
    if h.cont ~= nil and h.wx and h.wy then
      nodes[#nodes + 1] = { kind = "bind", name = h.name, cont = h.cont, wx = h.wx, wy = h.wy }
      link(1, #nodes, secs, "hearth")
    elseif h.name and opts.goalZone and h.name == opts.goalZone then
      -- the bind town is the target's zone: hearth there and walk the rest
      link(1, 2, secs + self.hearthTownWalk, "hearth-town")
    end
  end

  -- Dijkstra over a few dozen nodes: plain arrays are enough.
  local n = #nodes
  local best, prev, via, done = {}, {}, {}, {}
  for i = 1, n do best[i] = math.huge end
  best[1] = 0
  for _ = 1, n do
    local u, bu = nil, math.huge
    for i = 1, n do if not done[i] and best[i] < bu then u, bu = i, best[i] end end
    if not u or u == 2 then break end
    done[u] = true
    local nu = nodes[u]
    for v = 1, n do
      if not done[v] and v ~= u and nodes[v].cont == nu.cont and nodes[v].kind ~= "start" then
        local c = bu + walkSecs(self, nu, nodes[v], speed)
        if c < best[v] then best[v], prev[v], via[v] = c, u, "walk" end
      end
    end
    for _, e in ipairs(links[u] or {}) do
      local v = e[1]
      if not done[v] then
        local c = bu + e[2]
        if c < best[v] then best[v], prev[v], via[v] = c, u, e[3] end
      end
    end
  end
  if best[2] == math.huge then return nil end

  local chain = {}
  local v = 2
  while v ~= 1 do
    table.insert(chain, 1, { from = nodes[prev[v]], to = nodes[v], kind = via[v], secs = best[v] - best[prev[v]] })
    v = prev[v]
  end
  local legs = {}
  for _, c in ipairs(chain) do
    local last = legs[#legs]
    if c.kind == "hearth-town" then
      c.kind, c.secs = "hearth", c.secs - self.hearthTownWalk
      c.to = { kind = "bind", name = h.name, cont = to.cont, wx = to.wx, wy = to.wy }
      legs[#legs + 1] = c
      legs[#legs + 1] = { kind = "walk", from = c.to, to = nodes[2], secs = self.hearthTownWalk, town = true }
    elseif c.kind == "walk" and last and last.kind == "walk" then
      last.to, last.secs = c.to, last.secs + c.secs
    else
      legs[#legs + 1] = c
    end
  end
  for _, leg in ipairs(legs) do
    if leg.kind == "walk" and not leg.town and leg.from.cont == leg.to.cont then leg.yards = dist(leg.from, leg.to) end
  end
  return { legs = legs, secs = best[2] }
end

-- First leg that is not walking (the one the arrow announces), or nil for a walk-only plan.
function T.FirstTravelLeg(plan)
  for _, leg in ipairs(plan and plan.legs or {}) do
    if leg.kind ~= "walk" then return leg end
  end
  return nil
end

----------------------------------------------------------------------
-- Texts
----------------------------------------------------------------------
local TAKE = {
  boat = "Take the boat at %s to %s",
  zeppelin = "Take the zeppelin at %s to %s",
  airship = "Take the airship at %s to %s",
  tram = "Take the Deeprun Tram at %s to %s",
  portal = "Take the portal at %s to %s",
}
local SHORT = {
  fly = "Fly to %s", boat = "Boat to %s", zeppelin = "Zeppelin to %s", airship = "Airship to %s",
  tram = "Tram to %s", portal = "Portal to %s", hearth = "Hearth to %s",
}

local function placeName(p)
  return p and p.name or "?"
end

function T.Instruction(leg)
  if not leg then return "" end
  if leg.kind == "walk" then
    if leg.to.kind == "goal" then return L["Walk to the destination"] end
    return string.format(L["Walk to %s"], placeName(leg.to))
  elseif leg.kind == "fly" then
    return string.format(L["Fly from %s to %s"], placeName(leg.from), placeName(leg.to))
  elseif leg.kind == "hearth" then
    return string.format(L["Use your Hearthstone to %s"], placeName(leg.to))
  end
  return string.format(L[TAKE[leg.kind] or "Take the boat at %s to %s"], placeName(leg.from), placeName(leg.to))
end

-- One compact line: "Walk 300 yd > Fly to Orgrimmar > Zeppelin to Undercity > Walk 1.2k yd (about 9 min)".
function T.Summary(plan)
  if not plan then return "" end
  local parts = {}
  for _, leg in ipairs(plan.legs) do
    if leg.kind == "walk" and not leg.yards then
      parts[#parts + 1] = L["Walk to the destination"]
    elseif leg.kind == "walk" then
      parts[#parts + 1] = string.format(L["Walk %s"], ns.Nav.FormatDistance(leg.yards))
    else
      parts[#parts + 1] = string.format(L[SHORT[leg.kind] or "%s"], placeName(leg.to))
    end
  end
  local mins = math.max(1, math.floor(plan.secs / 60 + 0.5))
  return table.concat(parts, " > ") .. " " .. string.format(L["(about %d min)"], mins)
end

----------------------------------------------------------------------
-- Guidance for the UI (cached; called many times a second by the arrow)
----------------------------------------------------------------------
local worldCache = setmetatable({}, { __mode = "k" })

-- A step's loc in world form; map-percent locs are converted once through the client.
function T.WorldOf(loc)
  if not loc then return nil end
  if loc.cont ~= nil then return loc end
  local w = worldCache[loc]
  if w == nil then
    w = ns.Nav.World(loc) or false
    worldCache[loc] = w
  end
  return w or nil
end

-- What the planner needs from the client, gathered when a plan is (re)built, not per frame.
function T:Context(loc)
  local API = ns.API or {}
  local ctx = {}
  local st = ns.Session and ns.Session.selfState
  ctx.faction = st and st.faction
  if API.GetHearthstone then
    local has, remaining = API.GetHearthstone()
    local b = self.store.bind or {}
    local name = API.GetBindLocation and API.GetBindLocation() or b.name
    ctx.hearth = { has = has, remaining = remaining, name = name }
    if b.name == name and b.cont ~= nil then ctx.hearth.cont, ctx.hearth.wx, ctx.hearth.wy = b.cont, b.wx, b.wy end
  end
  if loc and API.GetMapName then
    local map = loc.map
    if not map and API.WorldToMap then map = API.WorldToMap(loc) end
    ctx.goalZone = map and API.GetMapName(map) or nil
  end
  return ctx
end

-- Steps can be rebuilt (routes recalculated): the same place counts as the same target.
local function sameLoc(a, b)
  if a == b then return true end
  if not a or not b then return false end
  return a.cont == b.cont and a.wx == b.wx and a.wy == b.wy and a.map == b.map and a.x == b.x and a.y == b.y
end

-- pos: the player's world position; loc: the step's loc. Returns nil when the arrow should behave as before
-- (near, same continent, or nothing better than walking straight), else
--   { plan, leg (first non-walk leg), point (where the arrow points; nil for a Hearthstone), text, summary }.
function T:Guidance(pos, loc)
  local target = T.WorldOf(loc)
  if not validLoc(pos) or not target then return nil end
  if pos.cont == target.cont then
    local dn, dw = target.wx - pos.wx, target.wy - pos.wy
    if dn * dn + dw * dw <= self.farYards * self.farYards then return nil end
  end
  local c = self.cache
  local now = ns.Now()
  if c and sameLoc(c.loc, loc) and c.version == self.version and c.cont == pos.cont and now - c.at < self.replanSecs then
    local dn, dw = pos.wx - c.wx, pos.wy - c.wy
    if dn * dn + dw * dw < self.replanYards * self.replanYards then return c.result or nil end
  end
  local ctx = self:Context(target)
  local plan = self:Plan(pos, target, ctx)
  local leg = T.FirstTravelLeg(plan)
  local result = false
  if leg then
    result = { plan = plan, leg = leg, point = leg.kind ~= "hearth" and leg.from or nil,
      text = T.Instruction(leg), summary = T.Summary(plan) }
  end
  self.cache = { loc = loc, version = self.version, cont = pos.cont, wx = pos.wx, wy = pos.wy, at = now, result = result }
  return result or nil
end

function T:Invalidate()
  self.cache = nil
end
