-- Appearance ("Adapt to my interface", docs/ADAPTIVE_UI.md): FLC's look as a theme the player picks or that is built
-- from the interface they already use (ElvUI, Tukui or Blizzard's own), so FLC looks like part of it.
--
-- A theme: colours for each role of FLC's widgets (W.C keys), a font (nil = the game's), a font scale, a bar texture,
-- an edge style ("line" 1px borders, "tooltip" Blizzard's tooltip border, "none") and a window scale.
-- A profile: a built-in theme plus overrides (from an adapter or the manual editor). Profiles are kept per account, or
-- per character when the player asks; the previous profile is kept so one click restores it.
-- Pure logic: what the other interface looks like comes in as plain values (Core/Compat.lua reads it).
local _, ns = ...
local U = ns.U

local A = {}
ns.Appearance = A

A.ROLES = { "bg", "panel", "line", "ember", "teal", "text", "muted", "ok", "warn", "bad", "hover" }
A.EDGES = { line = true, tooltip = true, none = true }
A.WHITE = "Interface\\Buttons\\WHITE8X8"
A.TOOLTIP_BG = "Interface\\Tooltips\\UI-Tooltip-Background"
A.TOOLTIP_EDGE = "Interface\\Tooltips\\UI-Tooltip-Border"

local function c(r, g, b, a) return { r, g, b, a or 1 } end

-- Built-in themes. "flc" is FLC's own look (the default: nothing changes until the player picks something else).
A.THEMES = {
  flc = { name = "FLC", edge = "line", colors = {
    bg = c(0.055, 0.063, 0.082, 0.90), panel = c(0.098, 0.110, 0.137, 0.95), line = c(1, 1, 1, 0.08),
    ember = c(0.965, 0.616, 0.235), teal = c(0.247, 0.780, 0.737), text = c(0.925, 0.929, 0.945),
    muted = c(0.600, 0.624, 0.663), ok = c(0.420, 0.851, 0.471), warn = c(1.000, 0.800, 0.310),
    bad = c(1.000, 0.420, 0.380), hover = c(1, 1, 1, 0.07) } },
  -- Blizzard's default windows: tooltip background and border, gold titles, the game's font
  blizzlike = { name = "Blizzlike / Forever", edge = "tooltip", colors = {
    bg = c(0.02, 0.02, 0.03, 0.88), panel = c(0.10, 0.09, 0.08, 0.90), line = c(0.80, 0.80, 0.80, 1),
    ember = c(1.00, 0.82, 0.00), teal = c(0.40, 0.78, 1.00), text = c(1, 1, 1), muted = c(0.75, 0.75, 0.75),
    ok = c(0.25, 1.00, 0.25), warn = c(1.00, 0.82, 0.00), bad = c(1.00, 0.25, 0.25), hover = c(1, 0.82, 0, 0.10) } },
  -- flat dark panels with black 1px borders and one value colour, the look of ElvUI-style interfaces
  elvuilike = { name = "ElvUI-like", edge = "line", colors = {
    bg = c(0.06, 0.06, 0.06, 0.80), panel = c(0.10, 0.10, 0.10, 1), line = c(0, 0, 0, 1),
    ember = c(0.09, 0.52, 0.82), teal = c(0.09, 0.52, 0.82), text = c(1, 1, 1), muted = c(0.62, 0.62, 0.62),
    ok = c(0.30, 0.85, 0.30), warn = c(0.95, 0.78, 0.25), bad = c(0.90, 0.25, 0.25), hover = c(1, 1, 1, 0.10) } },
  minimal = { name = "Minimal", edge = "none", colors = {
    bg = c(0, 0, 0, 0.45), panel = c(0, 0, 0, 0.35), line = c(1, 1, 1, 0),
    ember = c(0.85, 0.85, 0.85), teal = c(0.70, 0.85, 0.90), text = c(0.95, 0.95, 0.95), muted = c(0.60, 0.60, 0.60),
    ok = c(0.55, 0.85, 0.55), warn = c(0.90, 0.80, 0.50), bad = c(0.90, 0.50, 0.50), hover = c(1, 1, 1, 0.06) } },
  fantasy = { name = "Fantasy", edge = "tooltip", colors = {
    bg = c(0.13, 0.08, 0.04, 0.92), panel = c(0.20, 0.13, 0.07, 0.95), line = c(0.78, 0.60, 0.30, 1),
    ember = c(1.00, 0.76, 0.30), teal = c(0.55, 0.85, 0.65), text = c(0.98, 0.93, 0.82), muted = c(0.74, 0.66, 0.54),
    ok = c(0.55, 0.88, 0.40), warn = c(1.00, 0.80, 0.35), bad = c(0.95, 0.40, 0.30), hover = c(1, 0.85, 0.5, 0.10) } },
}
A.ORDER = { "flc", "blizzlike", "elvuilike", "minimal", "fantasy" }

-- ---------------------------------------------------------------------------------------------------------------
-- Validation: everything that enters a profile (adapters, the editor, an imported string) goes through here.

local function num(v, lo, hi)
  if type(v) ~= "number" or v ~= v then return nil end
  return math.max(lo, math.min(hi, v))
end

function A.Color(v)
  if type(v) ~= "table" then return nil end
  local r, g, b = num(v[1] or v.r, 0, 1), num(v[2] or v.g, 0, 1), num(v[3] or v.b, 0, 1)
  if not (r and g and b) then return nil end
  return { r, g, b, num(v[4] or v.a, 0, 1) or 1 }
end

-- A media path inside the game's own folders only: no links, no escape sequences, nothing outside Fonts/Interface
function A.Media(v)
  if type(v) ~= "string" or #v > 200 or v:find("[|%c]") or v:find("%.%.") then return nil end
  local low = v:lower():gsub("/", "\\")
  if low:find("^fonts\\") or low:find("^interface\\") then return v end
  return nil
end

function A.Sanitize(o)
  local out = {}
  if type(o) ~= "table" then return out end
  if type(o.colors) == "table" then
    for _, role in ipairs(A.ROLES) do
      local col = A.Color(o.colors[role])
      if col then out.colors = out.colors or {}; out.colors[role] = col end
    end
  end
  out.font = A.Media(o.font)
  out.bar = A.Media(o.bar)
  out.fontScale = num(o.fontScale, 0.7, 1.5)
  out.scale = num(o.scale, 0.6, 1.6)
  if A.EDGES[o.edge] then out.edge = o.edge end
  return out
end

-- The theme a profile stands for: its built-in base with the overrides on top.
function A.Resolve(profile)
  profile = type(profile) == "table" and profile or {}
  local base = A.THEMES[profile.base] and profile.base or "flc"
  local t = U.deepcopy(A.THEMES[base])
  t.id, t.fontScale, t.scale, t.bar = base, 1, 1, A.WHITE
  local o = A.Sanitize(profile.overrides)
  for role, col in pairs(o.colors or {}) do t.colors[role] = col end
  t.font = o.font
  t.bar = o.bar or t.bar
  t.fontScale = o.fontScale or t.fontScale
  t.scale = o.scale or t.scale
  t.edge = o.edge or t.edge
  t.source = profile.source or "built-in"
  return t
end

-- ---------------------------------------------------------------------------------------------------------------
-- Adapters: a profile from what the other interface exposes (plain values read by Compat, nil when absent)

function A.FromElvUI(m)
  if type(m) ~= "table" then return nil end
  local o = { colors = {} }
  local bd, fade, border, value = A.Color(m.backdrop), A.Color(m.backdropFade), A.Color(m.border), A.Color(m.value)
  if fade then o.colors.bg = fade elseif bd then o.colors.bg = { bd[1], bd[2], bd[3], 0.8 } end
  if bd then o.colors.panel = bd end
  if border then o.colors.line = border end
  if value then o.colors.ember, o.colors.teal = value, value end
  o.font, o.bar = A.Media(m.font), A.Media(m.bar)
  if type(m.fontSize) == "number" then o.fontScale = num(m.fontSize / 12, 0.7, 1.5) end
  return { base = "elvuilike", overrides = o, source = "adapter:elvui" }
end

function A.FromTukui(m)
  if type(m) ~= "table" then return nil end
  local o = { colors = {} }
  local bd, border = A.Color(m.backdrop), A.Color(m.border)
  if bd then o.colors.bg, o.colors.panel = { bd[1], bd[2], bd[3], 0.8 }, bd end
  if border then o.colors.line = border end
  o.font, o.bar = A.Media(m.font), A.Media(m.bar)
  return { base = "elvuilike", overrides = o, source = "adapter:tukui" }
end

function A.FromBlizzard(m)
  m = type(m) == "table" and m or {}
  local o = { colors = {} }
  local gold = A.Color(m.normal)
  if gold then o.colors.ember, o.colors.warn = gold, gold end
  o.font = A.Media(m.font)
  return { base = "blizzlike", overrides = o, source = "adapter:blizzard" }
end

-- NDui, RealUI, SpartanUI, GW2 UI: the same reading as ElvUI's (panel, border, accent, font, bar) on the built-in
-- theme closest to each look; what an interface does not expose keeps the base theme's value.
A.INTERFACE_BASES = { ndui = "elvuilike", realui = "minimal", spartanui = "fantasy", gw2ui = "fantasy" }

function A.FromInterface(id, m)
  if type(m) ~= "table" or not A.INTERFACE_BASES[id] then return nil end
  local o = { colors = {} }
  local bd, border, value = A.Color(m.backdrop), A.Color(m.border), A.Color(m.value)
  if bd then o.colors.bg, o.colors.panel = bd, { bd[1], bd[2], bd[3], math.max(bd[4], 0.6) } end
  if border then o.colors.line = border end
  if value then o.colors.ember, o.colors.teal = value, value end
  o.font, o.bar = A.Media(m.font), A.Media(m.bar)
  if type(m.fontSize) == "number" then o.fontScale = num(m.fontSize / 12, 0.7, 1.5) end
  return { base = A.INTERFACE_BASES[id], overrides = o, source = "adapter:" .. id }
end

A.ADAPTERS = { elvui = A.FromElvUI, tukui = A.FromTukui, blizzard = A.FromBlizzard }
for id in pairs(A.INTERFACE_BASES) do A.ADAPTERS[id] = function(m) return A.FromInterface(id, m) end end

-- The profile "Adapt to my interface" proposes for what Compat detected ({ id, media, ... }).
function A.Adapt(detected)
  local f = detected and A.ADAPTERS[detected.id]
  return (f and f(detected.media)) or A.FromBlizzard(detected and detected.media)
end

-- What identifies the other interface's current look: when it changes, FLC offers to adapt again (checked at login,
-- never polled).
function A.Fingerprint(detected)
  if type(detected) ~= "table" or not detected.id then return nil end
  local parts = { detected.id, tostring(detected.version or "") }
  local m = detected.media or {}
  for _, k in ipairs(U.keys(m)) do
    local v = m[k]
    if type(v) == "table" then
      local col = A.Color(v)
      if col then v = string.format("%.3f,%.3f,%.3f,%.3f", col[1], col[2], col[3], col[4]) else v = "?" end
    end
    parts[#parts + 1] = tostring(k) .. "=" .. tostring(v)
  end
  return table.concat(parts, ";")
end

-- ---------------------------------------------------------------------------------------------------------------
-- Storage: account profile, or per character when the player asks. The previous profile stays for "Restore".

function A:Store()
  local char = ns.Config.char and ns.Config.char.appearance
  if char and char.perCharacter then return char end
  return ns.Config.account and ns.Config.account.settings.appearance
end

function A:Profile()
  local s = self:Store()
  return s and s.profile or { base = "flc" }
end

function A:Save(profile)
  local s = self:Store()
  if not s then return end
  local clean = { base = A.THEMES[profile.base] and profile.base or "flc", overrides = A.Sanitize(profile.overrides),
    source = type(profile.source) == "string" and profile.source:sub(1, 40) or nil }
  s.previous = U.deepcopy(s.profile)
  s.profile = clean
  return clean
end

function A:Restore()
  local s = self:Store()
  if not s or not s.previous then return false end
  s.profile, s.previous = s.previous, s.profile
  return true
end

function A:SetPerCharacter(on)
  local char = ns.Config.char and ns.Config.char.appearance
  if not char then return end
  if on and not char.perCharacter then char.profile = U.deepcopy(self:Profile()) end
  char.perCharacter = on and true or false
end

-- Did the other interface change since FLC last adapted to it? (the caller asks once per login)
function A:Changed(detected)
  local s = self:Store()
  local fp = A.Fingerprint(detected)
  return s and s.fingerprint and fp and s.fingerprint ~= fp and true or false
end

function A:Remember(detected)
  local s = self:Store()
  if s then s.fingerprint = A.Fingerprint(detected) end
end

-- ---------------------------------------------------------------------------------------------------------------
-- Export / import: a single line the player may copy; only validated settings come back in.

local function enc(v)
  if type(v) == "table" then return string.format("%.3f,%.3f,%.3f,%.3f", v[1], v[2], v[3], v[4] or 1) end
  return tostring(v)
end

function A.Export(profile)
  local o = A.Sanitize(profile and profile.overrides)
  local parts = { "FLC-APPEARANCE-1", "base=" .. (A.THEMES[profile and profile.base] and profile.base or "flc") }
  for _, role in ipairs(A.ROLES) do
    if o.colors and o.colors[role] then parts[#parts + 1] = role .. "=" .. enc(o.colors[role]) end
  end
  for _, k in ipairs({ "font", "bar", "fontScale", "scale", "edge" }) do
    if o[k] ~= nil then parts[#parts + 1] = k .. "=" .. enc(o[k]) end
  end
  return table.concat(parts, ";")
end

function A.Import(text)
  if type(text) ~= "string" or #text > 2000 then return nil, "not an FLC appearance" end
  local fields = {}
  for part in text:gmatch("[^;]+") do fields[#fields + 1] = part end
  if fields[1] ~= "FLC-APPEARANCE-1" then return nil, "not an FLC appearance" end
  local profile, o = { base = "flc" }, { colors = {} }
  local isRole = {}
  for _, r in ipairs(A.ROLES) do isRole[r] = true end
  for i = 2, #fields do
    local k, v = fields[i]:match("^(%w+)=(.*)$")
    if k == "base" and A.THEMES[v] then profile.base = v
    elseif k and isRole[k] then
      local t = {}
      for n in v:gmatch("[^,]+") do t[#t + 1] = tonumber(n) end
      o.colors[k] = t
    elseif k == "fontScale" or k == "scale" then o[k] = tonumber(v)
    elseif k == "font" or k == "bar" or k == "edge" then o[k] = v end
  end
  profile.overrides = A.Sanitize(o)
  profile.source = "import"
  return profile
end
