-- Quest Engine: quest metadata, per-character quest knowledge and availability rules.
-- Knowledge is tri-state on purpose: true / false / nil (unknown). Unknown is never treated as false,
-- so the addon cannot invent progress for party members whose data we have not received.
local _, ns = ...
local U = ns.U

local QE = { meta = {}, metaSource = {}, names = { npc = {}, object = {} } }
ns.Quest = QE

-- Names of the NPCs and objects that guide steps point at ("Kill: <name>"). The generated data has one file per
-- client language; a file for another language than the client's keeps nothing (English is the base).
function QE:RegisterNames(names, locale)
  if locale and ns.API and ns.API.GetLocale and locale ~= ns.API.GetLocale() then return false end
  for kind, list in pairs(names or {}) do
    local into = self.names[kind]
    if into then for id, name in pairs(list) do into[id] = name end end
  end
  return true
end

function QE:SourceName(kind, id)
  local list = self.names[kind]
  return list and list[id]
end

----------------------------------------------------------------------
-- Metadata
----------------------------------------------------------------------
-- Objective kinds describe what the player physically does; they decide who can help.
QE.OBJECTIVE_KINDS = {
  kill = "shared",        -- party kill credit: a helper's kill counts for the target
  loot = "assist",        -- mobs drop items only for players on the quest: helper kills, target loots
  gather = "assist",      -- world object: target must interact, helper can clear the area
  escort = "assist",      -- target starts the event, helper protects
  event = "assist",
  interact = "target-only",
  talk = "target-only",
  use = "target-only",
  explore = "target-only",
  deliver = "target-only",
}

-- Mapping from client objective types when the data file has no explicit kind.
QE.API_TYPE_TO_KIND = { monster = "kill", item = "loot", object = "gather", event = "event", reputation = "deliver", player = "kill", log = "event" }

local VALID_FACTIONS = { Alliance = true, Horde = true, Neutral = true }

function QE:ValidateMeta(q)
  local errs = {}
  if type(q.id) ~= "number" then errs[#errs + 1] = "id must be a number" end
  if q.level ~= nil and type(q.level) ~= "number" then errs[#errs + 1] = "level must be a number" end
  if q.minLevel ~= nil and type(q.minLevel) ~= "number" then errs[#errs + 1] = "minLevel must be a number" end
  if q.faction ~= nil and not VALID_FACTIONS[q.faction] then errs[#errs + 1] = "invalid faction" end
  for _, field in ipairs({ "prereq", "prereqAny", "exclusive", "classes", "races", "raceIDs", "requiresActive" }) do
    if q[field] ~= nil and type(q[field]) ~= "table" then errs[#errs + 1] = field .. " must be a list" end
  end
  if q.objectives then
    for i, o in ipairs(q.objectives) do
      if not QE.OBJECTIVE_KINDS[o.kind or ""] then errs[#errs + 1] = "objective " .. i .. " has unknown kind " .. tostring(o.kind) end
    end
  end
  return #errs == 0, errs
end

-- Registers quest metadata. Later registrations override earlier ones (corrections layer).
function QE:RegisterQuests(list, source)
  local accepted, rejected = 0, 0
  for _, q in ipairs(list) do
    local ok, errs = self:ValidateMeta(q)
    if ok then
      self.meta[q.id] = q
      self.metaSource[q.id] = source
      accepted = accepted + 1
    else
      rejected = rejected + 1
      ns.Diag:Warn("quest-data", (source or "?") .. " quest " .. tostring(q.id) .. ": " .. table.concat(errs, "; "))
    end
  end
  return accepted, rejected
end

function QE:Meta(questID) return self.meta[questID] end

function QE:Name(questID, state)
  local entry = state and state.log and state.log[questID]
  if entry and entry.title then return entry.title end
  local m = self.meta[questID]
  return (m and m.name) or ("Quest #" .. tostring(questID))
end

----------------------------------------------------------------------
-- Quest state of one character (self or party member)
----------------------------------------------------------------------
local State = {}
State.__index = State
QE.State = State

-- source: "self" (client API), "addon" (synced), "api" (party API probes only), "manual" (user input)
function QE.NewState(o)
  local s = setmetatable({}, State)
  s.key = o.key
  s.name = o.name or U.shortName(o.key)
  s.level = o.level
  s.class = o.class
  s.race = o.race
  s.raceID = o.raceID
  s.faction = o.faction
  s.source = o.source or "manual"
  s.log = o.log or {}
  s.logKnown = o.logKnown and true or false
  s.onQuest = o.onQuest or {}         -- partial knowledge: [questID] = true/false
  s.completion = o.completion or {}   -- partial knowledge: [questID] = true/false
  s.completedFull = o.completedFull and true or false
  s.turnedIn = o.turnedIn or {}
  s.updatedAt = o.updatedAt or ns.Now()
  return s
end

function State:IsCompleted(questID)
  if self.turnedIn[questID] then return true end
  local v = self.completion[questID]
  if v ~= nil then return v end
  if self.logKnown and self.log[questID] then return false end
  if self.completedFull then return false end
  return nil
end

function State:IsOnQuest(questID)
  if self.logKnown then return self.log[questID] ~= nil end
  local v = self.onQuest[questID]
  if v ~= nil then return v end
  return nil
end

function State:IsReady(questID)
  local q = self.log[questID]
  if q then return q.complete and true or false end
  if self.logKnown then return false end
  return nil
end

function State:Objective(questID, index)
  local q = self.log[questID]
  return q and q.objectives and q.objectives[index] or nil
end

-- Applies a turn-in: removes from log and records completion. Used for self and synced members.
function State:MarkTurnedIn(questID)
  -- keep the time Sync:OnQuestTurnedIn wrote (the self state shares Config.char.turnedIn): `true` would count as an
  -- old record and be dropped at the next rebuild, before the server's flag arrives (found in the client, 2026-10-27)
  self.turnedIn[questID] = self.turnedIn[questID] or (ns.API.WallTime and ns.API.WallTime()) or true
  self.completion[questID] = true
  self.log[questID] = nil
  self.onQuest[questID] = false
end

----------------------------------------------------------------------
-- Composite state: a group of characters seen as one subject for shared routes.
-- A quest step is done only when every member that benefits from the quest is done.
----------------------------------------------------------------------
local Composite = {}
Composite.__index = Composite
QE.Composite = Composite

-- states: { [key] = State }, who: { [questID] = {keys} } (beneficiaries per quest)
function QE.NewComposite(states, who)
  local c = setmetatable({ states = states, who = who or {}, log = {}, source = "composite" }, Composite)
  local minLevel
  for _, s in pairs(states) do
    if s.level and (not minLevel or s.level < minLevel) then minLevel = s.level end
  end
  c.level = minLevel
  return c
end

-- Combines tri-state answers: any false -> false, else any nil -> nil, else true.
local function combine(c, questID, fn)
  local keys = c.who[questID]
  if not keys or #keys == 0 then return nil end
  local unknown = false
  for _, key in ipairs(keys) do
    local s = c.states[key]
    local v
    if s then v = fn(s) end
    if v == false then return false end
    if v == nil then unknown = true end
  end
  if unknown then return nil end
  return true
end

function Composite:IsCompleted(questID)
  return combine(self, questID, function(s) return s:IsCompleted(questID) end)
end

function Composite:IsOnQuest(questID)
  return combine(self, questID, function(s)
    local c, o = s:IsCompleted(questID), s:IsOnQuest(questID)
    if c == true or o == true then return true end
    if c == false and o == false then return false end
    return nil
  end)
end

function Composite:IsReady(questID)
  return combine(self, questID, function(s)
    if s:IsCompleted(questID) == true then return true end
    return s:IsReady(questID)
  end)
end

function Composite:Objective() return nil end

----------------------------------------------------------------------
-- Rules
----------------------------------------------------------------------
-- Availability for one character: returns status, reasons.
-- status: "completed" | "ready" | "active" | "available" | "unavailable" | "unknown"
function QE:Availability(state, questID)
  local done = state:IsCompleted(questID)
  if done == true then return "completed", {} end
  local on = state:IsOnQuest(questID)
  if on == true then
    if state:IsReady(questID) then return "ready", {} end
    return "active", {}
  end
  local m = self.meta[questID]
  local reasons = {}
  local unknown = (done == nil) or (on == nil)
  if m then
    if m.faction and state.faction and m.faction ~= "Neutral" and m.faction ~= state.faction then reasons[#reasons + 1] = "faction" end
    if m.classes and state.class and not U.contains(m.classes, state.class) then reasons[#reasons + 1] = "class" end
    if m.races and state.race and not U.contains(m.races, state.race) then reasons[#reasons + 1] = "race" end
    if m.raceIDs and state.raceID and not U.contains(m.raceIDs, state.raceID) then reasons[#reasons + 1] = "race" end
    if m.requiresActive then
      for _, p in ipairs(m.requiresActive) do
        local on = state:IsOnQuest(p)
        if on == false then reasons[#reasons + 1] = "requires-active:" .. p
        elseif on == nil then unknown = true end
      end
    end
    if m.minLevel and state.level and state.level < m.minLevel then reasons[#reasons + 1] = "level" end
    if m.prereq then
      for _, p in ipairs(m.prereq) do
        local c = state:IsCompleted(p)
        if c == false then reasons[#reasons + 1] = "prereq:" .. p
        elseif c == nil then unknown = true end
      end
    end
    if m.prereqAny and #m.prereqAny > 0 then
      local any, anyUnknown = false, false
      for _, p in ipairs(m.prereqAny) do
        local c = state:IsCompleted(p)
        if c == true then any = true elseif c == nil then anyUnknown = true end
      end
      if not any and not anyUnknown then reasons[#reasons + 1] = "prereq-any" end
      if not any and anyUnknown then unknown = true end
    end
    if m.exclusive then
      for _, x in ipairs(m.exclusive) do
        if state:IsCompleted(x) == true or state:IsOnQuest(x) == true then reasons[#reasons + 1] = "exclusive:" .. x end
      end
    end
  else
    unknown = true
  end
  if #reasons > 0 then return "unavailable", reasons end
  if unknown then return "unknown", reasons end
  return "available", reasons
end

local PENDING = { ready = true, active = true, available = true }
function QE:IsPending(status) return PENDING[status] == true end

-- Kind of each objective for a character that has the quest in its log.
function QE:ObjectiveKinds(questID, state)
  local kinds = {}
  local m = self.meta[questID]
  local entry = state and state.log[questID]
  local n = math.max(m and m.objectives and #m.objectives or 0, entry and #entry.objectives or 0)
  for i = 1, n do
    local mo = m and m.objectives and m.objectives[i]
    local eo = entry and entry.objectives[i]
    local kind = mo and mo.kind
    local estimated = false
    if not kind and eo then
      kind = QE.API_TYPE_TO_KIND[eo.type or ""]
      estimated = true
    end
    kinds[i] = { kind = kind or "interact", estimated = estimated or kind == nil, label = (mo and mo.label) or (eo and eo.text) or "?" }
  end
  return kinds
end

-- Classifies a quest for "helper assists target". Never claims a helper action is possible
-- unless the objective kind allows it.
function QE:ClassifyForHelp(helper, target, questID)
  local m = self.meta[questID]
  local me, meReasons = self:Availability(helper, questID)
  local them, themReasons = self:Availability(target, questID)
  local r = {
    questID = questID,
    me = me, meReasons = meReasons,
    target = them, targetReasons = themReasons,
    flags = {},
    objectives = {},
  }
  local f = r.flags
  f.pendingMe = self:IsPending(me)
  f.pendingTarget = self:IsPending(them)
  f.doneMeCanHelp = (me == "completed") and f.pendingTarget
  f.inaccessibleMe = (me == "unavailable")
  local shareable = not (m and m.shareable == false)
  f.shareable = shareable and (
    (me == "active" and them == "available") or (them == "active" and me == "available"))

  local kinds = self:ObjectiveKinds(questID, target)
  local helpful, targetOnly = 0, 0
  for i, k in ipairs(kinds) do
    local o = target:Objective(questID, i)
    local mode = QE.OBJECTIVE_KINDS[k.kind] or "target-only"
    local done = o and o.done or false
    r.objectives[i] = {
      index = i, kind = k.kind, help = mode, estimated = k.estimated, label = k.label,
      have = o and o.have, need = o and o.need, done = done,
    }
    if not done then
      if mode == "target-only" then targetOnly = targetOnly + 1 else helpful = helpful + 1 end
    end
  end
  f.targetOnly = f.pendingTarget and helpful == 0 and targetOnly > 0
  f.helpful = f.pendingTarget and helpful > 0
  return r
end

----------------------------------------------------------------------
-- Level / XP estimation (Classic-era formulas; labelled as estimates everywhere they are shown)
----------------------------------------------------------------------
function QE.GrayLevel(level)
  if level <= 5 then return 0 end
  if level <= 39 then return level - 5 - math.floor(level / 10) end
  if level <= 59 then return level - 1 - math.floor(level / 5) end
  return level - 9
end

function QE.DifficultyColor(playerLevel, questLevel)
  if not playerLevel or not questLevel then return "unknown" end
  local d = questLevel - playerLevel
  if d >= 5 then return "red" end
  if d >= 3 then return "orange" end
  if d >= -2 then return "yellow" end
  if questLevel > QE.GrayLevel(playerLevel) then return "green" end
  return "gray"
end

function QE.XPFactor(playerLevel, questLevel)
  local d = playerLevel - questLevel
  if d <= 5 then return 1 end
  if d == 6 then return 0.8 end
  if d == 7 then return 0.6 end
  if d == 8 then return 0.4 end
  if d == 9 then return 0.2 end
  return 0.1
end

-- Returns xp, isEstimate.
function QE:QuestXP(questID, playerLevel)
  local m = self.meta[questID]
  if not m or not playerLevel then return 0, true end
  if playerLevel >= 60 then return 0, false end
  local qL = m.level or m.minLevel or playerLevel
  local base, estimate = m.xp, false
  if not base then
    base = 25 * qL + 2 * qL * qL
    estimate = true
  end
  return math.floor(base * QE.XPFactor(playerLevel, qL)), estimate
end

----------------------------------------------------------------------
-- Local player
----------------------------------------------------------------------
-- Seconds a turn-in we saw ourselves counts while the server's completed flag catches up.
QE.TURNIN_LAG = 120

-- Builds the authoritative state of the logged-in character from the client.
function QE:BuildSelfState(previous)
  local API = ns.API
  local p = API.GetPlayerInfo()
  local completed, full = API.GetCompletedQuests()
  local turnedIn = previous and previous.turnedIn or (ns.Config.char and ns.Config.char.turnedIn) or {}
  local log = API.GetQuestLog()
  local now = API.WallTime and API.WallTime()
  -- Server flags can lag behind QUEST_TURNED_IN; our own records fill that window, and only that window. Found in the
  -- client (2026-10-24): a record kept forever outlived a quest the server reset, and the guide skipped its turn-in.
  -- A quest the client cannot flag (catalog `noFlag`: not in its QuestV2) never catches up, so its record stays until
  -- the quest is in the log again. Found by the 30-60 walks (2026-10-27): 841, 3861, 4973 and 9165.
  -- The quest log can still list a quest just after its QUEST_TURNED_IN: only an older record gives way to it.
  for id, at in pairs(turnedIn) do
    local recent = type(at) == "number" and now ~= nil and now - at < QE.TURNIN_LAG
    local m = self.meta[id]
    if (log[id] and not recent) or completed[id] or (full and not recent and not (m and m.noFlag)) then
      turnedIn[id] = nil
    end
  end
  local completion = {}
  for id in pairs(completed) do completion[id] = true end
  for id in pairs(turnedIn) do completion[id] = true end
  return QE.NewState({
    key = p.key, name = p.name, level = p.level, class = p.class, race = p.race, raceID = p.raceID, faction = p.faction,
    source = "self", log = log, logKnown = true,
    completion = completion, completedFull = full, turnedIn = turnedIn,
  })
end
