-- Leveling path 1-60 (docs/LEVELING_PATH.md): which route (zone, visit) comes next for the character's race, from the
-- catalog pack (tools/catalog/leveling_path.py builds it with the routes). A segment is { guide, from, to }: follow
-- that route from level `from` until level `to`. A route can come back later in the path; the guide engine keeps its
-- cursor, so the player resumes where they left it. Levels no route covers are "grind or dungeons" (gaps between
-- segments). Pure logic: no client calls.
local _, ns = ...

local P = { byRace = {} }
ns.Path = P

-- pack:LevelingPaths({ { race = 2, faction = "Horde", questShare = 0.62, grindLevels = {...},
--                        segments = { { "db.horde.363", 1, 4 }, ... } }, ... })
function P:Register(list)
  local n = 0
  for _, p in ipairs(type(list) == "table" and list or {}) do
    if type(p) == "table" and type(p.race) == "number" and type(p.segments) == "table" then
      local segs = {}
      for _, s in ipairs(p.segments) do
        if type(s) == "table" and type(s[1]) == "string" and type(s[2]) == "number" and type(s[3]) == "number" then
          segs[#segs + 1] = { guide = s[1], from = s[2], to = s[3] }
        end
      end
      if #segs > 0 then
        self.byRace[p.race] = { race = p.race, faction = p.faction, segments = segs, questShare = p.questShare,
          grindLevels = p.grindLevels or {} }
        n = n + 1
      end
    end
  end
  return n
end

function P:For(subject)
  return subject and subject.raceID and self.byRace[subject.raceID] or nil
end

-- Where the character stands on its path:
--   current: the segment of the guide being followed, if that guide is on the path for this level
--   target: the first segment whose levels are not passed yet (what the path says to do now)
--   next: what comes after the current guide (or the target, when the current guide is not on the path)
--   grindTo: when the level is between segments, the level the next segment starts at
-- Segments whose guide is not registered (an older or partial catalog) are skipped.
function P:Position(subject, currentGuideID)
  local path = self:For(subject)
  if not path then return nil end
  local level = subject.level or 1
  local GE = ns.Guide
  local function known(s) return GE and GE.guides and GE.guides[s.guide] ~= nil end
  -- a segment is still open while its levels are not passed; a one-level visit ("Alterac 28-28") at that level too
  local function open(s) return level < s.to or (level == s.to and s.from == s.to) end
  local out = { path = path }
  for i, s in ipairs(path.segments) do
    if known(s) and open(s) then
      if not out.target then out.target, out.targetIndex = s, i end
      -- the guide being followed is "current" only for a visit that has begun (not a later return to that zone)
      if s.guide == currentGuideID and not out.current and s.from <= level + 1 then out.current, out.currentIndex = s, i end
    end
  end
  local after = out.currentIndex or (out.targetIndex and out.targetIndex - 1) or #path.segments
  for i = after + 1, #path.segments do
    local s = path.segments[i]
    if known(s) and s.guide ~= currentGuideID and open(s) then
      out.next, out.nextIndex = s, i
      break
    end
  end
  if not out.current and out.target and out.target.guide ~= currentGuideID then
    out.next, out.nextIndex = out.target, out.targetIndex
  end
  -- a gap between the current route's levels and the next one: grind or dungeons; no gap when the next route starts
  -- where the current one ends (reaching that level is the current route's job)
  local reach = out.current and out.current.to or level
  if out.next and level < out.next.from and reach < out.next.from then out.grindTo = out.next.from end
  return out
end

-- The guide the path says to follow now (for GuideEngine:SuggestGuide), or nil.
function P:Suggest(subject)
  local pos = self:Position(subject, nil)
  return pos and pos.target or nil
end
