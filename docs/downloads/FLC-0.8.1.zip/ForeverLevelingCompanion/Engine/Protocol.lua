-- Addon-to-addon protocol (versioned, text based, one message <= 255 bytes).
-- Wire format: <version>^<type>^<session>^<seq>^<field>^<field>...   Fields are percent-escaped.
-- <session> is a random token chosen at load, so a /reload restarts sequence numbers safely.
-- Unknown types are ignored, malformed messages are counted and dropped, and a newer major
-- version marks the sender as incompatible instead of guessing. See docs/PROTOCOL.md.
local _, ns = ...
local U = ns.U

local P = {
  prefix = "FLComp",
  maxBytes = 255,
  seq = 0,
  session = "0",
  queue = {},
  -- Conservative local bucket below the documented server limit (10 burst, 1/s regen per prefix).
  bucket = { tokens = 8, capacity = 8, regen = 0.8, last = nil },
  handlers = {},
  inbox = {},       -- multi-part reassembly: [sender] = { [snap] = {parts, total, at} }
  lastSeq = {},     -- [sender] = { session, seq } of the last message accepted
  -- Messages from someone the roster does not list yet (their message arrived before GROUP_ROSTER_UPDATE): kept a
  -- short while and handled when they join. Measured in the client: a hello dropped this way left the member
  -- "pending" until their next quest change.
  early = {},       -- [sender] = { { msg, now }, ... }
  earlyTTL = 30, earlyMax = 30,
  isKnown = nil,    -- function(sender) -> bool, set by the Party Engine; nil = every sender is handled at once
}
ns.Protocol = P

P.TYPES = {
  H = "hello", S = "state", L = "questlog", O = "objective", T = "turnin", A = "abandon",
  Q = "query", R = "reply", P = "propose", Y = "answer", K = "help", F = "refresh", B = "bye",
}
-- Lower is sent first.
P.PRIORITY = { H = 1, B = 1, Y = 1, K = 1, P = 2, S = 3, O = 3, T = 3, A = 3, F = 3, R = 4, Q = 4, L = 5 }

----------------------------------------------------------------------
-- Encoding
----------------------------------------------------------------------
function P.Escape(s)
  s = tostring(s == nil and "" or s)
  return (string.gsub(s, "[%%%^|%c]", function(c) return string.format("%%%02X", string.byte(c)) end))
end

function P.Unescape(s)
  return (string.gsub(s, "%%(%x%x)", function(h) return string.char(tonumber(h, 16)) end))
end

function P.NewSession(seed)
  local n = math.floor(seed or 0) % 2176782336
  local digits, out = "0123456789abcdefghijklmnopqrstuvwxyz", ""
  repeat
    local d = n % 36
    out = string.sub(digits, d + 1, d + 1) .. out
    n = math.floor(n / 36)
  until n == 0
  P.session = out
  return out
end

function P.Encode(mtype, seq, fields)
  local parts = { tostring(ns.protocolVersion), mtype, P.session, tostring(seq) }
  for _, f in ipairs(fields or {}) do parts[#parts + 1] = P.Escape(f) end
  return table.concat(parts, "^")
end

-- Returns msg or nil, error.
function P.Decode(text)
  if type(text) ~= "string" or text == "" then return nil, "empty" end
  if #text > P.maxBytes then return nil, "too-long" end
  local raw = U.split(text, "^")
  local version = tonumber(raw[1])
  if not version then return nil, "bad-version" end
  local mtype, session = raw[2], raw[3]
  local seq = tonumber(raw[4])
  if not mtype or not session or not seq then return nil, "bad-header" end
  local fields = {}
  for i = 5, #raw do fields[#fields + 1] = P.Unescape(raw[i]) end
  return { version = version, type = mtype, session = session, seq = seq, fields = fields }
end

-- Quest log entry: "qid:ready:have/need.have/need"
function P.EncodeQuestEntry(q)
  local objs = {}
  for i, o in ipairs(q.objectives or {}) do
    objs[i] = string.format("%d/%d%s", o.have or 0, o.need or 0, o.done and "" or "-")
  end
  return string.format("%d:%d:%s", q.questID, q.complete and 1 or 0, table.concat(objs, "."))
end

function P.DecodeQuestEntry(s)
  local qid, ready, objs = string.match(s, "^(%d+):([01]):(.*)$")
  if not qid then return nil end
  local q = { questID = tonumber(qid), complete = ready == "1", objectives = {} }
  for _, part in ipairs(U.split(objs, ".")) do
    local have, need, open = string.match(part, "^(%d+)/(%d+)(%-?)$")
    if have then
      q.objectives[#q.objectives + 1] = { have = tonumber(have), need = tonumber(need), done = open ~= "-" }
    end
  end
  return q
end

-- Packs list items into fields so that each encoded message stays under maxBytes.
function P.Chunk(items, headerBytes)
  local chunks, current, size = {}, {}, headerBytes
  for _, it in ipairs(items) do
    local len = #it + 1
    if size + len > P.maxBytes and #current > 0 then
      chunks[#chunks + 1] = current
      current, size = {}, headerBytes
    end
    current[#current + 1] = it
    size = size + len
  end
  if #current > 0 or #chunks == 0 then chunks[#chunks + 1] = current end
  return chunks
end

----------------------------------------------------------------------
-- Sending (queued, coalesced, throttled)
----------------------------------------------------------------------
function P:NextSeq()
  self.seq = self.seq + 1
  return self.seq
end

-- coalesceKey: a pending message with the same key is replaced (e.g. only the latest STATE).
-- The sequence number is given when the message is sent, not when it is queued: the queue sends by priority (HELLO
-- first), and numbers given at queue time made a receiver drop the older-numbered STATE / QUEST LOG that followed as
-- stale (measured between two clients: a member stayed "pending").
function P:Queue(mtype, fields, coalesceKey, channel)
  local text = P.Encode(mtype, 9999999, fields)   -- size check with a long sequence number
  if #text > self.maxBytes then
    ns.Diag:Error("protocol", "message too long: " .. mtype .. " " .. #text)
    return false
  end
  if coalesceKey then
    for i = #self.queue, 1, -1 do
      if self.queue[i].key == coalesceKey then table.remove(self.queue, i) end
    end
  end
  self.queue[#self.queue + 1] = { type = mtype, fields = fields, key = coalesceKey, prio = P.PRIORITY[mtype] or 5, at = ns.Now(), channel = channel }
  table.sort(self.queue, function(a, b)
    if a.prio ~= b.prio then return a.prio < b.prio end
    return a.at < b.at
  end)
  return true
end

function P:Refill(now)
  local b = self.bucket
  if not b.last then b.last = now end
  b.tokens = math.min(b.capacity, b.tokens + (now - b.last) * b.regen)
  b.last = now
end

-- Called from the frame ticker. `send` is injectable for tests.
function P:Flush(now, send)
  send = send or ns.API.SendAddonMessage
  self:Refill(now)
  local channel = ns.API.GetGroupChannel and ns.API.GetGroupChannel()
  if not channel then
    -- Not grouped: nothing can be delivered; drop stale traffic but keep HELLO for later.
    for i = #self.queue, 1, -1 do
      if self.queue[i].type ~= "H" then table.remove(self.queue, i) end
    end
    return 0
  end
  local sent = 0
  while #self.queue > 0 and self.bucket.tokens >= 1 do
    local m = self.queue[1]
    m.text = m.text or P.Encode(m.type, self:NextSeq(), m.fields)   -- numbered in sending order
    local result = send(self.prefix, m.text, m.channel or channel)
    if result == "ok" then
      table.remove(self.queue, 1)
      self.bucket.tokens = self.bucket.tokens - 1
      sent = sent + 1
      ns.Diag:Count("proto.sent")
    elseif result == "throttled" then
      self.bucket.tokens = 0
      ns.Diag:Count("proto.throttled")
      break
    elseif result == "lockdown" then
      -- Encounter lockdown: keep the queue and retry later.
      ns.Diag:Count("proto.lockdown")
      break
    else
      table.remove(self.queue, 1)
      ns.Diag:Warn("protocol", "send failed " .. tostring(result) .. " type " .. m.type)
      ns.Diag:Count("proto.failed")
      if result == "unavailable" then break end
    end
  end
  return sent
end

----------------------------------------------------------------------
-- Receiving
----------------------------------------------------------------------
function P:On(mtype, fn) self.handlers[mtype] = fn end

function P:Receive(sender, text, now)
  local msg, err = P.Decode(text)
  if not msg then
    ns.Diag:Count("proto.malformed")
    ns.Diag:Debug("protocol", "malformed from " .. tostring(sender) .. ": " .. tostring(err))
    return false, err
  end
  if msg.version > ns.protocolVersion then
    -- Newer peer: only HELLO is understood across versions (its layout is frozen).
    if msg.type ~= "H" then
      ns.Bus:Fire("PROTO_INCOMPATIBLE", sender, msg.version)
      return false, "newer-version"
    end
  elseif msg.version < ns.protocolMin then
    ns.Bus:Fire("PROTO_INCOMPATIBLE", sender, msg.version)
    return false, "older-version"
  end
  -- Stale = older than the last message of the same stream from that sender's session: HELLOs are one stream, all
  -- data messages (state, quest log, objectives...) another, so a late old objective is still dropped after newer data.
  -- Separate streams because FLC up to 0.4.0 numbered messages when queued and sent HELLO first: its STATE / QUEST LOG
  -- then arrived with lower numbers than the HELLO and were dropped (measured between two clients).
  local last = self.lastSeq[sender]
  if not last or last.session ~= msg.session then
    last = { session = msg.session, seq = {} }
    self.lastSeq[sender] = last
  end
  local stream = msg.type == "H" and "H" or "data"
  if last.seq[stream] and msg.seq <= last.seq[stream] then
    ns.Diag:Count("proto.out-of-order")
    return false, "stale"
  end
  last.seq[stream] = msg.seq
  if self.isKnown and not self.isKnown(sender) then
    local list = self.early[sender] or {}
    self.early[sender] = list
    if #list >= self.earlyMax then table.remove(list, 1) end
    list[#list + 1] = { msg = msg, now = now }
    ns.Diag:Count("proto.early")
    return false, "early"
  end
  return self:Dispatch(sender, msg, now)
end

function P:Dispatch(sender, msg, now)
  local h = self.handlers[msg.type]
  if not h then
    ns.Diag:Count("proto.unknown-type")
    return false, "unknown-type"
  end
  local ok, herr = pcall(h, sender, msg.fields, msg, now)
  if not ok then
    ns.Diag:Error("protocol:" .. msg.type, herr)
    return false, "handler-error"
  end
  return true
end

-- Handles what `sender` sent before joining the roster, in arrival order; anything older than earlyTTL is dropped.
function P:Replay(sender, now)
  local list = self.early[sender]
  self.early[sender] = nil
  local handled = 0
  for _, e in ipairs(list or {}) do
    if now - e.now <= self.earlyTTL and self:Dispatch(sender, e.msg, e.now) then handled = handled + 1 end
  end
  return handled
end

-- Multi-part quest log reassembly. Returns the full entry list when the snapshot is complete.
function P:Assemble(sender, snap, part, total, entries, now)
  local box = self.inbox[sender]
  if not box or box.snap ~= snap then
    box = { snap = snap, parts = {}, total = total, at = now }
    self.inbox[sender] = box
  end
  box.parts[part] = entries
  local all = {}
  for i = 1, total do
    if not box.parts[i] then return nil end
    for _, e in ipairs(box.parts[i]) do all[#all + 1] = e end
  end
  self.inbox[sender] = nil
  return all
end

function P:Reset()
  self.queue, self.inbox, self.lastSeq, self.seq = {}, {}, {}, 0
  self.bucket.tokens, self.bucket.last = self.bucket.capacity, nil
end
