-- Dungeon Quest Advisor (D4, docs/DUNGEON_ADVISOR.md): why a dungeon is worth a visit for this character (its quests to
-- do, first visit, the quests' XP, a class quest of the character inside), and the preparation when the player chooses
-- it: quests to pick up first (giver and place), quests not open yet (and why), quests already in the log, then the
-- entrance. The leveling mode (Engine/Modes.lua) decides whether a dungeon is suggested at all; this adds the reasons
-- and the plan. Nothing waits for a group and nothing searches for one: the game's own group finder is only opened.
-- Quest XP is the client's QuestXP at the quest's level times Forever's multiplier, as a range when the Forever
-- bonus is not confirmed for that quest (docs/research/DUNGEON_XP.md); kill XP is never used. Pure logic.
local _, ns = ...

local DA = { info = {} }
ns.DungeonAdvisor = DA

-- reasons a quest is closed that no preparation can change: the quest is not for this character
DA.NOT_FOR_YOU = { faction = true, class = true, race = true }

function DA:Register(map, source)
  local n = 0
  for id, info in pairs(type(map) == "table" and map or {}) do
    if type(id) == "string" and type(info) == "table" then
      self.info[id] = info
      n = n + 1
    end
  end
  self.source = source
  return n
end

function DA:Info(id) return self.info[id] end

-- vanilla rule the server uses (QuestDef.cpp XPValue): full XP up to 5 levels above the quest, then 80/60/40/20%, then 10%
function DA.LevelFactor(levelsAbove)
  if levelsAbove <= 5 then return 1 end
  return ({ [6] = 0.8, [7] = 0.6, [8] = 0.4, [9] = 0.2 })[levelsAbove] or 0.1
end

-- XP of one dungeon quest for a character of `level`: lowest, highest (the same when the value is
-- Forever's confirmed one); nil without data.
function DA.QuestXP(q, level)
  if type(q) ~= "table" or not q.xp or not q.level or not level then return nil end
  local f = DA.LevelFactor(level - q.level)
  -- rounded up as the server does, which computes in single precision: 1550 x 2.2 is 3410 there, 3410.0000000000005
  -- in Lua's doubles; the relative noise below 1e-7 is dropped first
  local function up(v) return math.ceil(v * (1 - 1e-7)) end
  local lo = up(q.xp * (q.mult or 1) * f)
  local hi = q.multMax and up(q.xp * q.multMax * f) or lo
  return lo, hi
end

local function notForYou(reasons)
  for _, r in ipairs(reasons or {}) do
    if DA.NOT_FOR_YOU[r] or string.find(r, "^exclusive:") then return true end
  end
  return false
end

-- A class quest of the advisor (Engine/Advisor.lua) for this character whose chain has one of the dungeon's quests.
function DA:ClassChain(state, questSet)
  local AD = ns.Advisor
  if not AD or not state.class then return nil end
  for _, e in ipairs(AD.entries or {}) do
    if e.classes and e.classes[state.class] then
      for _, qid in ipairs(e.chain or { e.quest }) do
        if questSet[qid] then return e end
      end
    end
  end
  return nil
end

-- What the dungeon holds for the character:
--   { dungeon, info, inLog = {}, toPick = {}, notYet = {}, done = {}, notForYou = {} (entries { id, status, reasons }),
--     pending, firstVisit, xpMin, xpMax, xpUnknown (pending quests without XP data), xpConfirmed (pending quests whose XP
--     is Forever's confirmed value), classChain, finder, reasons = { codes } }
function DA:Evaluate(state, d)
  local QE, info = ns.Quest, self.info[d.id]
  local ev = { dungeon = d, info = info, inLog = {}, toPick = {}, notYet = {}, done = {}, notForYou = {},
    xpMin = 0, xpMax = 0, xpUnknown = 0, xpConfirmed = 0 }
  local set = {}
  for _, qid in ipairs(ns.Route.DungeonQuests(d)) do
    set[qid] = true
    local status, reasons = QE:Availability(state, qid)
    local e = { id = qid, status = status, reasons = reasons }
    local list
    if status == "completed" then list = ev.done
    elseif status == "active" or status == "ready" then list = ev.inLog
    elseif status == "available" then list = ev.toPick
    elseif notForYou(reasons) then list = ev.notForYou
    else list = ev.notYet end
    list[#list + 1] = e
    if list == ev.inLog or list == ev.toPick then
      local q = info and info.quests and info.quests[qid]
      local lo, hi = DA.QuestXP(q, state.level)
      if lo then
        ev.xpMin, ev.xpMax = ev.xpMin + lo, ev.xpMax + hi
        if q.forever then ev.xpConfirmed = ev.xpConfirmed + 1 end
      else
        ev.xpUnknown = ev.xpUnknown + 1
      end
    end
  end
  ev.pending = #ev.inLog + #ev.toPick
  ev.firstVisit = #ev.done == 0
  ev.classChain = self:ClassChain(state, set)
  -- items of the character's wishlist (Loot Atlas) this dungeon drops: wanted and interesting ones
  ev.wishlist = ns.LootAtlas and ns.LootAtlas:WishlistIn(d.id) or {}
  ev.finder = info and info.finder or false
  local r = {}
  if ev.pending > 0 then r[#r + 1] = "pending" end
  if ev.firstVisit and ev.pending > 0 then r[#r + 1] = "first-visit" end
  if ev.xpMax > 0 then r[#r + 1] = ev.xpConfirmed > 0 and "xp-forever" or "xp-range" end
  if ev.classChain then r[#r + 1] = "class-quest" end
  if #ev.wishlist > 0 then r[#r + 1] = "wishlist" end
  if #ev.notYet > 0 then r[#r + 1] = "not-yet" end
  ev.reasons = r
  return ev
end

-- The dungeon the leveling mode suggests now, evaluated; nil when none.
function DA:Suggestion(state, mode)
  local MO = ns.Modes
  local pick = MO and MO:Dungeon(state, mode)
  if not pick then return nil end
  return self:Evaluate(state, pick.dungeon)
end

----------------------------------------------------------------------
-- Preparation (the player chose the dungeon)
----------------------------------------------------------------------
local function store()
  local char = ns.Session and ns.Session.char
  if not char then return nil end
  char.leveling = type(char.leveling) == "table" and char.leveling or {}
  return char.leveling
end

function DA:Preparing()
  local l = store()
  return l and l.prep or nil
end

function DA:Prepare(id, level)
  local l = store()
  if not l or type(id) ~= "string" then return false end
  l.prep = { id = id, level = level }
  if ns.Bus then ns.Bus:Fire("DUNGEON_PREP_CHANGED", id) end
  return true
end

-- Back to the normal route: the preparation ends; the dungeon's decisions (Later / Skip) are untouched.
function DA:EndPrep()
  local l = store()
  if not l or not l.prep then return false end
  l.prep = nil
  if ns.Bus then ns.Bus:Fire("DUNGEON_PREP_CHANGED", nil) end
  return true
end

local function questLoc(qid)
  local m = ns.Quest.meta[qid]
  return m and m.start
end

-- The preparation as steps, in this order: pick up (grouped by giver), started inside, already in the log, not open
-- yet, entrance.
--   { kind = "pickup" | "inside" | "carry" | "blocked" | "entrance", quest, giver, loc, why }
-- `done` is true when nothing is left to do there (every quest handed in or out of reach): the route goes on.
function DA:Steps(state, id)
  local d
  for _, x in ipairs(ns.Route.dungeons or {}) do if x.id == id then d = x end end
  if not d then return nil end
  local ev = self:Evaluate(state, d)
  local info, steps = ev.info, {}
  local function giverOf(qid)
    local q = info and info.quests and info.quests[qid]
    if not q then return nil end
    return (q.giver and ns.Quest:SourceName("npc", q.giver)) or q.giverName
  end
  local picks, inside = {}, {}
  for _, e in ipairs(ev.toPick) do
    local giver, loc = giverOf(e.id), questLoc(e.id)
    if giver or loc then
      picks[#picks + 1] = { kind = "pickup", quest = e.id, giver = giver, loc = loc }
    else
      -- no giver and no place outside: started inside the dungeon (an NPC there, an item it drops)
      inside[#inside + 1] = { kind = "inside", quest = e.id }
    end
  end
  table.sort(picks, function(a, b)
    if (a.giver or "") ~= (b.giver or "") then return (a.giver or "") < (b.giver or "") end
    return a.quest < b.quest
  end)
  for _, s in ipairs(picks) do steps[#steps + 1] = s end
  for _, s in ipairs(inside) do steps[#steps + 1] = s end
  for _, e in ipairs(ev.inLog) do steps[#steps + 1] = { kind = "carry", quest = e.id, ready = e.status == "ready" } end
  for _, e in ipairs(ev.notYet) do
    local why = e.reasons and e.reasons[1] or e.status
    steps[#steps + 1] = { kind = "blocked", quest = e.id, why = why, giver = giverOf(e.id) }
  end
  if info and info.entrance then steps[#steps + 1] = { kind = "entrance", loc = info.entrance } end
  return { dungeon = d, ev = ev, steps = steps, done = ev.pending == 0 }
end

-- Party Mode before going in (request section 8): per dungeon quest that matters to someone in the group, who has it
-- in the log, who can take it now, who needs something first (and what), who already handed it in, and whose
-- progress FLC cannot read. "share" is true when someone has it and someone else could take it: the game decides
-- whether the quest can really be shared. members = Session:GroupMembers(). Quests nobody can do are left out.
--   { { id, inLog = { names }, canTake = { names }, needs = { { name, why } }, done = { names }, unknown = { names },
--       share = bool, deps = { quest ids it needs } }, ... }
function DA:PartyView(members, d)
  local QE, out = ns.Quest, {}
  for _, qid in ipairs(ns.Route.DungeonQuests(d)) do
    local row = { id = qid, inLog = {}, canTake = {}, needs = {}, done = {}, unknown = {} }
    for _, m in ipairs(members or {}) do
      local name = m.name or m.key or "?"
      if not m.state then
        row.unknown[#row.unknown + 1] = name
      else
        local status, reasons = QE:Availability(m.state, qid)
        if status == "completed" then row.done[#row.done + 1] = name
        elseif status == "active" or status == "ready" then row.inLog[#row.inLog + 1] = name
        elseif status == "available" then row.canTake[#row.canTake + 1] = name
        elseif status == "unavailable" and not notForYou(reasons) then
          row.needs[#row.needs + 1] = { name = name, why = reasons[1] }
        elseif status == "unknown" then row.unknown[#row.unknown + 1] = name end
      end
    end
    if #row.inLog + #row.canTake + #row.needs > 0 then
      row.share = #row.inLog > 0 and #row.canTake > 0
      local m = QE.meta[qid]
      row.deps = m and m.prereq or nil
      out[#out + 1] = row
    end
  end
  return out
end

-- The step a waypoint points at: the first quest to pick up that has a place, else the entrance.
function DA.NextPlace(plan)
  for _, s in ipairs(plan and plan.steps or {}) do
    if (s.kind == "pickup" or s.kind == "entrance") and s.loc then return s end
  end
  return nil
end
