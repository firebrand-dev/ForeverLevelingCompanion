-- Smart Loot Advisor (LA1, docs/LOOT_ADVISOR.md): the bosses' own items of the dungeons rated for this character
-- with the Class Quest Advisor's item scoring (Engine/Advisor.lua: weapon DPS and speed for melee, weighted stats,
-- the specialisation's weights for hybrids) or the player's own stat priorities, against what is equipped. Every
-- verdict is an estimate from stat weights, said so with its confidence; it is never a simulation, never a drop
-- chance, and it never decides need or greed. Items the class can use are all kept, hybrid ones included. Pure logic.
local _, ns = ...

local LA = {}
ns.LootAdvisor = LA

-- what each class can wear and wield (classic trainers; the same tables as tools/catalog/advisor.py)
LA.WEAPONS = {
  WARRIOR = { ["axe-1h"] = 1, ["axe-2h"] = 1, bow = 1, gun = 1, ["mace-1h"] = 1, ["mace-2h"] = 1, polearm = 1,
    ["sword-1h"] = 1, ["sword-2h"] = 1, staff = 1, fist = 1, dagger = 1, thrown = 1, crossbow = 1 },
  PALADIN = { ["axe-1h"] = 1, ["axe-2h"] = 1, ["mace-1h"] = 1, ["mace-2h"] = 1, polearm = 1, ["sword-1h"] = 1, ["sword-2h"] = 1 },
  HUNTER = { ["axe-1h"] = 1, ["axe-2h"] = 1, bow = 1, gun = 1, polearm = 1, ["sword-1h"] = 1, ["sword-2h"] = 1, staff = 1,
    fist = 1, dagger = 1, thrown = 1, crossbow = 1 },
  ROGUE = { bow = 1, gun = 1, ["mace-1h"] = 1, ["sword-1h"] = 1, fist = 1, dagger = 1, thrown = 1, crossbow = 1 },
  PRIEST = { ["mace-1h"] = 1, staff = 1, dagger = 1, wand = 1 },
  SHAMAN = { ["axe-1h"] = 1, ["axe-2h"] = 1, ["mace-1h"] = 1, ["mace-2h"] = 1, staff = 1, fist = 1, dagger = 1 },
  MAGE = { ["sword-1h"] = 1, staff = 1, dagger = 1, wand = 1 },
  WARLOCK = { ["sword-1h"] = 1, staff = 1, dagger = 1, wand = 1 },
  DRUID = { ["mace-1h"] = 1, ["mace-2h"] = 1, staff = 1, fist = 1, dagger = 1 },
}
LA.ARMOR = {   -- armour type -> from level
  WARRIOR = { cloth = 1, leather = 1, mail = 1, plate = 40, shield = 1 },
  PALADIN = { cloth = 1, leather = 1, mail = 1, plate = 40, shield = 1, libram = 1 },
  HUNTER = { cloth = 1, leather = 1, mail = 40 },
  ROGUE = { cloth = 1, leather = 1 },
  PRIEST = { cloth = 1 },
  SHAMAN = { cloth = 1, leather = 1, mail = 40, shield = 1, totem = 1 },
  MAGE = { cloth = 1 },
  WARLOCK = { cloth = 1 },
  DRUID = { cloth = 1, leather = 1, idol = 1 },
}
LA.LEVEL_AHEAD = 3     -- items up to this many levels above the character are listed ("in N levels")
LA.CLEAR_GAIN = 0.25   -- a gain this large on the estimate is "likely"; below it, "close"

function LA:Register(loader)
  if type(loader) == "function" then self.loader, self.data = loader, nil
  elseif type(loader) == "table" then self.loader, self.data = nil, loader end
  return true
end

-- The pack's loot, built on first use.
-- The boss's entry in the loot data ({ boss, dungeon, items }), by its encounter, or nil.
function LA:Boss(encounter) return self:Data().bosses and self:Data().bosses[encounter] end

function LA:Data()
  if not self.data and self.loader then
    local ok, d = pcall(self.loader)
    self.data = ok and type(d) == "table" and d or { items = {}, bosses = {} }
    self.loader = nil
  end
  return self.data or { items = {}, bosses = {} }
end

function LA.CanUse(rec, class, level)
  if rec.cl then
    local listed = false
    for _, c in ipairs(rec.cl) do if c == class then listed = true end end
    if not listed then return false end
  end
  if rec.w then return (LA.WEAPONS[class] or {})[rec.w] ~= nil end
  if rec.a then
    local from = (LA.ARMOR[class] or {})[rec.a]
    return from ~= nil and (level or 1) >= from
  end
  return true
end

-- The player's own stat priorities ({ stat = weight }), or nil for the class's.
function LA:CustomWeights()
  local char = ns.Session and ns.Session.char
  local w = char and char.lootWeights
  return type(w) == "table" and next(w) and w or nil
end

function LA:SetCustomWeights(w)
  local char = ns.Session and ns.Session.char
  if not char then return false end
  char.lootWeights = type(w) == "table" and next(w) and w or nil
  return true
end

-- "strength=1, stamina=0.5" -> { strength = 1, stamina = 0.5 }; nil when nothing readable.
function LA.ParseWeights(text)
  local w = {}
  for k, v in string.gmatch(text or "", "([%a%-]+)%s*=%s*([%d%.]+)") do w[string.lower(k)] = tonumber(v) end
  return next(w) and w or nil
end

local function scorerItem(rec)
  return { slot = rec.slot, dps = rec.dps, stats = rec.st, weapon = rec.w }
end

-- One item for a character: { id, rec, boss, dungeon, verdict = "better" | "superseded" | nil, gain (fraction over the
-- equipped one, estimate), confidence = "likely" | "close" | "unknown", soon = levels to wait (0 = now), custom }.
function LA:Rate(id, rec, where, state, gear, spec)
  local AD = ns.Advisor
  local custom = self:CustomWeights()
  local verdict, mine, reward
  verdict, reward, mine = AD.CompareItem(scorerItem(rec), gear, state.class, spec, custom)
  local gain = (verdict and mine and mine > 0 and reward) and (reward - mine) / mine or nil
  local conf = verdict == nil and "unknown"
    or (verdict == "better" and (mine == nil or (gain and gain >= LA.CLEAR_GAIN)) and "likely")   -- nil mine: an empty slot
    or "close"
  return { id = id, rec = rec, boss = where and where.boss, npc = where and where.npc, dungeon = where and where.dungeon,
    verdict = verdict, gain = gain,
    confidence = conf, soon = math.max(0, (rec.rl or 0) - (state.level or 1)), custom = custom ~= nil }
end

-- The upgrades of one dungeon (or of every dungeon when nil), or of one boss (its encounter), the class can use
-- within LEVEL_AHEAD levels: better ones first, by estimated gain.
function LA:Upgrades(state, gear, spec, dungeonID, limit, encounter)
  local data = self:Data()
  local out = {}
  for enc, b in pairs(data.bosses or {}) do
    if (not dungeonID or b.dungeon == dungeonID) and (not encounter or enc == encounter) then
      for _, id in ipairs(b.items or {}) do
        local rec = data.items[id]
        if rec and LA.CanUse(rec, state.class, (state.level or 1) + LA.LEVEL_AHEAD)
            and (rec.rl or 0) <= (state.level or 1) + LA.LEVEL_AHEAD then
          local r = self:Rate(id, rec, b, state, gear, spec)
          if r.verdict == "better" then out[#out + 1] = r end
        end
      end
    end
  end
  table.sort(out, function(a, b)
    if (a.soon == 0) ~= (b.soon == 0) then return a.soon == 0 end
    if (a.gain or 0) ~= (b.gain or 0) then return (a.gain or 0) > (b.gain or 0) end
    return a.id < b.id
  end)
  if limit then
    for i = #out, limit + 1, -1 do out[i] = nil end
  end
  return out
end
