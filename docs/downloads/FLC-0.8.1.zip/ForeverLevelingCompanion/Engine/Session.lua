-- Session: which route is active (personal guide, Help Player, Level Together, Catch-Up, Dungeon,
-- leader route) and the guarantees around it:
--   * the personal guide is snapshotted once when the first session starts and restored exactly;
--   * a session never writes to the personal track;
--   * other players' completions never mark the local character's quests;
--   * the session is stored in SavedVariables, so /reload, disconnects and group changes keep it.
local _, ns = ...
local U = ns.U
local QE = ns.Quest
local GE = ns.Guide
local RE = ns.Route

local S = { selfState = nil, ctx = { mode = "solo", partySize = 1 } }
ns.Session = S

S.KINDS = { help = true, together = true, catchup = true, dungeon = true, group = true, detour = true }
S.KIND_LABEL = { help = "Help Player", together = "Level together", catchup = "Group catch-up", dungeon = "Dungeon Focus", group = "Leader route",
  detour = "Class quest" }
S.HELP_WINDOW = 15     -- target guide steps looked at when building a Help Player route

function S:Init(char)
  self.char = char
  char.personal = char.personal or GE.NewTrack(nil)
  local p = char.personal
  p.cursors, p.reached, p.manual, p.skipped = p.cursors or {}, p.reached or {}, p.manual or {}, p.skipped or {}
  if char.session then
    -- Restored after /reload or relog: the route is kept, party data must be refreshed.
    char.session.restored = true
    if char.session.kind == "help" then char.session.status = "waiting-target" end
    ns.Diag:Info("session", "restored " .. tostring(char.session.kind) .. " session")
  end
end

function S:Personal() return self.char.personal end
function S:GetSession() return self.char.session end

function S:SetSelfState(state)
  self.selfState = state
  local p = self.char.personal
  local missing = p.guideID and not GE:Get(p.guideID) and p.guideID or nil
  if not p.guideID or not GE:Get(p.guideID) then
    local g = GE:SuggestGuide(state, ns.API.GetPlayerWorldPosition and ns.API.GetPlayerWorldPosition())
    if g and missing and p.missingGuide ~= missing then
      -- the saved guide is gone (catalog updated or disabled): say so once; its cursor stays for when it returns
      p.missingGuide = missing
      ns.Diag:Warn("session", "saved guide " .. tostring(missing) .. " is not available; picked " .. g.id)
      if ns.API.Print and ns.L then ns.API.Print(string.format(ns.L["Your guide %s is not available: another was chosen"], missing)) end
    end
    if g then
      p.guideID = g.id
      -- First run on an existing character: resume at the first unfinished step instead of step 1.
      if not p.cursors[g.id] then
        local i, step = GE:FindResumePoint(g, p, state, self.ctx)
        p.cursors[g.id] = { index = i, stepID = step and step.id }
      end
    end
  end
end

function S:UpdateContext(partySize)
  self.ctx.partySize = partySize or 1
  self.ctx.mode = (partySize or 1) > 1 and "group" or "solo"
end

----------------------------------------------------------------------
-- Active route resolution
----------------------------------------------------------------------
local function placeholderState(session)
  return QE.NewState({ key = session.target, name = session.targetName, source = "manual" })
end

function S:Subject(session)
  if not session or session.kind == "detour" then return self.selfState end
  if session.kind == "help" then
    local m = ns.Party:Get(session.target)
    return m and m.state or placeholderState(session)
  end
  local states = { [ns.selfKey or "self"] = self.selfState }
  for _, m in ipairs(ns.Party:List()) do states[m.key] = m.state end
  return QE.NewComposite(states, session.who or {})
end

-- Returns a description of what the UI should show right now.
function S:Active()
  local session = self.char.session
  if session and session.route then
    local guide = GE:Prepare(session.route)
    return { guide = guide, track = session.track, subject = self:Subject(session), session = session, kind = session.kind }
  end
  local p = self.char.personal
  local guide = p.guideID and GE:Get(p.guideID)
  return { guide = guide, track = p, subject = self.selfState, kind = "personal" }
end

function S:Current()
  local a = self:Active()
  if not a.guide or not a.subject then return a end
  a.index, a.step, a.status, a.info = GE:Current(a.guide, a.track, a.subject, self.ctx)
  return a
end

-- Information broadcast to the party: always the PERSONAL guide position.
function S:DescribeSelf()
  local d = {}
  local st = self.selfState
  if st then d.level, d.class = st.level, st.class end
  local p = self.char.personal
  local g = p.guideID and GE:Get(p.guideID)
  if g then
    local c = GE:Cursor(p, g)
    d.guideID, d.index, d.stepID, d.total = g.id, c.index, c.stepID, #g.steps
  end
  local session = self.char.session
  d.mode = session and session.kind or "solo"
  d.assisting = session and session.kind == "help" and session.target or nil
  if ns.API.GetUnitPosition then
    local map, x, y = ns.API.GetUnitPosition("player")
    d.map, d.x, d.y = map, x, y
  end
  return d
end

----------------------------------------------------------------------
-- Personal snapshot / restore
----------------------------------------------------------------------
local function snapshotPersonal(p)
  local saved = U.deepcopy(p)
  local g = p.guideID and GE:Get(p.guideID)
  if g then
    local c = GE:Cursor(p, g)
    saved.cursors[g.id] = U.copy(c)
  end
  saved.savedAt = ns.Now()
  return saved
end

-- Starts a session while keeping the ORIGINAL personal snapshot if one is already active,
-- so switching from helping Nico to helping Gustavo never saves the Nico route as "personal".
local function begin(self, session)
  local current = self.char.session
  if current and current.kind == "detour" and current ~= session and ns.Advisor then
    local d = ns.Advisor:Decisions()[current.advisor]
    if d and d.state == "now" then ns.Advisor:Decide(current.advisor, "later", self.selfState and self.selfState.level) end
  end
  session.saved = current and current.saved or snapshotPersonal(self.char.personal)
  session.startedAt = ns.Now()
  session.track = session.track or GE.NewTrack(session.route and session.route.id)
  session.status = session.status or "active"
  if current and current.kind == "help" and current.target ~= session.target then
    ns.Party:SendHelp("stop", current.target)
  end
  self.char.session = session
  ns.Bus:Fire("SESSION_CHANGED", "started", session)
  ns.Party:BroadcastState()
  return session
end

-- Ends any session and restores the personal guide exactly where it was saved.
function S:Stop(reason)
  local session = self.char.session
  if not session then return nil end
  local saved = session.saved
  local p = self.char.personal
  if type(saved) == "table" and saved.guideID then
    if type(p) ~= "table" or type(p.cursors) ~= "table" then
      -- Personal track damaged: rebuild it from the snapshot.
      p = U.deepcopy(saved)
      self.char.personal = p
      ns.Diag:Warn("session", "personal track rebuilt from snapshot")
    end
    p.guideID = saved.guideID
    p.cursors[saved.guideID] = U.copy(saved.cursors[saved.guideID])
  end
  if session.kind == "help" then ns.Party:SendHelp("stop", session.target) end
  self.char.session = nil
  ns.Bus:Fire("SESSION_CHANGED", "stopped", session, reason)
  ns.Party:BroadcastState()
  local c = p.guideID and p.cursors[p.guideID]
  return { guideID = p.guideID, index = c and c.index, stepID = c and c.stepID }
end

----------------------------------------------------------------------
-- Help Player
----------------------------------------------------------------------
local HELP_NOTE = {
  shared = "Kill together: your kills count for %s while grouped and nearby",
  assist = "Help clear: %s must loot or interact personally",
  ["target-only"] = "Only %s can do this: stay close and protect",
}

-- Quests worth helping with: target's log, upcoming quests of their guide, and manual picks.
-- Class Quest Advisor "Do it now": the chain's quests as a route of their own; the personal guide is saved and comes
-- back with End (or when the chain is done). Returns the session, or nil and why.
function S:StartDetour(entry)
  if not entry then return nil, "unknown chain" end
  local subject = self.selfState
  if not subject then return nil, "no character data yet" end
  local current = self.char.session
  if current and current.kind ~= "detour" then
    return nil, "end the current Party Mode session first"     -- never replaced without asking
  end
  local route = ns.Advisor:BuildRoute(entry, subject, GE:LoadedGuides())
  if not route then return nil, "nothing left to do in this chain" end
  return begin(self, { kind = "detour", route = route, advisor = entry.id, title = entry.title,
    track = GE.NewTrack(route.id) })
end

function S:HelpCandidates(m)
  local set, order = {}, {}
  local function add(q)
    if not set[q] then set[q] = true; order[#order + 1] = q end
  end
  for _, qid in ipairs(U.keys(m.state.log)) do add(qid) end
  for qid, on in pairs(m.state.onQuest) do if on then add(qid) end end
  local g = m.guide and m.guide.guideID and GE:Get(m.guide.guideID)
  if g then
    local start = (m.guide.stepID and g.index[m.guide.stepID]) or m.guide.index or 1
    for i = start, math.min(#g.steps, start + self.HELP_WINDOW - 1) do
      local s = g.steps[i]
      if s.quest then add(s.quest) end
    end
  end
  return order
end

function S:BuildHelpRoute(targetKey)
  local m = ns.Party:Get(targetKey)
  if not m then return nil, "unknown-member" end
  local me, target = self.selfState, m.state
  local guides = {}
  local tg = m.guide and m.guide.guideID and GE:Get(m.guide.guideID)
  if tg then guides[#guides + 1] = tg end
  local mine = self.char.personal.guideID and GE:Get(self.char.personal.guideID)
  if mine and mine ~= tg then guides[#guides + 1] = mine end

  local tasks, quests, summary = {}, {}, { shared = 0, assist = 0, targetOnly = 0, alsoMine = 0, unknown = 0 }
  local who = m.name or U.shortName(targetKey)
  local blockedByExclusive = {}
  for _, qid in ipairs(self:HelpCandidates(m)) do
    local cls = QE:ClassifyForHelp(me, target, qid)
    local meta = QE:Meta(qid)
    local include = cls.flags.pendingTarget or (cls.target == "unknown" and target:IsOnQuest(qid) == true)
    -- Upcoming quests (not yet accepted) only when we can actually contribute to them.
    if include and cls.target == "available" and not cls.flags.helpful then include = false end
    -- Exclusive alternatives: keep the first one in the target's guide order only.
    if include and blockedByExclusive[qid] then include = false end
    if include and meta and meta.exclusive then
      for _, x in ipairs(meta.exclusive) do blockedByExclusive[x] = true end
    end
    if include then
      quests[#quests + 1] = qid
      local base = "q" .. qid
      local myRole = cls.flags.pendingMe and "progress" or (cls.me == "completed" and "help-completed" or "help")
      if cls.flags.pendingMe then summary.alsoMine = summary.alsoMine + 1 end
      local after
      if cls.target == "available" then
        local note = cls.flags.shareable and cls.me == "active" and "Share this quest with %s" or "%s must accept this quest"
        tasks[#tasks + 1] = { id = base .. ":accept", type = "accept", quest = qid, loc = RE.LocFor(qid, "accept", guides),
          help = { mode = "target-only", me = myRole }, note = note }
        after = { base .. ":accept" }
      end
      local openObjectives = 0
      for _, o in ipairs(cls.objectives) do
        if not o.done then
          openObjectives = openObjectives + 1
          local key = o.help == "target-only" and "targetOnly" or o.help
          summary[key] = (summary[key] or 0) + 1
          tasks[#tasks + 1] = { id = base .. ":obj" .. o.index, type = "complete", quest = qid, objective = o.index,
            loc = RE.LocFor(qid, "complete", guides), after = after, label = o.label,
            help = { mode = o.help, me = myRole, estimated = o.estimated }, note = HELP_NOTE[o.help] }
        end
      end
      local objAfter = after
      if openObjectives > 0 then
        objAfter = {}
        for _, t in ipairs(tasks) do
          if t.quest == qid and t.objective then objAfter[#objAfter + 1] = t.id end
        end
      elseif #cls.objectives == 0 and not (meta and meta.objectives) and not target:IsReady(qid) then
        -- No objective data (member without addon): one step whose progress stays unknown.
        summary.unknown = summary.unknown + 1
        tasks[#tasks + 1] = { id = base .. ":work", type = "complete", quest = qid, loc = RE.LocFor(qid, "complete", guides),
          after = after, help = { mode = "unknown", me = myRole }, note = "Progress of %s is unknown: ask them" }
        objAfter = { base .. ":work" }
      end
      tasks[#tasks + 1] = { id = base .. ":turnin", type = "turnin", quest = qid, loc = RE.LocFor(qid, "turnin", guides),
        after = objAfter, help = { mode = "target-only", me = myRole }, note = "%s turns in the quest" }
    end
  end

  local start = m.pos
  if not start and ns.API.GetUnitPosition then
    local map, x, y = ns.API.GetUnitPosition("player")
    if map and x then start = { map = map, x = x, y = y } end
  end
  local ordered = RE.Order(tasks, start)
  local route = RE.ToGuide(ordered, { id = "assist:" .. targetKey, title = who, kind = "help" })
  route.target, route.targetName, route.quests = targetKey, who, quests
  route.summary = summary
  route.knowledge = ns.Party:Knowledge(m)
  route.builtAt = ns.Now()
  return route
end

function S:StartHelp(targetKey)
  local m = ns.Party:Get(targetKey)
  if not m then return nil, "unknown-member" end
  local route, err = self:BuildHelpRoute(targetKey)
  if not route then return nil, err end
  local session = begin(self, {
    kind = "help", target = targetKey, targetName = m.name, route = route,
    track = GE.NewTrack(route.id), status = m.connected and "active" or "target-offline",
  })
  ns.Party:SendHelp("start", targetKey)
  if m.hasAddon and m.share then
    ns.Party:RequestRefresh()
    local unknown = {}
    for _, qid in ipairs(self:HelpCandidates(m)) do
      if m.state:IsCompleted(qid) == nil then unknown[#unknown + 1] = qid end
    end
    if #unknown > 0 then
      session.awaiting = true
      ns.Party:QueryCompletion(unknown)
    end
  end
  return session
end

-- Rebuilds the route for the same target, keeping the saved personal snapshot.
function S:Recalculate()
  local session = self.char.session
  if not session then return nil end
  if session.kind == "help" then
    local route = self:BuildHelpRoute(session.target)
    if not route then return nil end
    session.route, session.track = route, GE.NewTrack(route.id)
  elseif session.kind == "detour" then
    -- a class quest chain is rebuilt from the chain (what is left of it), never from the party
    local e = ns.Advisor and ns.Advisor.byId[session.advisor]
    local route = e and ns.Advisor:BuildRoute(e, self.selfState, GE:LoadedGuides())
    if not route then return nil end
    session.route, session.track = route, GE.NewTrack(route.id)
  else
    -- A route still waiting for knowledge keeps its candidate list open; explicit quest lists stay.
    local quests = (session.proposer and session.proposer ~= ns.selfKey) and session.quests or nil
    local route = self:BuildGroupRoute(session.kind, session.preset, quests)
    session.route, session.track, session.who = route, GE.NewTrack(route.id), route.who
  end
  if session.status ~= "target-offline" and session.status ~= "target-left" then session.status = "active" end
  session.changed, session.awaiting = nil, nil
  ns.Bus:Fire("SESSION_CHANGED", "recalculated", session)
  return session
end

-- True when every route step is done by the target's own data, or every route quest is turned in.
-- Unknown progress is never "done", so members without data never finish automatically.
function S:HelpFinished(session)
  if not session or session.kind ~= "help" or not session.route then return false end
  local m = ns.Party:Get(session.target)
  if not m then return false end
  local quests = session.route.quests or {}
  if #quests == 0 then return true end
  local allTurnedIn = true
  for _, qid in ipairs(quests) do
    if m.state:IsCompleted(qid) ~= true then allTurnedIn = false end
  end
  if allTurnedIn then return true end
  local guide = GE:Prepare(session.route)
  for _, step in ipairs(guide.steps) do
    local st = GE:StepStatus(step, session.track, m.state, self.ctx)
    if st ~= "done" and st ~= "na" then return false end
  end
  return true
end

----------------------------------------------------------------------
-- Group modes (Level Together / Catch-Up / Dungeon / leader route)
----------------------------------------------------------------------
function S:GroupMembers()
  local list = {}
  if self.selfState then
    list[#list + 1] = { key = ns.selfKey or "self", name = self.selfState.name, level = self.selfState.level, state = self.selfState, class = self.selfState.class }
  end
  local mine = self.char.personal.guideID and GE:Get(self.char.personal.guideID)
  local myIndex = mine and GE:Cursor(self.char.personal, mine).index or 0
  for _, m in ipairs(ns.Party:List()) do
    local behind = 0
    if m.guide and mine and m.guide.guideID == mine.id then behind = math.max(0, myIndex - (m.guide.index or myIndex)) end
    local window = {}
    local g = m.guide and m.guide.guideID and GE:Get(m.guide.guideID)
    if g then
      local start = (m.guide.stepID and g.index[m.guide.stepID]) or m.guide.index or 1
      for i = start, math.min(#g.steps, start + 30) do if g.steps[i].quest then window[#window + 1] = g.steps[i].quest end end
    end
    list[#list + 1] = { key = m.key, name = m.name, level = m.level, class = m.class, state = m.state, stepsBehind = behind, window = window }
  end
  if mine then
    local c = GE:Cursor(self.char.personal, mine)
    local window = {}
    for i = c.index, math.min(#mine.steps, c.index + 30) do if mine.steps[i].quest then window[#window + 1] = mine.steps[i].quest end end
    list[1].window = window
  end
  return list
end

function S:BuildGroupRoute(kind, preset, quests)
  local members = self:GroupMembers()
  -- generated routes not built yet add nothing: the catalog's quest metadata has the same locations
  local guides = GE:LoadedGuides()
  local start
  if ns.API.GetUnitPosition then
    local map, x, y = ns.API.GetUnitPosition("player")
    if map and x then start = { map = map, x = x, y = y } end
  end
  local route = RE.PlanGroup({
    members = members, preset = kind == "dungeon" and "dungeon" or (preset or "balanced"),
    mode = kind == "catchup" and "catchup" or "together", candidates = quests,
    start = start, guides = guides, max = quests and #quests or 8,
  })
  -- Beneficiaries per quest drive the composite subject.
  local who = {}
  for _, e in ipairs(route.plan.quests) do who[e.questID] = U.copy(e.beneficiaries) end
  route.who = who
  route.quests = {}
  for _, e in ipairs(route.plan.quests) do route.quests[#route.quests + 1] = e.questID end
  return route
end

function S:StartGroup(kind, preset, quests, proposer)
  if not S.KINDS[kind] then return nil, "bad-kind" end
  local route = self:BuildGroupRoute(kind, preset, quests)
  local session = begin(self, {
    kind = kind, preset = preset, route = route, who = route.who, quests = route.quests,
    track = GE.NewTrack(route.id), proposer = proposer,
  })
  -- Members whose completion we do not know yet are asked; the route is rebuilt on their answer.
  local unknown, seen = {}, {}
  for _, e in ipairs(route.plan.evaluated) do
    if #e.unknown > 0 and not seen[e.questID] then
      seen[e.questID] = true
      unknown[#unknown + 1] = e.questID
    end
  end
  if #unknown > 0 then
    session.awaiting = true
    ns.Party:QueryCompletion(unknown)
  end
  return session
end

-- Leader: start locally and ask the others. Members are never switched without their answer.
function S:ProposeGroupRoute(kind, preset)
  local session = self:StartGroup(kind, preset)
  if not session then return nil end
  local id = (ns.selfKey or "self") .. ":" .. tostring(math.floor(ns.Now()))
  session.proposalID = id
  session.proposer = ns.selfKey
  ns.Party:ProposeRoute(id, kind, preset or "balanced", session.quests)
  return session
end

function S:AcceptProposal(id)
  local p = ns.Party.proposals[id]
  if not p or p.status ~= "pending" then return nil, "not-pending" end
  ns.Party:AnswerProposal(id, true)
  local session = self:StartGroup("group", p.preset, p.quests, p.from)
  if session then session.proposalID = id end
  return session
end

function S:DeclineProposal(id)
  return ns.Party:AnswerProposal(id, false)
end

----------------------------------------------------------------------
-- Reactions to party changes
----------------------------------------------------------------------
local function notify(kind, ...)
  ns.Bus:Fire("SESSION_NOTICE", kind, ...)
end

local function isTarget(m)
  local s = S.char and S.char.session
  return s and s.kind == "help" and s.target == m.key
end

-- An abandoned quest: the personal guide goes back to its giver (GE:Reopen), the arrow with it.
ns.Bus:On("TRACKER_QUEST_ABANDONED", S, function(qid)
  local p = S.char and S.char.personal
  local g = p and p.guideID and GE:Get(p.guideID)
  if g and S.selfState and GE:Reopen(g, p, qid, S.selfState, S.ctx) and ns.UI then ns.UI.dirty = true end
end)

ns.Bus:On("PARTY_MEMBER_OFFLINE", S, function(m)
  if isTarget(m) then
    S.char.session.status = "target-offline"
    notify("target-offline", m.name)
  end
end)

ns.Bus:On("PARTY_MEMBER_ONLINE", S, function(m)
  if isTarget(m) then
    S.char.session.status = "active"
    S.char.session.changed = true
    notify("target-online", m.name)
  end
end)

ns.Bus:On("PARTY_MEMBER_LEFT", S, function(m)
  if isTarget(m) then
    S.char.session.status = "target-left"
    notify("target-left", m.name)
  end
end)

ns.Bus:On("PARTY_MEMBER_JOINED", S, function(m)
  if isTarget(m) and S.char.session.status ~= "waiting-target" then
    S.char.session.status = "active"
    S.char.session.changed = true
    notify("target-back", m.name)
  end
end)

ns.Bus:On("PARTY_MEMBER_DATA", S, function(m, what)
  local s = S.char and S.char.session
  if not s then return end
  -- First completion answers after starting: rebuild once, before the user has moved on.
  if what == "completion" and s.awaiting then
    local relevant = s.kind ~= "help" or s.target == m.key
    local untouched = true
    for _, c in pairs(s.track.cursors) do if (c.index or 1) > 1 then untouched = false end end
    if relevant and untouched then S:Recalculate() end
    s = S.char.session
  end
  if isTarget(m) then
    if s.status == "waiting-target" then s.status = "active" end
    if what == "log" and s.route then
      -- New quest in the target's log that is not part of the route: offer a recalculation.
      local inRoute = U.set(s.route.quests)
      for qid in pairs(m.state.log) do
        if not inRoute[qid] then s.changed = true end
      end
    end
    if what == "hello" and not m.share then
      notify("target-declined", m.name)
    end
    if S:HelpFinished(s) and s.status ~= "finished" then
      s.status = "finished"
      notify("help-finished", m.name)
    end
  end
end)

ns.Bus:On("PARTY_TURNIN", S, function(m)
  local s = S.char and S.char.session
  if isTarget(m) and S:HelpFinished(s) and s.status ~= "finished" then
    s.status = "finished"
    notify("help-finished", m.name)
  end
end)

ns.Bus:On("PARTY_LEADER_CHANGED", S, function(newLeader)
  local s = S.char and S.char.session
  if s and s.kind == "group" and s.proposer and s.proposer ~= newLeader then
    s.leaderChanged = true
    notify("leader-changed", newLeader)
  end
end)

-- A detour ends by itself when the chain's last quest is turned in: the personal guide comes back where it was.
-- Ended early (End, or another session), a "now" decision becomes "later": the chain is offered again later.
ns.Bus:On("TRACKER_QUEST_TURNED_IN", S, function(qid)
  local session = S.char and S.char.session
  local e = session and session.kind == "detour" and ns.Advisor and ns.Advisor.byId[session.advisor]
  if e and e.quest == qid then
    S:Stop("chain-done")
    if ns.API.Print and ns.L then ns.API.Print(string.format(ns.L["Class quest done: %s - back to your guide"], e.title or "?")) end
  end
end)
ns.Bus:On("SESSION_CHANGED", S, function(what, session, reason)
  if what ~= "stopped" or not session or session.kind ~= "detour" or reason == "chain-done" then return end
  local d = ns.Advisor and ns.Advisor:Decisions()[session.advisor]
  if d and d.state == "now" then
    ns.Advisor:Decide(session.advisor, "later", S.selfState and S.selfState.level)
  end
end)
