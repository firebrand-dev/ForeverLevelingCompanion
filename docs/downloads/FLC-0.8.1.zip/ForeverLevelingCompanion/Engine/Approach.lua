-- Approach hints (docs/APPROACH_HINTS.md): the last stretch to a step when the way there is not a straight line.
-- A catalog step may carry
--   approach = { hint = "<key>", args = { floor = "upper"|"lower", who = "npc" }, from = { wx, wy, z },
--                via = { { wx, wy, z }, ... } }
-- precomputed offline (tools/catalog/approach.py) from the client's terrain; nothing here asks the
-- game. The arrow follows the via points in order, in 2D (the client gives addons no player height, so `z` is only
-- information); the hint is one short line ("Go up the stairs inside the tower - the NPC is on the upper floor").
-- Pure logic: the UI hands in the player's world position { cont, wx, wy } and the step.
local _, ns = ...
local L = ns.L

local A = {
  arrive = 6,           -- yards (2D): a via point counts as reached this close
  corridor = 40,        -- the player follows the approach when this close to what is left of its path ...
  leave = 60,           -- ... and stops following it beyond this (back to the straight arrow)
  unreachableNear = 30, -- "not reachable on foot" is not said this close to the goal (the player may be there already)
}
ns.Approach = A

-- Hint keys (the same vocabulary as tools/catalog/approach.py); the English text is the translation key.
A.HINTS = {
  ["climb-tower"] = "Go up the stairs inside the tower",
  ["descend-tower"] = "Go down the stairs inside the tower",
  climb = "Go up the stairs or ramp",
  descend = "Go down the stairs or ramp",
  bridge = "Cross the bridge",
  ["round-tower"] = "Go round the tower",
  round = "Go round the obstacle",
  follow = "Follow the path: the straight way is blocked",
  ["follow-entrance"] = "Follow the path to the entrance",
  unreachable = "Not reachable on foot from here: look for a flight point, portal or other way",
  ["swim-down"] = "It is under water: swim down to it",
}
-- Hints about the way the player comes from: said only while the player is on that way.
A.PATH_HINTS = { bridge = true, ["round-tower"] = true, round = true, follow = true, ["follow-entrance"] = true }
A.FLOOR = {
  upper = { npc = "The NPC is on the upper floor", any = "The target is on the upper floor" },
  lower = { npc = "The NPC is on the lower level", any = "The target is on the lower level" },
}
A.FLOOR_TAIL = {
  upper = { npc = "the NPC is on the upper floor", any = "the target is on the upper floor" },
  lower = { npc = "the NPC is on the lower level", any = "the target is on the lower level" },
}

local function valid(ap)
  return type(ap) == "table" and (type(ap.hint) == "string" or type(ap.args) == "table")
end

-- The hint line, translated; onPath = the player is following the approach's way. nil when there is nothing to say.
function A.Text(ap, onPath)
  if not valid(ap) then return nil end
  local key = A.HINTS[ap.hint or ""]
  if key and A.PATH_HINTS[ap.hint] and not onPath then key = nil end
  local args = type(ap.args) == "table" and ap.args or nil
  local floor = args and A.FLOOR[args.floor or ""] and args.floor or nil
  local who = args and args.who == "npc" and "npc" or "any"
  if key and floor then return L[key] .. " - " .. L[A.FLOOR_TAIL[floor][who]] end
  if key then return L[key] end
  if floor then return L[A.FLOOR[floor][who]] end
  return nil
end

-- The approach's way as world points: from, via..., then the step's own loc (the arrow's usual target).
local paths = setmetatable({}, { __mode = "k" })

local function pathOf(ap, loc)
  local p = paths[ap]
  if p and p.loc == loc then return p end
  p = { loc = loc }
  local function add(v)
    if type(v) == "table" and type(v.wx) == "number" and type(v.wy) == "number" then
      p[#p + 1] = { cont = loc.cont, wx = v.wx, wy = v.wy, z = v.z }
    end
  end
  if type(ap.via) == "table" and #ap.via > 0 then
    add(ap.from)
    if #p == 0 then p[1] = false end -- no start: the first via point still counts from wherever the player is
    for _, v in ipairs(ap.via) do add(v) end
    p[#p + 1] = loc
  end
  paths[ap] = p
  return p
end

local function d2(a, b)
  local dn, dw = b.wx - a.wx, b.wy - a.wy
  return math.sqrt(dn * dn + dw * dw)
end

-- 2D distance from p to the segment a-b (world yards).
local function segDist(p, a, b)
  local dx, dy = b.wx - a.wx, b.wy - a.wy
  local den = dx * dx + dy * dy
  local t = 0
  if den > 0 then
    t = ((p.wx - a.wx) * dx + (p.wy - a.wy) * dy) / den
    if t < 0 then t = 0 elseif t > 1 then t = 1 end
  end
  local x, y = a.wx + t * dx - p.wx, a.wy + t * dy - p.wy
  return math.sqrt(x * x + y * y)
end

-- pos: the player's world position; step: the current step. Returns nil without an approach (or on another
-- continent), else a table (reused between calls; read it, do not keep it):
--   text     the hint line or nil;
--   point    the via point the arrow points at, or nil (then the arrow points at the step as before);
--   index, total   which via point (1-based) of how many;
--   remaining      yards left along the way (to the via point, then via point to via point, then to the step).
function A:Guidance(pos, step)
  local ap = step and step.approach
  local loc = step and step.loc
  if not valid(ap) or not loc or loc.cont == nil or not pos or pos.cont ~= loc.cont then return nil end
  local st = self.state
  if not st or st.ap ~= ap or st.loc ~= loc then
    st = { ap = ap, loc = loc, cursor = 2, engaged = false, out = {} }
    self.state = st
  end
  local out = st.out
  local path = pathOf(ap, loc)
  local n = #path
  out.point, out.index, out.total, out.remaining = nil, nil, nil, nil
  if n >= 3 and st.cursor < n then
    -- where the player is along the way: the nearest stretch of what is left (earlier stretches are never revisited)
    local best, bestK = math.huge, nil
    local first = st.cursor - 1
    local from = path[first] or pos
    for k = first, n - 1 do
      local a = (k == first) and from or path[k]
      local dist = segDist(pos, a, path[k + 1])
      if dist < best - 3 then best, bestK = dist, k end
    end
    local limit = st.engaged and self.leave or self.corridor
    if best > limit then
      st.engaged = false
    else
      st.engaged = true
      if bestK + 1 > st.cursor then st.cursor = bestK + 1 end
      while st.cursor < n and d2(pos, path[st.cursor]) <= self.arrive do st.cursor = st.cursor + 1 end
      if d2(pos, loc) <= self.arrive * 2 then st.cursor = n end -- next to the step already
      if st.cursor < n then
        local target = path[st.cursor]
        local rest = d2(pos, target)
        for k = st.cursor, n - 1 do rest = rest + d2(path[k], path[k + 1]) end
        out.point, out.index, out.total, out.remaining = target, st.cursor - 1, n - 2, rest
      end
    end
  end
  local onPath = st.engaged or (n < 3)
  -- the text only changes with the way being followed or the language (no new strings 20 times a second)
  if st.textOnPath ~= onPath or st.textLocale ~= ns.locale or st.text == nil then
    st.textOnPath, st.textLocale = onPath, ns.locale
    st.text = A.Text(ap, onPath) or false
    -- computed from the game's terrain, never walked: shown "in review"
    if st.text then st.text = string.format(L["%s (in review)"], st.text) end
  end
  local text = st.text or nil
  if text and ap.hint == "unreachable" and d2(pos, loc) <= self.unreachableNear then text = nil end
  out.text = text
  out.engaged = st.engaged
  return out
end

function A:Reset()
  self.state = nil
end
