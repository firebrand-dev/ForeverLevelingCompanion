-- Client adapter. The ONLY file in the engine layer that touches WoW globals.
-- Every function is resolved at call time and probed, never assumed: WoW Forever (1.60.x) runs on
-- the Mainline code family (C_QuestLog, C_Map, C_ChatInfo) with Midnight-era "secret values",
-- while Classic Era (1.15.x) exposes the legacy globals. Both shapes are supported.
local _, ns = ...
local U = ns.U

local API = { caps = {} }
ns.API = API

-- Environment indirection so tests can swap the global table.
ns.env = ns.env or _G
local function G(name) return ns.env[name] end
local function NS(tbl, fn)
  local t = ns.env[tbl]
  return t and t[fn]
end

-- Values the client marks secret can be displayed but not compared or used in arithmetic.
function API.IsSecret(v)
  local f = G("issecretvalue")
  if f then
    local ok, r = pcall(f, v)
    return ok and r == true
  end
  return false
end

local function plain(v)
  if v == nil or API.IsSecret(v) then return nil end
  return v
end

function API.Probe()
  local c = {}
  c.questLogModern = NS("C_QuestLog", "GetInfo") ~= nil and NS("C_QuestLog", "GetNumQuestLogEntries") ~= nil
  c.questLogLegacy = G("GetQuestLogTitle") ~= nil
  c.questObjectives = NS("C_QuestLog", "GetQuestObjectives") ~= nil
  c.leaderBoard = G("GetQuestLogLeaderBoard") ~= nil
  c.completedFlag = NS("C_QuestLog", "IsQuestFlaggedCompleted") ~= nil or G("IsQuestFlaggedCompleted") ~= nil
  c.completedList = NS("C_QuestLog", "GetAllCompletedQuestIDs") ~= nil or G("GetQuestsCompleted") ~= nil
  c.unitOnQuest = NS("C_QuestLog", "IsUnitOnQuest") ~= nil
  c.pushable = NS("C_QuestLog", "IsPushableQuest") ~= nil or G("GetQuestLogPushable") ~= nil
  c.mapPosition = NS("C_Map", "GetBestMapForUnit") ~= nil and NS("C_Map", "GetPlayerMapPosition") ~= nil
  c.worldPos = NS("C_Map", "GetWorldPosFromMapPos") ~= nil and G("CreateVector2D") ~= nil
  c.mapSize = NS("C_Map", "GetMapWorldSize") ~= nil
  c.facing = G("GetPlayerFacing") ~= nil
  c.unitPosition = G("UnitPosition") ~= nil
  c.worldToMap = NS("C_Map", "GetMapPosFromWorldPos") ~= nil and G("CreateVector2D") ~= nil
  c.questie = G("Questie") ~= nil or G("QuestieLoader") ~= nil
  c.addonMessage = NS("C_ChatInfo", "SendAddonMessage") ~= nil
  c.chatModern = NS("C_ChatInfo", "SendChatMessage") ~= nil
  c.chatLegacy = G("SendChatMessage") ~= nil
  c.chatLockdown = NS("C_ChatInfo", "InChatMessagingLockdown") ~= nil
  c.secretValues = G("issecretvalue") ~= nil
  c.userWaypoint = NS("C_Map", "SetUserWaypoint") ~= nil and NS("UiMapPoint", "CreateFromCoordinates") ~= nil
  c.tomtom = G("TomTom") ~= nil and type(G("TomTom").AddWaypoint) == "function"
  c.encodingUtil = G("C_EncodingUtil") ~= nil
  -- travel planner (Engine/Travel.lua): flights need one of the two taxi shapes, the Hearthstone its cooldown
  c.taxiMap = NS("C_TaxiMap", "GetAllTaxiNodes") ~= nil and G("GetTaxiMapID") ~= nil
  c.taxiLegacy = G("NumTaxiNodes") ~= nil and G("TaxiNodeName") ~= nil and G("TaxiNodeGetType") ~= nil
  c.bindLocation = G("GetBindLocation") ~= nil
  c.itemCooldown = NS("C_Container", "GetItemCooldown") ~= nil or G("GetItemCooldown") ~= nil
  c.onTaxi = G("UnitOnTaxi") ~= nil
  c.trialAccount = (G("IsTrialAccount") and G("IsTrialAccount")()) and true or false
  API.caps = c
  return c
end

----------------------------------------------------------------------
-- Client / player info
----------------------------------------------------------------------
function API.GetClientInfo()
  local info = {}
  local gbi = G("GetBuildInfo")
  if gbi then
    local v, b, _, iface = gbi()
    info.version, info.build, info.interface = v, b, iface
  end
  info.project = G("WOW_PROJECT_ID")
  info.locale = G("GetLocale") and G("GetLocale")() or "enUS"
  return info
end

-- The development-only test addon (tests/ingame/FLC_TestRunner), when it is installed and enabled.
function API.TestRunner()
  local r = G("FLC_TESTRUNNER")
  if type(r) == "table" and type(r.Attach) == "function" then return r end
  return nil
end

function API.GetLocale()
  return G("GetLocale") and G("GetLocale")() or "enUS"
end

function API.Time()
  local f = G("GetTime")
  return f and f() or 0
end

-- Wall-clock seconds (survive relogs, unlike GetTime); nil when the client does not offer them.
function API.WallTime()
  local f = G("time")
  return f and f() or nil
end

function API.ProfileTimer()
  local f = G("debugprofilestop")
  return f and f() or 0
end

function API.InCombat()
  local f = G("InCombatLockdown")
  return f and f() or false
end

-- Windows a welcome window must not open over (the game menu, a confirmation, the game's own settings).
API.BUSY_FRAMES = { "GameMenuFrame", "StaticPopup1", "SettingsPanel", "InterfaceOptionsFrame", "VideoOptionsFrame",
  "CinematicFrame", "MovieFrame", "CharacterCreateFrame" }

-- Why this is not a good moment to open a window by itself, or nil: in combat, in a cinematic, or a window above.
function API.ScreenBusy()
  if API.InCombat() then return "combat" end
  local inCombat = G("UnitAffectingCombat")
  if inCombat and plain(inCombat("player")) then return "combat" end
  local cine = G("InCinematic")
  if cine and plain(cine()) then return "cinematic" end
  for _, name in ipairs(API.BUSY_FRAMES) do
    local f = G(name)
    if type(f) == "table" and type(f.IsShown) == "function" then
      local ok, shown = pcall(f.IsShown, f)
      if ok and shown then return name end
    end
  end
  return nil
end

local function unitFullName(unit)
  local f = G("UnitFullName")
  local name, realm
  if f then
    name, realm = f(unit)
  elseif G("UnitName") then
    name, realm = G("UnitName")(unit)
  end
  name, realm = plain(name), plain(realm)
  if not name then return nil end
  if not realm or realm == "" then
    local gr = G("GetNormalizedRealmName")
    realm = gr and plain(gr()) or nil
  end
  if realm and realm ~= "" then return name .. "-" .. realm end
  return name
end
API.UnitKey = unitFullName

-- The sender of an addon message as a roster key ("Name-Realm"). WoW Forever sends "Name Surname" instead: the
-- character's surname, or nothing (a trailing space) for a character without one. Its UnitFullName gives that surname
-- as the realm, so "Name Surname" becomes "Name-Surname"; a bare name gets our realm, as same-realm members are keyed.
function API.SenderKey(sender)
  sender = plain(sender)
  if type(sender) ~= "string" then return nil end
  sender = sender:gsub("^%s+", ""):gsub("%s+$", "")
  if sender == "" then return nil end
  local name, surname = sender:match("^([^%s%-]+)%s+(.+)$")
  if name then return name .. "-" .. surname end
  if not sender:find("-", 1, true) then
    local gr = G("GetNormalizedRealmName")
    local realm = gr and plain(gr()) or nil
    if realm and realm ~= "" then sender = sender .. "-" .. realm end
  end
  return sender
end

function API.GetPlayerInfo()
  local p = { unit = "player" }
  p.key = unitFullName("player")
  p.name = U.shortName(p.key)
  p.level = G("UnitLevel") and plain(G("UnitLevel")("player")) or 1
  if G("UnitClass") then
    local _, classFile = G("UnitClass")("player")
    p.class = plain(classFile)
  end
  if G("UnitRace") then
    local _, raceFile, raceID = G("UnitRace")("player")
    p.race = plain(raceFile)
    p.raceID = plain(raceID)
  end
  if G("UnitFactionGroup") then p.faction = plain(G("UnitFactionGroup")("player")) end
  return p
end

----------------------------------------------------------------------
-- Quest log
----------------------------------------------------------------------
-- Legacy leaderboard text looks like "Kobold Vermin slain: 4/10".
function API.ParseObjectiveText(text)
  if type(text) ~= "string" then return nil end
  local label, have, need = string.match(text, "^(.-):%s*(%d+)%s*/%s*(%d+)%s*$")
  if not label then
    have, need, label = string.match(text, "^(%d+)%s*/%s*(%d+)%s+(.+)$")
  end
  if have then return label, tonumber(have), tonumber(need) end
  return text, nil, nil
end

local function normalizeObjective(o)
  local label, have, need = API.ParseObjectiveText(o.text)
  return {
    text = label or o.text or "",
    type = o.type or "unknown",
    have = o.numFulfilled or have or (o.finished and 1 or 0),
    need = o.numRequired or need or 1,
    done = o.finished and true or false,
  }
end

-- Returns { [questID] = { questID, title, level, complete, failed, objectives = {...} } }.
-- `complete` means "ready to turn in" and comes from the client, not from our arithmetic.
function API.GetQuestLog()
  local log = {}
  local CQ = G("C_QuestLog")
  if CQ and CQ.GetNumQuestLogEntries and CQ.GetInfo then
    local n = CQ.GetNumQuestLogEntries() or 0
    for i = 1, n do
      local info = CQ.GetInfo(i)
      if info and not info.isHeader and info.questID and info.questID > 0 then
        local q = { questID = info.questID, title = info.title, level = info.level, objectives = {} }
        local state = CQ.IsComplete and CQ.IsComplete(info.questID)
        if state == nil then state = info.isComplete == 1 or info.isComplete == true end
        q.complete = state and true or false
        q.failed = CQ.IsFailed and CQ.IsFailed(info.questID) or false
        local objs = CQ.GetQuestObjectives and CQ.GetQuestObjectives(info.questID) or {}
        for idx, o in ipairs(objs) do q.objectives[idx] = normalizeObjective(o) end
        log[q.questID] = q
      end
    end
    return log
  end
  local getTitle = G("GetQuestLogTitle")
  if getTitle then
    local n = G("GetNumQuestLogEntries") and G("GetNumQuestLogEntries")() or 0
    for i = 1, n do
      local title, level, _, isHeader, _, isComplete, _, questID = getTitle(i)
      if not isHeader and questID and questID > 0 then
        local q = { questID = questID, title = title, level = level, objectives = {} }
        q.complete = isComplete == 1 or isComplete == true
        q.failed = isComplete == -1
        local nObj = G("GetNumQuestLeaderBoards") and G("GetNumQuestLeaderBoards")(i) or 0
        for idx = 1, nObj do
          local text, otype, finished = G("GetQuestLogLeaderBoard")(idx, i)
          q.objectives[idx] = normalizeObjective({ text = text, type = otype, finished = finished })
        end
        log[questID] = q
      end
    end
  end
  return log
end

function API.IsQuestCompleted(questID)
  local f = NS("C_QuestLog", "IsQuestFlaggedCompleted") or G("IsQuestFlaggedCompleted")
  if not f then return nil end
  return f(questID) and true or false
end

function API.GetCompletedQuests()
  local set = {}
  local all = NS("C_QuestLog", "GetAllCompletedQuestIDs")
  if all then
    for _, id in ipairs(all() or {}) do set[id] = true end
    return set, true
  end
  local legacy = G("GetQuestsCompleted")
  if legacy then
    local t = legacy() or {}
    for id, v in pairs(t) do if v then set[id] = true end end
    return set, true
  end
  return set, false
end

-- Tri-state: true / false when the client answers, nil when the API is unavailable or secret.
function API.IsUnitOnQuest(unit, questID)
  local f = NS("C_QuestLog", "IsUnitOnQuest")
  if not f then return nil end
  local ok, r = pcall(f, unit, questID)
  if not ok then return nil end
  r = plain(r)
  if r == nil then return nil end
  return r and true or false
end

function API.IsQuestPushable(questID)
  local f = NS("C_QuestLog", "IsPushableQuest")
  if f then return f(questID) and true or false end
  return nil
end

----------------------------------------------------------------------
-- Map / position
----------------------------------------------------------------------
function API.GetUnitPosition(unit)
  local best = NS("C_Map", "GetBestMapForUnit")
  local pos = NS("C_Map", "GetPlayerMapPosition")
  if not best or not pos then return nil end
  local mapID = plain(best(unit or "player"))
  if not mapID then return nil end
  local v = pos(mapID, unit or "player")
  if not v then return mapID, nil, nil end
  local x, y = v:GetXY()
  x, y = plain(x), plain(y)
  if not x or not y or (x == 0 and y == 0) then return mapID, nil, nil end
  return mapID, x * 100, y * 100
end

function API.GetMapSize(mapID)
  local f = NS("C_Map", "GetMapWorldSize")
  if not f or not mapID then return nil end
  local w, h = f(mapID)
  if w and h and w > 0 and h > 0 then return w, h end
  return nil
end

-- Converts map percent coordinates to continent/world coordinates (yards).
function API.ToWorld(mapID, x, y)
  local f = NS("C_Map", "GetWorldPosFromMapPos")
  local vec = G("CreateVector2D")
  if not f or not vec or not mapID then return nil end
  local continent, pos = f(mapID, vec(x / 100, y / 100))
  if not continent or not pos then return nil end
  local wx, wy = pos:GetXY()
  return continent, wx, wy
end

-- World coordinates use the game's convention (position_x = north, position_y = west).
-- UnitPosition returns them in that order: 1st = position_x, 2nd = position_y (measured in the 1.60.1.70532
-- client: [1] = -2926.20 = X, [2] = -283.10 = Y at Camp Narache).
-- C_Map's world vectors are calibrated against it at runtime (API.CalibrateWorld) instead of assuming their order.
API.worldAxis = "unknown"   -- "same" | "swapped" | "unknown"

-- The map id of the instance the character is in (GetInstanceInfo's 8th value), nil outside instances or when the
-- client does not say. Inside dungeons this client gives no UnitPosition (2026-10-28), so a dungeon guide uses this.
function API.GetInstanceMapID()
  local f = G("GetInstanceInfo")
  if type(f) ~= "function" then return nil end
  local ok, _, kind, _, _, _, _, _, id = pcall(f)
  if not ok or kind == "none" then return nil end
  return plain(id)
end

function API.GetPlayerWorldPosition()
  local up = G("UnitPosition")
  if up then
    local posX, posY, _, instance = up("player")
    posX, posY, instance = plain(posX), plain(posY), plain(instance)
    if posX and posY and instance then return { cont = instance, wx = posX, wy = posY } end
  end
  local map, x, y = API.GetUnitPosition("player")
  if map and x then return API.MapToWorld(map, x, y) end
  return nil
end

-- Map percent -> world loc in server convention, using the calibration when known.
function API.MapToWorld(mapID, x, y)
  local cont, a, b = API.ToWorld(mapID, x, y)
  if not cont then return nil end
  if API.worldAxis == "swapped" then a, b = b, a end
  return { cont = cont, wx = a, wy = b }
end

-- World loc (server convention) -> uiMapID and map percent, via the client's own map data.
function API.WorldToMap(loc, uiMapID)
  local f = NS("C_Map", "GetMapPosFromWorldPos")
  local vec = G("CreateVector2D")
  if not f or not vec or not loc or loc.cont == nil then return nil end
  local a, b = loc.wx, loc.wy
  if API.worldAxis == "swapped" then a, b = b, a end
  local ok, mapID, pos = pcall(f, loc.cont, vec(a, b), uiMapID)
  if not ok or not mapID or not pos then return nil end
  local x, y = pos:GetXY()
  if not x then return nil end
  return mapID, x * 100, y * 100
end

-- Compares UnitPosition with C_Map's conversion of the same spot to learn C_Map's axis order.
function API.CalibrateWorld()
  local up = G("UnitPosition")
  local map, x, y = API.GetUnitPosition("player")
  if not up or not map or not x then return API.worldAxis end
  local posX, posY = up("player")
  posX, posY = plain(posX), plain(posY)
  local cont, a, b = API.ToWorld(map, x, y)
  if not posX or not cont then return API.worldAxis end
  local tol = 5
  if math.abs(a - posX) < tol and math.abs(b - posY) < tol then API.worldAxis = "same"
  elseif math.abs(a - posY) < tol and math.abs(b - posX) < tol then API.worldAxis = "swapped" end
  API.caps.worldAxis = API.worldAxis
  return API.worldAxis
end

function API.GetFacing()
  local f = G("GetPlayerFacing")
  if not f then return nil end
  return plain(f())
end

function API.GetMapName(mapID)
  local f = NS("C_Map", "GetMapInfo")
  if not f or not mapID then return nil end
  local info = f(mapID)
  return info and info.name
end

-- The game's own group finder window, opened as its keybinding does (FLC never searches or queues for a group).
-- Returns the function used, or nil when this client has none of them.
-- The Forever client 1.60.1.70532 has the classic finder (LFGParentFrame, with LFGBrowseFrame and LFGListingFrame) and
-- no toggle function for it (client run 20261028-225318): it is shown as a panel, as its micro button does.
function API.OpenGroupFinder()
  for _, name in ipairs({ "PVEFrame_ToggleFrame", "ToggleLFGParentFrame", "LFGParentFrame_Toggle", "ToggleLFDParentFrame" }) do
    local f = G(name)
    if type(f) == "function" and pcall(f) then return name end
  end
  local frame, show = G("LFGParentFrame"), G("ShowUIPanel")
  if type(frame) == "table" and type(show) == "function" and pcall(show, frame) then return "LFGParentFrame" end
  return nil
end

-- Optional waypoint providers. TomTom is "All Rights Reserved": called, never bundled.
function API.SetWaypoint(mapID, x, y, title, provider)
  local tt = G("TomTom")
  if (provider == "auto" or provider == "tomtom") and tt and tt.AddWaypoint then
    local ok = pcall(tt.AddWaypoint, tt, mapID, x / 100, y / 100, { title = title, persistent = false })
    if ok then return "tomtom" end
  end
  if provider == "auto" or provider == "blizzard" then
    local set = NS("C_Map", "SetUserWaypoint")
    local point = G("UiMapPoint")
    if set and point and point.CreateFromCoordinates then
      local ok = pcall(set, point.CreateFromCoordinates(mapID, x / 100, y / 100))
      if ok then return "blizzard" end
    end
  end
  return nil
end

----------------------------------------------------------------------
-- Travel: flight map, Hearthstone (Engine/Travel.lua). Every call is optional: without it the planner only walks.
----------------------------------------------------------------------
local FLIGHT_CURRENT, FLIGHT_REACHABLE = 0, 1   -- Enum.FlightPathState (Mainline); read from Enum when present
local HEARTHSTONE = 6948

local function flightStates()
  local e = G("Enum")
  local s = type(e) == "table" and e.FlightPathState
  if type(s) == "table" and s.Current and s.Reachable then return s.Current, s.Reachable end
  return FLIGHT_CURRENT, FLIGHT_REACHABLE
end

-- The flight map's nodes, readable only while it is open (TAXIMAP_OPENED). Returns a list of
-- { id, name, known, current, loc = { cont, wx, wy } | nil } and the API shape used ("modern" | "legacy" | nil).
-- "known" = the character can fly there from here (Current or Reachable); positions come from the taxi map's
-- coordinates when the client can convert them.
function API.GetTaxiNodes()
  local out = {}
  local mapFn = G("GetTaxiMapID")
  local mapID
  if mapFn then
    local ok, m = pcall(mapFn)
    mapID = ok and plain(m) or nil
  end
  local all = NS("C_TaxiMap", "GetAllTaxiNodes")
  if all and mapID then
    local ok, nodes = pcall(all, mapID)
    if ok and type(nodes) == "table" then
      local cur, reach = flightStates()
      for _, n in ipairs(nodes) do
        if type(n) == "table" then
          local state = plain(n.state)
          local loc
          if n.position and n.position.GetXY then
            local x, y = n.position:GetXY()
            x, y = plain(x), plain(y)
            if x and y then loc = API.MapToWorld(mapID, x * 100, y * 100) end
          end
          out[#out + 1] = { id = plain(n.nodeID), name = plain(n.name), current = state == cur,
            known = state == cur or state == reach, loc = loc }
        end
      end
      return out, "modern"
    end
  end
  local num = G("NumTaxiNodes")
  local nameFn, typeFn, posFn = G("TaxiNodeName"), G("TaxiNodeGetType"), G("TaxiNodePosition")
  if num and nameFn and typeFn then
    local ok, count = pcall(num)
    for i = 1, (ok and plain(count) or 0) do
      local name, kind = plain(nameFn(i)), plain(typeFn(i))
      local loc
      if posFn and mapID then
        local x, y = posFn(i)
        x, y = plain(x), plain(y)
        if x and y then loc = API.MapToWorld(mapID, x * 100, y * 100) end
      end
      if name then
        out[#out + 1] = { id = name, name = name, current = kind == "CURRENT",
          known = kind == "CURRENT" or kind == "REACHABLE", loc = loc }
      end
    end
    return out, "legacy"
  end
  return out, nil
end

-- Name of the Hearthstone's bind location ("Razor Hill"), or nil.
function API.GetBindLocation()
  local f = G("GetBindLocation")
  if not f then return nil end
  local ok, name = pcall(f)
  name = ok and plain(name) or nil
  if type(name) ~= "string" or name == "" then return nil end
  return name
end

-- has: true/false when the client says whether the Hearthstone is in the bags (nil: unknown);
-- remaining: seconds of cooldown left, 0 when ready (nil: unknown).
function API.GetHearthstone()
  local count = NS("C_Item", "GetItemCount") or G("GetItemCount")
  local cooldown = NS("C_Container", "GetItemCooldown") or G("GetItemCooldown")
  local has, remaining
  if count then
    local ok, n = pcall(count, HEARTHSTONE)
    n = ok and plain(n) or nil
    if type(n) == "number" then has = n > 0 end
  end
  if cooldown then
    local ok, start, duration = pcall(cooldown, HEARTHSTONE)
    start, duration = plain(start), plain(duration)
    if ok and type(start) == "number" and type(duration) == "number" then
      remaining = (start > 0 and duration > 0) and math.max(0, start + duration - API.Time()) or 0
    end
  end
  return has, remaining
end

-- True while the player rides a flight path; nil when the client cannot say.
function API.OnTaxi()
  local f = G("UnitOnTaxi")
  if not f then return nil end
  local ok, r = pcall(f, "player")
  if not ok then return nil end
  r = plain(r)
  if r == nil then return nil end
  return r and true or false
end

----------------------------------------------------------------------
-- Group
----------------------------------------------------------------------
local INSTANCE_CATEGORY = 2  -- LE_PARTY_CATEGORY_INSTANCE

function API.IsInGroup()
  local f = G("IsInGroup")
  return f and f() or false
end

function API.GetGroupChannel()
  local inGroup = G("IsInGroup")
  if not inGroup then return nil end
  if inGroup(G("LE_PARTY_CATEGORY_INSTANCE") or INSTANCE_CATEGORY) then return "INSTANCE_CHAT" end
  if G("IsInRaid") and G("IsInRaid")() then return "RAID" end
  if inGroup() then return "PARTY" end
  return nil
end

-- Party units only (1-5 players). Values the client hides as secret come back as nil.
function API.GetGroupRoster()
  local roster = {}
  local n = G("GetNumSubgroupMembers") and G("GetNumSubgroupMembers")() or 0
  for i = 1, math.min(n, 4) do
    local unit = "party" .. i
    local key = unitFullName(unit)
    if key then
      local m = { unit = unit, key = key, name = U.shortName(key) }
      m.level = G("UnitLevel") and plain(G("UnitLevel")(unit)) or nil
      if m.level and m.level <= 0 then m.level = nil end
      if G("UnitClass") then
        local _, classFile = G("UnitClass")(unit)
        m.class = plain(classFile)
      end
      m.connected = nil
      if G("UnitIsConnected") then
        local c = plain(G("UnitIsConnected")(unit))
        if c ~= nil then m.connected = c and true or false end
      end
      m.leader = G("UnitIsGroupLeader") and plain(G("UnitIsGroupLeader")(unit)) or false
      roster[#roster + 1] = m
    end
  end
  return roster
end

function API.IsPlayerLeader()
  local f = G("UnitIsGroupLeader")
  return f and plain(f("player")) and true or false
end

----------------------------------------------------------------------
-- Chat
----------------------------------------------------------------------
-- Publishes a value as a global other addons can reach (FLC_Packs, the guide-pack API).
function API.Export(name, value)
  ns.env[name] = value
end

function API.RegisterPrefix(prefix)
  local f = NS("C_ChatInfo", "RegisterAddonMessagePrefix") or G("RegisterAddonMessagePrefix")
  if f then return f(prefix) end
  return false
end

-- Returns "ok" | "throttled" | "lockdown" | "unavailable" | "error:<code>".
function API.SendAddonMessage(prefix, msg, channel)
  local f = NS("C_ChatInfo", "SendAddonMessage")
  if not f then return "unavailable" end
  local ok, result = pcall(f, prefix, msg, channel)
  if not ok then return "error:lua" end
  if result == nil or result == true or result == 0 then return "ok" end
  if result == false then return "error:false" end
  if result == 3 or result == 8 then return "throttled" end
  if result == 11 then return "lockdown" end
  return "error:" .. tostring(result)
end

function API.InChatLockdown()
  local f = NS("C_ChatInfo", "InChatMessagingLockdown")
  if not f then return false end
  local ok, r = pcall(f)
  return ok and r and true or false
end

-- Party/instance chat. Pipes must be escaped or the client treats them as UI escape codes.
function API.SendChat(text, channel)
  if API.InChatLockdown() then return "lockdown" end
  text = string.gsub(text, "|", "||")
  local f = NS("C_ChatInfo", "SendChatMessage") or G("SendChatMessage")
  if not f then return "unavailable" end
  local ok = pcall(f, text, channel)
  return ok and "ok" or "error:lua"
end

function API.Print(msg)
  local frame = G("DEFAULT_CHAT_FRAME")
  if frame and frame.AddMessage then
    frame:AddMessage("|cff3fc7ebFLC|r " .. tostring(msg))
  end
end

----------------------------------------------------------------------
-- Quest windows (Engine/QuestFlow.lua): what an NPC offers and the quest window's buttons. None of these is a
-- protected call; every one is optional, and a client without one just leaves that window to the player.
----------------------------------------------------------------------
local function call(name, ...)
  local f = G(name)
  if not f then return nil end
  local ok, a, b, c, d, e = pcall(f, ...)
  if ok then return plain(a), plain(b), plain(c), plain(d), plain(e) end
  return nil
end

function API.ShiftDown() return call("IsShiftKeyDown") == true end

function API.QuestWindowID()
  local id = call("GetQuestID")
  return type(id) == "number" and id > 0 and id or nil
end

function API.QuestAccept() return G("AcceptQuest") ~= nil and pcall(G("AcceptQuest")) end
function API.QuestCompletable() return call("IsQuestCompletable") == true end
function API.QuestComplete() return G("CompleteQuest") ~= nil and pcall(G("CompleteQuest")) end
function API.QuestMoneyToGet() return tonumber(call("GetQuestMoneyToGet")) or 0 end
function API.QuestChoices() return tonumber(call("GetNumQuestChoices")) or 0 end
function API.QuestReward(choice) return G("GetQuestReward") ~= nil and pcall(G("GetQuestReward"), choice) end

-- Equip locations -> the advisor's reward slots (Engine/Advisor.lua AD.SLOTS)
API.EQUIP_SLOTS = { INVTYPE_HEAD = "head", INVTYPE_NECK = "neck", INVTYPE_SHOULDER = "shoulder", INVTYPE_CHEST = "chest",
  INVTYPE_ROBE = "chest", INVTYPE_WAIST = "waist", INVTYPE_LEGS = "legs", INVTYPE_FEET = "feet", INVTYPE_WRIST = "wrist",
  INVTYPE_HAND = "hands", INVTYPE_FINGER = "finger", INVTYPE_TRINKET = "trinket", INVTYPE_CLOAK = "back",
  INVTYPE_WEAPONMAINHAND = "main-hand", INVTYPE_WEAPON = "one-hand", INVTYPE_2HWEAPON = "two-hand",
  INVTYPE_WEAPONOFFHAND = "off-hand", INVTYPE_SHIELD = "shield", INVTYPE_HOLDABLE = "held-in-off-hand",
  INVTYPE_RANGED = "ranged", INVTYPE_RANGEDRIGHT = "ranged", INVTYPE_THROWN = "thrown" }

-- One reward to choose: { link, name, count, usable, slot, dps, stats, sell (copper each, nil while not loaded) }
function API.QuestChoiceItem(i)
  local name, _, count, _, usable = call("GetQuestItemInfo", "choice", i)
  local link = call("GetQuestItemLink", "choice", i)
  local item = { link = link, name = name, count = tonumber(count) or 1, usable = usable ~= false and usable ~= nil,
    stats = {} }
  if not link then return item end
  local info = G("GetItemInfo") or NS("C_Item", "GetItemInfo")
  if info then
    local ok, n, _, _, _, _, _, _, _, equipLoc, _, sell = pcall(info, link)
    if ok and plain(n) then
      item.slot = API.EQUIP_SLOTS[plain(equipLoc) or ""]
      item.sell = tonumber(plain(sell))
    end
  end
  local stats = G("GetItemStats") or NS("C_Item", "GetItemStats")
  if stats then
    local ok, t = pcall(stats, link)
    if ok and type(t) == "table" then
      for k, v in pairs(t) do
        if type(v) == "number" then
          if k == "ITEM_MOD_DAMAGE_PER_SECOND_SHORT" then item.dps = v
          elseif API.ITEM_STATS[k] then item.stats[API.ITEM_STATS[k]] = v end
        end
      end
    end
  end
  return item
end

-- What an NPC's gossip or greeting window offers: { available = { {id, title, trivial} }, active = { {id, title,
-- complete} } }. ids are nil where the client gives only titles (QuestFlow matches those by name).
function API.NpcQuests(kind)
  local out = { available = {}, active = {} }
  local gi = ns.env.C_GossipInfo
  if kind == "gossip" and gi and gi.GetAvailableQuests then
    local ok, list = pcall(gi.GetAvailableQuests)
    for _, q in ipairs(ok and type(list) == "table" and list or {}) do
      out.available[#out.available + 1] = { id = plain(q.questID), title = plain(q.title), trivial = plain(q.isTrivial) }
    end
    ok, list = pcall(gi.GetActiveQuests)
    for _, q in ipairs(ok and type(list) == "table" and list or {}) do
      out.active[#out.active + 1] = { id = plain(q.questID), title = plain(q.title), complete = plain(q.isComplete) }
    end
  elseif kind == "gossip" then
    local av = { pcall(G("GetGossipAvailableQuests") or function() end) }
    for i = 2, #av, 7 do out.available[#out.available + 1] = { title = plain(av[i]), trivial = plain(av[i + 2]) } end
    local ac = { pcall(G("GetGossipActiveQuests") or function() end) }
    for i = 2, #ac, 6 do out.active[#out.active + 1] = { title = plain(ac[i]), complete = plain(ac[i + 3]) } end
  else
    for i = 1, tonumber(call("GetNumAvailableQuests")) or 0 do
      local _, _, _, _, id = call("GetAvailableQuestInfo", i)
      out.available[#out.available + 1] = { id = id, title = call("GetAvailableTitle", i) }
    end
    for i = 1, tonumber(call("GetNumActiveQuests")) or 0 do
      local title, complete = call("GetActiveTitle", i)
      out.active[#out.active + 1] = { id = call("GetActiveQuestID", i), title = title, complete = complete }
    end
  end
  return out
end

-- Opens one quest of the NPC's list: by id where the client takes it, else by its place in the list.
function API.NpcSelect(kind, which, i, id)
  local gi = ns.env.C_GossipInfo
  if kind == "gossip" and gi and id then
    local f = which == "available" and gi.SelectAvailableQuest or gi.SelectActiveQuest
    return f ~= nil and pcall(f, id)
  end
  local name = kind == "gossip" and (which == "available" and "SelectGossipAvailableQuest" or "SelectGossipActiveQuest")
    or (which == "available" and "SelectAvailableQuest" or "SelectActiveQuest")
  return G(name) ~= nil and pcall(G(name), i)
end

-- Target NPC id from GUID "Creature-0-...-npcID-spawn". Forever hides server/spawn parts only.
function API.GetNpcInfo(unit)
  local guidFn = G("UnitGUID")
  local guid = guidFn and plain(guidFn(unit or "npc"))
  local name = G("UnitName") and plain(G("UnitName")(unit or "npc"))
  local npcID
  if type(guid) == "string" then
    local parts = U.split(guid, "-")
    if parts[1] == "Creature" or parts[1] == "Vehicle" then npcID = tonumber(parts[6]) end
  end
  return npcID, name
end

----------------------------------------------------------------------
-- Character build (Class Quest Advisor): equipment, talents, known spells. Every call is optional: when the client
-- lacks one, the advisor keeps the generator's general advice and says it could not compare.
----------------------------------------------------------------------
-- GetItemStats keys -> the advisor's stat names (tools/catalog/rewards.py)
API.ITEM_STATS = {
  ITEM_MOD_STRENGTH_SHORT = "strength", ITEM_MOD_AGILITY_SHORT = "agility", ITEM_MOD_STAMINA_SHORT = "stamina",
  ITEM_MOD_INTELLECT_SHORT = "intellect", ITEM_MOD_SPIRIT_SHORT = "spirit", ITEM_MOD_ATTACK_POWER_SHORT = "attack-power",
  ITEM_MOD_RANGED_ATTACK_POWER_SHORT = "ranged-attack-power", ITEM_MOD_SPELL_POWER_SHORT = "spell-power",
  ITEM_MOD_SPELL_DAMAGE_DONE_SHORT = "spell-damage", ITEM_MOD_SPELL_HEALING_DONE_SHORT = "healing",
  ITEM_MOD_DEFENSE_SKILL_RATING_SHORT = "defense",
}
API.GEAR_SLOTS = { 1, 2, 3, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18 }

-- { [slot] = { dps = n, stats = { strength = n, ... } } or false (empty) }, or nil when items cannot be read.
function API.GetEquippedGear()
  local link, stats = G("GetInventoryItemLink"), G("GetItemStats") or NS("C_Item", "GetItemStats")
  if not link or not stats then return nil end
  local out = {}
  for _, slot in ipairs(API.GEAR_SLOTS) do
    local ok, l = pcall(link, "player", slot)
    l = ok and plain(l) or nil
    if not l then
      out[slot] = false
    else
      local ok2, t = pcall(stats, l)
      if ok2 and type(t) == "table" then
        local g = { stats = {} }
        local info = G("GetItemInfo")
        if info then
          local ok3, _, _, _, _, _, _, _, _, equipLoc = pcall(info, l)
          if ok3 then g.equipLoc = plain(equipLoc) end
        end
        for k, v in pairs(t) do
          if type(v) == "number" then
            if k == "ITEM_MOD_DAMAGE_PER_SECOND_SHORT" then g.dps = v
            elseif API.ITEM_STATS[k] then g.stats[API.ITEM_STATS[k]] = v end
          end
        end
        out[slot] = g
      end
      -- an item whose data is not cached yet stays unknown (nil) rather than empty
    end
  end
  return out
end

-- The item's name in the client's language, or nil while the client has not loaded that item yet (it is asked to
-- load it then, unless noLoad: GET_ITEM_INFO_RECEIVED follows).
function API.GetItemName(id, noLoad)
  if type(id) ~= "number" then return nil end
  local name
  local byId = NS("C_Item", "GetItemNameByID")
  if byId then
    local ok, n = pcall(byId, id)
    name = ok and plain(n) or nil
  end
  if not name then
    local info = G("GetItemInfo") or NS("C_Item", "GetItemInfo")
    if info then
      local ok, n = pcall(info, id)
      name = ok and plain(n) or nil
    end
  end
  if type(name) == "string" and name ~= "" then return name end
  local load = not noLoad and NS("C_Item", "RequestLoadItemDataByID")
  if load then pcall(load, id) end
  return nil
end

-- The talent tab with the most points (1-3), or nil (no talents spent, or the API is missing).
function API.GetTalentSpec()
  local info = G("GetTalentTabInfo")
  if not info then return API.GetSpecializationTab() end
  local best, bestPoints = nil, 0
  for tab = 1, 3 do
    local ok, a, b, c, d, e = pcall(info, tab)
    if ok then
      -- classic: name, iconTexture, pointsSpent, fileName; later clients put pointsSpent further: take the first number
      -- after the name that is not a texture id
      local points
      for _, v in ipairs({ c, e, d }) do
        if type(v) == "number" and v >= 0 and v <= 61 then points = v break end
      end
      if points and points > bestPoints then best, bestPoints = tab, points end
    end
  end
  return best
end

-- Clients without talent tabs (WoW: Forever 1.60 has C_SpecializationInfo instead): the chosen specialization's role
-- and primary stat say whether a druid, shaman or paladin plays as a caster. Returned as the classic tab the advisor
-- knows (1 = Balance / Elemental / Holy, a caster; 2 = not), or nil when there is none or the client cannot say.
function API.GetSpecializationTab()
  local get = G("GetSpecialization") or NS("C_SpecializationInfo", "GetSpecialization")
  local info = G("GetSpecializationInfo") or NS("C_SpecializationInfo", "GetSpecializationInfo")
  if not get or not info then return nil end
  local ok, index = pcall(get)
  if not ok or type(index) ~= "number" or index < 1 then return nil end
  local ok2, id, _, _, _, role, primaryStat = pcall(info, index)
  if not ok2 or not id then return nil end
  if role == "HEALER" or primaryStat == 4 then return 1 end   -- 4: LE_UNIT_STAT_INTELLECT
  if role == "TANK" or role == "DAMAGER" then return 2 end
  return nil
end

-- The role the player plays: "TANK", "HEALER" or "DAMAGER", or nil when the client cannot say. The group's role
-- when one is assigned (the dungeon finder's), else the chosen specialization's.
function API.GetPlayerRole()
  local known = { TANK = true, HEALER = true, DAMAGER = true }
  local assigned = G("UnitGroupRolesAssigned")
  if assigned then
    local ok, r = pcall(assigned, "player")
    if ok and known[r] then return r end
  end
  local get = G("GetSpecialization") or NS("C_SpecializationInfo", "GetSpecialization")
  local info = G("GetSpecializationInfo") or NS("C_SpecializationInfo", "GetSpecializationInfo")
  if not get or not info then return nil end
  local ok, index = pcall(get)
  if not ok or type(index) ~= "number" or index < 1 then return nil end
  local ok2, id, _, _, _, role = pcall(info, index)
  if ok2 and id and known[role] then return role end
  return nil
end

-- true when the character has the spell, false when not, nil when the client cannot say. By id when given
-- (IsPlayerSpell / IsSpellKnown), else by name (GetSpellInfo answers for spells in the spellbook).
function API.KnowsSpell(name, id)
  if type(id) == "number" then
    local f = G("IsPlayerSpell") or G("IsSpellKnown")
    if f then
      local ok, r = pcall(f, id)
      if ok and type(r) == "boolean" then return r end
    end
  end
  local info = G("GetSpellInfo") or NS("C_Spell", "GetSpellInfo")
  if not info or type(name) ~= "string" then return nil end
  local ok, r = pcall(info, name)
  if not ok then return nil end
  return r ~= nil
end

-- ---------------------------------------------------------------------------------------------------------------
-- Appearance ("Adapt to my interface", docs/ADAPTIVE_UI.md): what the player's interface looks like, as plain values.
-- Only the public media tables those interfaces give their own plugins are read, through pcall, and only numbers and
-- strings come out (secret values are dropped). Nothing of theirs is changed.

local function colorOf(v)
  if type(v) ~= "table" then return nil end
  local r, g, b, a = plain(v[1] or v.r), plain(v[2] or v.g), plain(v[3] or v.b), plain(v[4] or v.a)
  if type(r) ~= "number" or type(g) ~= "number" or type(b) ~= "number" then return nil end
  return { r, g, b, type(a) == "number" and a or nil }
end

local function str(v)
  v = plain(v)
  return type(v) == "string" and v or nil
end

function API.AddOnLoaded(name)
  local f = NS("C_AddOns", "IsAddOnLoaded") or G("IsAddOnLoaded")
  if not f then return false end
  local ok, loaded = pcall(f, name)
  return ok and plain(loaded) and true or false
end

local function readElvUI()
  local E = G("ElvUI")
  if type(E) ~= "table" then return nil end
  local ok, out = pcall(function()
    local e = E[1]
    local m = e and e.media
    if type(m) ~= "table" then return nil end
    local db = type(e.db) == "table" and type(e.db.general) == "table" and e.db.general or {}
    return { version = str(e.version) or (type(plain(e.version)) == "number" and tostring(e.version)) or nil, media = {
      backdrop = colorOf(m.backdropcolor), backdropFade = colorOf(m.backdropfadecolor), border = colorOf(m.bordercolor),
      value = colorOf(m.rgbvaluecolor), font = str(m.normFont), bar = str(m.normTex),
      fontSize = type(plain(db.fontSize)) == "number" and db.fontSize or nil } }
  end)
  return ok and out or nil
end

local function readTukui()
  local T = G("Tukui")
  if type(T) ~= "table" or type(T.unpack) ~= "function" then return nil end
  local ok, out = pcall(function()
    local t, C = T:unpack()
    if type(C) ~= "table" then return nil end
    local gen, med = type(C.General) == "table" and C.General or {}, type(C.Medias) == "table" and C.Medias or {}
    return { version = str(t and t.Version), media = { backdrop = colorOf(gen.BackdropColor), border = colorOf(gen.BorderColor),
      font = str(med.Font), bar = str(med.Normal) } }
  end)
  return ok and out or nil
end

function API.AddOnVersion(name)
  local f = NS("C_AddOns", "GetAddOnMetadata") or G("GetAddOnMetadata")
  if not f then return nil end
  local ok, v = pcall(f, name, "Version")
  return ok and str(v) or nil
end

-- The game's own font as the interface left it (RealUI and GW2_UI set their fonts on the game's font objects)
local function gameFont()
  local gfn = G("GameFontNormal")
  if not (gfn and gfn.GetFont) then return nil end
  local ok, path, size = pcall(gfn.GetFont, gfn)
  return ok and str(path) or nil, ok and type(plain(size)) == "number" and size or nil
end

-- NDui (the "forever" build): its namespace is the global NDui = { B, C, L, DB }; flat black panels at its skin alpha,
-- black borders, the class colour as accent, its font and bar texture.
local function readNDui()
  local N = G("NDui")
  if type(N) ~= "table" then return nil end
  local ok, out = pcall(function()
    local C, DB = N[2], N[4]
    if type(DB) ~= "table" then return nil end
    local skins = type(C) == "table" and type(C.db) == "table" and type(C.db.Skins) == "table" and C.db.Skins or {}
    local alpha = plain(skins.SkinAlpha)
    local font = type(DB.Font) == "table" and DB.Font or {}
    return { backdrop = { 0, 0, 0, type(alpha) == "number" and alpha or 0.5 }, border = { 0, 0, 0, 1 },
      value = colorOf({ DB.r, DB.g, DB.b }), font = str(font[1]), bar = str(DB.normTex),
      fontSize = type(plain(font[2])) == "number" and font[2] or nil }
  end)
  return ok and out or nil
end

-- RealUI: its skin is Aurora (global Aurora.Color: frame, panel, border, highlight), its bar texture in
-- RealUI.textures; its fonts are set on the game's font objects.
local function readRealUI()
  local R, Au = G("RealUI"), G("Aurora")
  if type(R) ~= "table" then return nil end
  local ok, out = pcall(function()
    local col = type(Au) == "table" and type(Au.Color) == "table" and Au.Color or {}
    local tex = type(R.textures) == "table" and R.textures or {}
    local font, size = gameFont()
    return { backdrop = colorOf(col.panelBg) or colorOf(col.frame), border = colorOf(col.border),
      value = colorOf(col.highlight), font = font, bar = str(tex.plain), fontSize = size }
  end)
  return ok and out or nil
end

-- SpartanUI: the active artwork style's registered accent and font (its theme registry's metadata only: asking for
-- a theme's full data would load it).
local function readSpartanUI()
  local S = G("SUI")
  if type(S) ~= "table" then return nil end
  local ok, out = pcall(function()
    -- its own getter (the saved style, or its default before its setup wizard ran), else the saved style
    local style = type(S.GetActiveStyle) == "function" and str(S:GetActiveStyle())
      or (type(S.DB) == "table" and type(S.DB.Artwork) == "table" and str(S.DB.Artwork.Style)) or nil
    local reg = type(S.ThemeRegistry) == "table" and S.ThemeRegistry or nil
    local entry = style and reg and type(reg.Get) == "function" and reg:Get(style) or nil
    local font = type(S.Font) == "table" and type(S.Font.GetFont) == "function" and S.Font:GetFont() or nil
    return { style = style, value = type(entry) == "table" and colorOf(entry.accent) or nil, font = str(font) }
  end)
  return ok and out or nil
end

-- GW2 UI: its namespace GW2_ADDON; its accent colour, its status bar texture, its font on the game's font objects.
local function readGW2()
  local GW = G("GW2_ADDON")
  if type(GW) ~= "table" then return nil end
  local ok, out = pcall(function()
    local col = type(GW.Colors) == "table" and GW.Colors or {}
    local font, size = gameFont()
    return { value = colorOf(col.Accent), font = font, fontSize = size,
      bar = "Interface\\AddOns\\GW2_UI\\textures\\uistuff\\gwstatusbar" }
  end)
  return ok and out or nil
end

-- Interfaces with an adapter besides ElvUI and Tukui: { id, addon folder, reader }
API.ADAPTED_INTERFACES = {
  { id = "ndui", name = "NDui", read = readNDui },
  { id = "realui", name = "RealUI", read = readRealUI },
  { id = "spartanui", name = "SpartanUI", read = readSpartanUI },
  { id = "gw2ui", name = "GW2_UI", read = readGW2 },
}

-- Other complete interfaces FLC recognizes but has no adapter for: the manual assistant is offered. KkthnxUI has no
-- build for this client; LUI publishes none outside its source.
API.KNOWN_INTERFACES = { "KkthnxUI", "LUI" }

-- { id = "elvui" | "tukui" | "blizzard" | "other", name, version, media = { ... plain values ... } }
function API.DetectInterface()
  local e = readElvUI()
  if e then return { id = "elvui", name = "ElvUI", version = e.version, media = e.media } end
  local t = readTukui()
  if t then return { id = "tukui", name = "Tukui", version = t.version, media = t.media } end
  for _, ui in ipairs(API.ADAPTED_INTERFACES) do
    if API.AddOnLoaded(ui.name) then
      local m = ui.read()
      if m then return { id = ui.id, name = ui.name, version = API.AddOnVersion(ui.name), media = m } end
    end
  end
  local font = gameFont()
  local nfc = G("NORMAL_FONT_COLOR")
  local media = { font = font, normal = colorOf(nfc) }
  for _, name in ipairs(API.KNOWN_INTERFACES) do
    if API.AddOnLoaded(name) then return { id = "other", name = name, media = media } end
  end
  return { id = "blizzard", name = "Blizzard", media = media }
end

-- "Take the style of a window": the frame under the mouse (or one of its parents) that has a backdrop, read with its
-- own getters. nil when nothing readable is there (most Blizzard windows draw textures, not backdrops).
function API.StyleUnderMouse()
  local foci = G("GetMouseFoci")
  local frame
  if foci then
    local ok, list = pcall(foci)
    frame = ok and type(list) == "table" and list[1] or nil
  elseif G("GetMouseFocus") then
    local ok, f = pcall(G("GetMouseFocus"))
    frame = ok and f or nil
  end
  for _ = 1, 6 do
    if type(frame) ~= "table" then return nil end
    if type(frame.GetBackdropColor) == "function" then
      local ok, r, g, b, a = pcall(frame.GetBackdropColor, frame)
      if ok and type(plain(r)) == "number" and type(plain(g)) == "number" and type(plain(b)) == "number" then
        local out = { bg = { r, g, b, type(plain(a)) == "number" and a or 1 } }
        local ok2, br, bg2, bb, ba = pcall(frame.GetBackdropBorderColor, frame)
        if ok2 and type(plain(br)) == "number" and type(plain(bg2)) == "number" and type(plain(bb)) == "number" then
          out.border = { br, bg2, bb, type(plain(ba)) == "number" and ba or 1 }
        end
        local okn, name = pcall(frame.GetName, frame)
        out.name = okn and str(name) or nil
        return out
      end
    end
    local okp, parent = pcall(frame.GetParent, frame)
    frame = okp and parent or nil
  end
  return nil
end
