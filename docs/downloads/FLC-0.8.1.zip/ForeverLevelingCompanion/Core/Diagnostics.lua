-- Diagnostics: ring-buffer log, error capture, performance counters and a copyable report.
-- Nothing here leaves the client; the report is shown in an edit box for the user to copy.
local _, ns = ...
local U = ns.U

local Diag = {
  maxEntries = 300,
  entries = {},
  errors = {},
  perf = {},
  counters = {},
  levelNames = { "ERROR", "WARN", "INFO", "DEBUG" },
  level = 3,
}
ns.Diag = Diag

local LEVEL = { ERROR = 1, WARN = 2, INFO = 3, DEBUG = 4 }
Diag.LEVEL = LEVEL

-- When SavedVariables are available the buffers are persisted there so a crash before
-- logout still leaves a trace after the next /reload.
function Diag:Attach(store)
  if type(store) ~= "table" then return end
  store.log = type(store.log) == "table" and store.log or {}
  store.errors = type(store.errors) == "table" and store.errors or {}
  self.entries = store.log
  self.errors = store.errors
  self:Trim()
end

function Diag:Trim()
  while #self.entries > self.maxEntries do table.remove(self.entries, 1) end
  while #self.errors > 50 do table.remove(self.errors, 1) end
end

function Diag:Log(level, area, msg)
  local lv = LEVEL[level] or LEVEL.INFO
  if lv > self.level then return end
  self.entries[#self.entries + 1] = string.format("%.1f %s [%s] %s", ns.Now(), level, area or "-", tostring(msg))
  if #self.entries > self.maxEntries then table.remove(self.entries, 1) end
end

function Diag:Info(area, msg) self:Log("INFO", area, msg) end
function Diag:Warn(area, msg) self:Log("WARN", area, msg) end
function Diag:Debug(area, msg) self:Log("DEBUG", area, msg) end

function Diag:Error(area, err)
  local text = tostring(err)
  self:Log("ERROR", area, text)
  -- Collapse repeated errors so an OnUpdate failure cannot flood the buffer.
  local last = self.errors[#self.errors]
  if last and last.area == area and last.msg == text then
    last.count = (last.count or 1) + 1
    last.last = ns.Now()
  else
    self.errors[#self.errors + 1] = { area = area, msg = text, count = 1, first = ns.Now(), last = ns.Now() }
  end
  self:Trim()
  -- once per session, a chat line saying how to report it (the error itself stays in the report)
  if not self.told and ns.API and ns.API.Print and ns.L then
    self.told = true
    ns.API.Print(ns.L["FLC had an error. Type /flc bug to see it and report it."])
  end
end

function Diag:Count(name, n)
  self.counters[name] = (self.counters[name] or 0) + (n or 1)
end

-- Runs fn protected; returns ok plus results. Used by every client event entry point.
function Diag:Guard(area, fn, ...)
  local ok, a, b, c = pcall(fn, ...)
  if not ok then
    self:Error(area, a)
    return false
  end
  return true, a, b, c
end

-- Measures a call with the client's high resolution timer when present.
function Diag:Measure(name, fn, ...)
  local timer = ns.API and ns.API.ProfileTimer
  if not timer then return fn(...) end
  local start = timer()
  local r1, r2, r3 = fn(...)
  local elapsed = timer() - start
  local p = self.perf[name]
  if not p then
    p = { calls = 0, total = 0, max = 0 }
    self.perf[name] = p
  end
  p.calls = p.calls + 1
  p.total = p.total + elapsed
  if elapsed > p.max then p.max = elapsed end
  return r1, r2, r3
end

function Diag:BuildReport(extra)
  local lines = {}
  local function add(s) lines[#lines + 1] = s end
  add("Forever Leveling Companion diagnostics")
  add("addon " .. ns.version .. " schema " .. ns.schemaVersion .. " protocol " .. ns.protocolVersion)
  if ns.API and ns.API.GetClientInfo then
    local info = ns.API.GetClientInfo()
    add(string.format("client %s build %s interface %s project %s locale %s",
      tostring(info.version), tostring(info.build), tostring(info.interface), tostring(info.project), tostring(info.locale)))
  end
  if ns.API and ns.API.caps then
    add("capabilities:")
    for _, k in ipairs(U.keys(ns.API.caps)) do
      add("  " .. k .. " = " .. tostring(ns.API.caps[k]))
    end
  end
  if extra then
    for _, s in ipairs(extra) do add(s) end
  end
  add("counters:")
  for _, k in ipairs(U.keys(self.counters)) do add("  " .. k .. " = " .. self.counters[k]) end
  add("perf (ms total / calls / max):")
  for _, k in ipairs(U.keys(self.perf)) do
    local p = self.perf[k]
    add(string.format("  %s %.2f / %d / %.2f", k, p.total, p.calls, p.max))
  end
  add("errors:")
  for _, e in ipairs(self.errors) do
    add(string.format("  x%d [%s] %s", e.count or 1, e.area, e.msg))
  end
  add("log (last 60):")
  for i = math.max(1, #self.entries - 59), #self.entries do add("  " .. self.entries[i]) end
  return table.concat(lines, "\n")
end
