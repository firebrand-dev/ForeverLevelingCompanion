-- Localization. Keys are the English strings, so a missing translation falls back to English.
local _, ns = ...

local tables = {}
local active = {}

ns.L = setmetatable({}, {
  __index = function(_, key)
    local v = active[key]
    if v == nil or v == true then return key end
    return v
  end,
})

function ns:RegisterLocale(code, strings)
  tables[code] = tables[code] or {}
  for k, v in pairs(strings) do tables[code][k] = v end
end

-- esMX shares the Spanish table unless it registers its own overrides.
local aliases = { esMX = "esES" }

function ns:SetLocale(code)
  active = tables[code] or tables[aliases[code] or ""] or {}
  ns.locale = code
end

function ns:GetLocaleCoverage(code)
  local t = tables[code] or {}
  return ns.U.count(t)
end
