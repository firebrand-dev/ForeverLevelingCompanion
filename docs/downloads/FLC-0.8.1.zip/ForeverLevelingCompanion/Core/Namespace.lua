-- Forever Leveling Companion - shared namespace, utilities and internal message bus.
-- This file must stay free of WoW API calls so it can be loaded by the offline test harness.
local ADDON_NAME, ns = ...

ns.name = ADDON_NAME or "ForeverLevelingCompanion"
ns.version = "0.8.1"
-- Where players paste what /flc review and /flc bug show (the reports page, docs/REPORTS.md)
ns.REPORT_URL = "https://github.com/firebrand-dev/FLC-reportes/issues/new/choose"
-- Where a new version is downloaded (GitHub Releases, docs/release/LAUNCH_GO_NO_GO.md); shown, never fetched
ns.DOWNLOAD_URL = "https://github.com/firebrand-dev/ForeverLevelingCompanion/releases/latest"
ns.schemaVersion = 1      -- SavedVariables layout
ns.dataFormat = 1         -- guide data format accepted by the Guide Engine
ns.protocolVersion = 1    -- addon-to-addon protocol (see docs/PROTOCOL.md)
ns.protocolMin = 1

-- Clock is injectable so tests can control time.
ns.clock = ns.clock or function() return 0 end
function ns.Now() return ns.clock() end

----------------------------------------------------------------------
-- Utilities
----------------------------------------------------------------------
local U = {}
ns.U = U

function U.copy(t)
  if type(t) ~= "table" then return t end
  local r = {}
  for k, v in pairs(t) do r[k] = v end
  return r
end

function U.deepcopy(t, seen)
  if type(t) ~= "table" then return t end
  seen = seen or {}
  if seen[t] then return seen[t] end
  local r = {}
  seen[t] = r
  for k, v in pairs(t) do r[U.deepcopy(k, seen)] = U.deepcopy(v, seen) end
  return r
end

function U.keys(t)
  local r = {}
  for k in pairs(t) do r[#r + 1] = k end
  table.sort(r, function(a, b) return tostring(a) < tostring(b) end)
  return r
end

function U.count(t)
  local n = 0
  for _ in pairs(t) do n = n + 1 end
  return n
end

function U.set(list)
  local s = {}
  if list then for _, v in ipairs(list) do s[v] = true end end
  return s
end

function U.contains(list, value)
  if not list then return false end
  for _, v in ipairs(list) do if v == value then return true end end
  return false
end

function U.clamp(v, lo, hi)
  if v < lo then return lo end
  if v > hi then return hi end
  return v
end

function U.round(v, decimals)
  local m = 10 ^ (decimals or 0)
  return math.floor(v * m + 0.5) / m
end

-- copper -> "1g 20s 5c" / "35s 0c" / "8c"
function U.money(copper)
  copper = math.floor(tonumber(copper) or 0)
  local g, s, c = math.floor(copper / 10000), math.floor(copper / 100) % 100, copper % 100
  if g > 0 then return string.format("%dg %ds %dc", g, s, c) end
  if s > 0 then return string.format("%ds %dc", s, c) end
  return string.format("%dc", c)
end

function U.split(s, sep)
  local out = {}
  if s == nil or s == "" then return out end
  local start = 1
  while true do
    local i = string.find(s, sep, start, true)
    if not i then
      out[#out + 1] = string.sub(s, start)
      break
    end
    out[#out + 1] = string.sub(s, start, i - 1)
    start = i + #sep
  end
  return out
end

-- "0.3.0" < "0.10.1": numeric comparison of dotted versions (missing parts count as 0).
function U.versionLess(a, b)
  local pa, pb = U.split(tostring(a or "0"), "."), U.split(tostring(b or "0"), ".")
  for i = 1, math.max(#pa, #pb) do
    local x, y = tonumber(pa[i]) or 0, tonumber(pb[i]) or 0
    if x ~= y then return x < y end
  end
  return false
end

-- Shortens "Name-Realm" to "Name" for display only; keys always keep the realm.
function U.shortName(key)
  if not key then return "?" end
  return (string.match(key, "^([^%-]+)")) or key
end

----------------------------------------------------------------------
-- Internal message bus (module-to-module, never touches the client)
----------------------------------------------------------------------
local Bus = { handlers = {} }
ns.Bus = Bus

function Bus:On(event, owner, fn)
  local list = self.handlers[event]
  if not list then
    list = {}
    self.handlers[event] = list
  end
  list[#list + 1] = { owner = owner, fn = fn }
end

function Bus:Off(event, owner)
  local list = self.handlers[event]
  if not list then return end
  for i = #list, 1, -1 do
    if list[i].owner == owner then table.remove(list, i) end
  end
end

-- Every handler is isolated: one failing module must not stop the others.
function Bus:Fire(event, ...)
  local list = self.handlers[event]
  if not list then return end
  local snapshot = U.copy(list)
  for _, h in ipairs(snapshot) do
    local ok, err = pcall(h.fn, ...)
    if not ok and ns.Diag then
      ns.Diag:Error("bus:" .. event, err)
    end
  end
end

function Bus:Reset()
  self.handlers = {}
end
