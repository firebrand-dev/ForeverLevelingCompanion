-- Configuration and persistence: defaults, schema migrations and self-repair of SavedVariables.
-- FLC_DB (account) holds settings, UI layout, diagnostics and the optional data recorder.
-- FLC_CharDB (per character) holds guide progress and the active assistance session.
local _, ns = ...
local U = ns.U

local Config = {}
ns.Config = Config

Config.ANNOUNCE_MODES = { "off", "objectives", "pct25", "pct50", "every", "default" }
Config.PRESETS = { "fastxp", "balanced", "completionist", "dungeon", "hardcore" }
Config.SETUP_STATES = { pending = true, migrated = true, adapted = true, manual = true, skipped = true }

Config.accountDefaults = {
  settings = {
    locale = "auto",
    announce = { mode = "default", turnIn = true, prefix = "", minInterval = 2.0 },
    sync = { share = "ask" },              -- "ask" | "yes" | "no"
    party = { preset = "balanced", staleAfter = 180 },
    ui = { scale = 1, locked = false, showArrow = true, showTracker = true, compactInCombat = true, expanded = false,
      hideBlizzardTracker = true,          -- the game's own quest tracker hidden while FLC's is shown (UI/TrackerFrame.lua)
      minimap = { show = true, angle = 200, moved = false } },  -- FLC's minimap button, its place in degrees once
                                                                 -- the player moves it (UI/MinimapButton.lua)
    nav = { arrivalYards = 12, waypointProvider = "auto", travelYards = 1500 },
    recorder = false,
    notices = {},
    bossGuide = "basic",                   -- "basic" | "detailed" | "off" (Engine/BossGuide.lua)
    appearance = { profile = { base = "flc" } },   -- Engine/Appearance.lua; previous / fingerprint added when used
    updates = {},                          -- newest version another FLC player announced (Engine/Updates.lua)
    questFlow = { mode = "guide" },        -- accept / turn in by themselves: "guide" | "all" | "off" (Engine/QuestFlow.lua)
  },
  layout = {},
  diag = {},
  recorded = {},
}

Config.charDefaults = {
  personal = { guideID = nil, cursors = {}, reached = {}, manual = {}, skipped = {} },
  session = nil,
  turnedIn = {},   -- quest IDs seen through QUEST_TURNED_IN, covers server flag latency
  travel = { nodes = {}, bind = {} }, -- flight masters seen known on the flight map; where the Hearthstone is bound
  advisor = { decisions = {} },       -- Class Quest Advisor: the player's now / later / skip per chain
  leveling = { mode = "quests", dungeons = {} }, -- leveling mode (Engine/Modes.lua) and later / skip per dungeon
  appearance = { perCharacter = false }, -- this character's own look instead of the account's (Engine/Appearance.lua)
}

-- Fills missing keys from defaults and replaces values whose type is wrong.
-- Returns the number of repaired fields.
local function reconcile(target, defaults, path, repairs)
  for k, dv in pairs(defaults) do
    local v = target[k]
    local p = path .. "." .. tostring(k)
    if v == nil then
      target[k] = U.deepcopy(dv)
    elseif type(v) ~= type(dv) then
      repairs[#repairs + 1] = p .. " (" .. type(v) .. " -> " .. type(dv) .. ")"
      target[k] = U.deepcopy(dv)
    elseif type(dv) == "table" and next(dv) ~= nil then
      reconcile(v, dv, p, repairs)
    end
  end
end

-- Ordered migrations; each takes the table and must be idempotent.
Config.accountMigrations = {
  [1] = function(db)
    -- 0.0.x prototypes stored announce mode as a string at settings.announce.
    if db.settings and type(db.settings.announce) == "string" then
      db.settings.announce = { mode = db.settings.announce }
    end
  end,
}

Config.charMigrations = {
  [1] = function(db)
    -- 0.0.x prototypes stored a single flat cursor.
    if db.guideID or db.stepIndex then
      db.personal = db.personal or {}
      db.personal.guideID = db.personal.guideID or db.guideID
      db.personal.cursors = db.personal.cursors or {}
      if db.guideID then
        db.personal.cursors[db.guideID] = { index = db.stepIndex or 1, stepID = db.stepID }
      end
      db.guideID, db.stepIndex, db.stepID = nil, nil, nil
    end
  end,
}

local function migrate(db, migrations, label)
  local from = tonumber(db.schema) or 0
  if from > ns.schemaVersion then
    -- Data written by a newer addon version: keep it, but do not rewrite it.
    ns.Diag:Warn("config", label .. " schema " .. from .. " is newer than " .. ns.schemaVersion)
    return false
  end
  for v = from + 1, ns.schemaVersion do
    local fn = migrations[v]
    if fn then
      local ok, err = pcall(fn, db)
      if not ok then ns.Diag:Error("config:migrate:" .. label .. ":" .. v, err) end
    end
    db.schema = v
  end
  return true
end

local function validateSession(session)
  if session == nil then return true end
  if type(session) ~= "table" then return false end
  if type(session.saved) ~= "table" then return false end
  if session.route ~= nil and type(session.route) ~= "table" then return false end
  return true
end

-- Loads (or creates) both stores. Accepts whatever the client restored, including garbage.
function Config:Load(accountRaw, charRaw)
  local repairs = {}
  local account = type(accountRaw) == "table" and accountRaw or {}
  local char = type(charRaw) == "table" and charRaw or {}
  if accountRaw ~= nil and type(accountRaw) ~= "table" then repairs[#repairs + 1] = "FLC_DB was " .. type(accountRaw) end
  if charRaw ~= nil and type(charRaw) ~= "table" then repairs[#repairs + 1] = "FLC_CharDB was " .. type(charRaw) end

  -- an account that already had FLC settings (an earlier version) is not a first start
  local existing = type(account.settings) == "table" and next(account.settings) ~= nil
  migrate(account, self.accountMigrations, "account")
  migrate(char, self.charMigrations, "char")
  reconcile(account, self.accountDefaults, "FLC_DB", repairs)
  reconcile(char, self.charDefaults, "FLC_CharDB", repairs)
  -- First Run Setup (UI/SetupFrame.lua): "pending" on a new install, "migrated" for a player of an earlier version
  -- (never shown by itself); then "adapted", "manual" or "skipped". `offered`: the player closed it or chose.
  local setup = account.settings.setup
  if type(setup) ~= "table" or not self.SETUP_STATES[setup.state] then
    account.settings.setup = { state = existing and "migrated" or "pending" }
  end

  if not U.contains(self.ANNOUNCE_MODES, account.settings.announce.mode) then
    repairs[#repairs + 1] = "announce.mode " .. tostring(account.settings.announce.mode)
    account.settings.announce.mode = "default"
  end
  if not U.contains(self.PRESETS, account.settings.party.preset) then
    repairs[#repairs + 1] = "party.preset " .. tostring(account.settings.party.preset)
    account.settings.party.preset = "balanced"
  end
  if not validateSession(char.session) then
    -- Keep the broken session for inspection, but never lose the saved personal cursor if present.
    repairs[#repairs + 1] = "session invalid"
    char._brokenSession = char.session
    if type(char.session) == "table" and type(char.session.saved) == "table" then
      char.personal = U.deepcopy(char.session.saved)
    end
    char.session = nil
  end

  for _, r in ipairs(repairs) do ns.Diag:Warn("config", "repaired " .. r) end
  self.account, self.char, self.repairs = account, char, repairs
  self.settings = account.settings
  ns.Diag:Attach(account.diag)
  return account, char, repairs
end

function Config:Get(path)
  local node = self.settings
  for _, part in ipairs(U.split(path, ".")) do
    if type(node) ~= "table" then return nil end
    node = node[part]
  end
  return node
end

function Config:Set(path, value)
  local parts = U.split(path, ".")
  local node = self.settings
  for i = 1, #parts - 1 do
    node[parts[i]] = node[parts[i]] or {}
    node = node[parts[i]]
  end
  node[parts[#parts]] = value
  ns.Bus:Fire("CONFIG_CHANGED", path, value)
end
