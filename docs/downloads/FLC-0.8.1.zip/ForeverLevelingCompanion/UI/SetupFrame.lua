-- First Run Setup (docs/ADAPTIVE_UI.md): a welcome window, once, on a new install: Adapt to my interface (a preview
-- first), Configure it myself (the Appearance window) or Skip for now (FLC's own look). Only FLC's look changes, never
-- the other interface or any other addon. Opened again any time with /flc setup or from Options and Appearance.
local _, ns = ...
local W, L = ns.W, ns.L
local UI = ns.UI
local A = ns.Appearance

UI.SETUP_SKINS = { "blizzlike", "elvuilike", "minimal", "fantasy" }
-- seconds after entering the world, between tries while the moment is not right, and how many tries in a session
UI.SETUP_DELAY, UI.SETUP_RETRY, UI.SETUP_TRIES = 4, 5, 60

local function store() return ns.Config.settings.setup end

-- an interface FLC has an adapter for (not Blizzard's own look, not an unknown replacement)
local function known(det) return det and det.id ~= "blizzard" and det.id ~= "other" and A.ADAPTERS[det.id] and true or false end

function UI:SetupState() return store().state end

function UI:SetupFinish(state)
  local s = store()
  s.state, s.offered = state, true
  if self.setup then self.setup:Hide() end
end

-- Adapt to my interface: a known interface is previewed at once; otherwise the four skins are offered
function UI:SetupAdapt()
  local det = ns.API.DetectInterface()
  self.setupDetected, self.appearanceDetected = det, det
  self.setupMode = "adapt"
  if known(det) then
    self:AppearancePreview(A.Adapt(det))
    self.setupPreview = det.name
  end
  if self.main and not self.main:IsShown() then self.main:Show() end   -- the preview is seen on FLC's own window
  self:RefreshSetup()
end

function UI:SetupSkin(id)
  if not A.THEMES[id] then return end
  self:AppearancePreview({ base = id, overrides = {}, source = "built-in" })
  self.setupPreview = A.THEMES[id].name
  self:RefreshSetup()
end

function UI:SetupApply()
  if not self.appearanceDraft then return end
  self:AppearanceSave()
  self:SetupFinish("adapted")
  ns.API.Print(L["FLC's look is saved. Change it any time with /flc appearance"])
end

function UI:SetupManual()
  self:AppearanceCancel()
  self:SetupFinish("manual")
  self:ShowAppearance()
end

function UI:SetupSkip()
  self:AppearanceCancel()   -- back to the saved look: FLC's own on a new install
  self:SetupFinish("skipped")
  ns.API.Print(L["FLC keeps its own look. /flc setup opens the welcome setup again"])
end

-- Closed without a choice: the preview goes back and the setup stays pending (it does not open by itself again)
function UI:SetupClose()
  self:AppearanceCancel()
  local s = store()
  s.offered = true
  if self.setup then self.setup:Hide() end
  if s.state == "pending" then ns.API.Print(L["The welcome setup is still there: /flc setup or Options -> Appearance"]) end
end

function UI:BuildSetup()
  local f = W.Panel("FLC_SetupFrame", nil, 340, 10)
  self.setup = f
  W.Dialog(f)
  W.Movable(f, "setup", { "CENTER", "CENTER", 0, 60 })
  f.title = W.Text(f, 14, W.C.ember)
  f.title:SetPoint("TOPLEFT", 8, -8)
  f.title:SetText(L["Welcome to Forever Leveling Companion"])
  f.close = W.Button(f, "x", 18, 16, function() UI:SetupClose() end)
  f.close:SetPoint("TOPRIGHT", -4, -4)
  f.intro = W.Text(f, 11, W.C.text)
  f.intro:SetPoint("TOPLEFT", 8, -30)
  f.intro:SetWidth(324)
  f.intro:SetText(L["Make FLC match your interface. Only FLC's windows change: your interface and other addons stay as they are."])
  f.detected = W.Text(f, 11, W.C.muted)
  f.detected:SetPoint("TOPLEFT", 8, -64)
  f.detected:SetWidth(324)
  local y = -84
  f.adapt = W.Button(f, L["Adapt to my interface"], 324, 20, function() UI:SetupAdapt() end, W.C.teal)
  f.adapt:SetPoint("TOPLEFT", 8, y)
  f.manual = W.Button(f, L["Configure it myself"], 324, 20, function() UI:SetupManual() end)
  f.manual:SetPoint("TOPLEFT", 8, y - 23)
  f.skip = W.Button(f, L["Skip for now"], 324, 20, function() UI:SetupSkip() end)
  f.skip:SetPoint("TOPLEFT", 8, y - 46)
  f.skinsLabel = W.Text(f, 11, W.C.muted)
  f.skinsLabel:SetPoint("TOPLEFT", 8, y - 76)
  f.skins = {}
  for i, id in ipairs(UI.SETUP_SKINS) do
    local b = W.Button(f, A.THEMES[id].name, 160, 18, function() UI:SetupSkin(id) end)
    b:SetPoint("TOPLEFT", 8 + ((i - 1) % 2) * 164, y - 94 - math.floor((i - 1) / 2) * 21)
    b.key = id
    f.skins[i] = b
  end
  f.preview = W.Text(f, 11, W.C.warn)
  f.preview:SetPoint("TOPLEFT", 8, y - 144)
  f.preview:SetWidth(324)
  f.apply = W.Button(f, L["Apply"], 100, 20, function() UI:SetupApply() end, W.C.ok)
  f.apply:SetPoint("TOPLEFT", 8, y - 166)
  f.perchar = W.Button(f, "", 216, 20, function()
    ns.Appearance:SetPerCharacter(not ns.Config.char.appearance.perCharacter)
    UI:RefreshSetup()
  end)
  -- the skins, the preview and Apply only once Adapt is chosen: until then the window is compact
  f.baseY, f.fullHeight, f.compactHeight = y, -(y - 166) + 30, -(y - 76) + 30
  f:Hide()
end

function UI:RefreshSetup()
  local f = self.setup
  if not f then return end
  local det = self.setupDetected
  if known(det) then
    f.detected:SetText(L["Your interface"] .. ": " .. det.name .. (det.version and (" " .. det.version) or ""))
  elseif det and det.id == "other" then
    f.detected:SetText(L["Your interface"] .. ": " .. det.name .. " - " .. L["FLC has no adapter for it: pick a skin"])
  else
    f.detected:SetText(L["No other interface found: Adapt offers FLC's skins"])
  end
  local adapting = self.setupMode == "adapt"
  f.perchar:ClearAllPoints()
  if adapting then
    f.perchar:SetPoint("LEFT", f.apply, "RIGHT", 8, 0)
    f:SetHeight(f.fullHeight)
  else
    f.perchar:SetPoint("TOPLEFT", 116, f.baseY - 76)
    f:SetHeight(f.compactHeight)
  end
  for _, b in ipairs(f.skins) do if adapting then b:Show() else b:Hide() end end
  if adapting then
    f.skinsLabel:SetText(known(det) and L["Or one of FLC's skins:"] or L["Pick a skin to preview it:"])
    f.skinsLabel:Show()
  else
    f.skinsLabel:Hide()
  end
  if self.setupPreview and self.appearanceDraft then
    f.preview:SetText(string.format(L["Preview: %s. Apply keeps it."], self.setupPreview))
    f.apply:Show()
  else
    f.preview:SetText("")
    f.apply:Hide()
  end
  f.perchar:SetLabel(L["Only for this character"] .. ": "
    .. ((ns.Config.char.appearance.perCharacter and L["on"]) or L["off"]))
end

function UI:ShowSetup()
  if not self.setup then self:BuildSetup() end
  self.setupMode, self.setupPreview = nil, nil
  self.setupDetected = ns.API.DetectInterface()
  if self.appearance and self.appearance:IsShown() then self.appearance:Hide() end
  self.setup:Show()
  self:RefreshSetup()
end

-- Is something on screen that the welcome window must not open over? (FLC's own dialogs count too)
function UI:SetupBusy()
  local busy = ns.API.ScreenBusy()
  if busy then return busy end
  for _, key in ipairs({ "appearance", "report", "atlas" }) do
    local fr = self[key]
    if type(fr) == "table" and fr.IsShown and fr:IsShown() then return key end
  end
  return nil
end

-- After entering the world: on a new install, at a calm moment (not in combat, a cinematic or under another window);
-- tries again a few seconds later meanwhile. Once the player closes it or chooses, it never opens by itself again; an
-- earlier version's player never sees it by itself.
function UI:SetupOnWorld()
  local s = store()
  if self.setupScheduled or s.state ~= "pending" or s.offered then return end
  self.setupScheduled = true
  local timer = ns.env.C_Timer
  local tries = 0
  local function try()
    tries = tries + 1
    local st = store()
    if st.state ~= "pending" or st.offered then return end
    local busy = UI:SetupBusy()
    if busy then
      UI.setupWaiting = busy
      if tries < UI.SETUP_TRIES and timer and timer.After then timer.After(UI.SETUP_RETRY, try) end
      return
    end
    UI.setupWaiting = nil
    -- `offered` is kept only when the player closes it or chooses: left open across a /reload or a logout, it comes
    -- back once more at the next entry into the world
    UI:ShowSetup()
  end
  if timer and timer.After then timer.After(UI.SETUP_DELAY, try) else try() end
end
