-- Appearance window (Options -> Appearance, /flc appearance): Adapt to my interface -> Preview -> Apply.
-- Every change is a live preview of FLC's own windows; nothing is kept until Apply. Cancel goes back to the saved look,
-- Restore to the one before it. Nothing of the other interface is changed.
local _, ns = ...
local W, L = ns.W, ns.L
local UI = ns.UI
local A = ns.Appearance

-- Choices of the manual assistant (cycled with one button each)
UI.APPEARANCE_ACCENTS = {
  { L["Gold"], { 1.00, 0.82, 0.00 } }, { L["Ember"], { 0.965, 0.616, 0.235 } }, { L["Blue"], { 0.09, 0.52, 0.82 } },
  { L["Teal"], { 0.247, 0.780, 0.737 } }, { L["Green"], { 0.42, 0.85, 0.47 } }, { L["Purple"], { 0.64, 0.45, 0.90 } },
  { L["Class color"], "class" },
}
UI.APPEARANCE_FONTS = {
  { L["Game font"], nil }, { "Friz Quadrata", "Fonts\\FRIZQT__.TTF" }, { "Arial Narrow", "Fonts\\ARIALN.TTF" },
  { "Morpheus", "Fonts\\MORPHEUS.TTF" }, { "Skurri", "Fonts\\SKURRI.TTF" },
}
UI.APPEARANCE_OPACITY = { 0.45, 0.65, 0.80, 0.90, 0.97 }
UI.APPEARANCE_TEXT = { 0.85, 1.0, 1.15, 1.3 }
UI.APPEARANCE_SCALE = { 0.8, 0.9, 1.0, 1.1, 1.25 }
UI.APPEARANCE_EDGES = { "line", "tooltip", "none" }
UI.APPEARANCE_EDGE_LABEL = { line = "Thin lines", tooltip = "Blizzard style", none = "No borders" }

local function nextIn(list, cur, eq)
  for i, v in ipairs(list) do
    if (eq and eq(v, cur)) or v == cur then return list[i % #list + 1] end
  end
  return list[1]
end

function UI:AppearanceApply(theme)
  W.ApplyTheme(theme)
  if self.Refresh then self:Refresh() end
end

-- The profile being previewed (a copy; the saved one changes only on Apply)
function UI:AppearanceDraft()
  if not self.appearanceDraft then self.appearanceDraft = ns.U.deepcopy(A:Profile()) end
  self.appearanceDraft.overrides = self.appearanceDraft.overrides or {}
  return self.appearanceDraft
end

function UI:AppearancePreview(profile)
  self.appearanceDraft = profile
  self:AppearanceApply(A.Resolve(profile))
  self:RefreshAppearance()
end

function UI:AppearanceOverride(key, value)
  local d = self:AppearanceDraft()
  d.overrides[key] = value
  d.source = "manual"
  self:AppearancePreview(d)
end

function UI:AppearanceColor(role, rgb)
  local d = self:AppearanceDraft()
  d.overrides.colors = d.overrides.colors or {}
  d.overrides.colors[role] = rgb
  d.source = "manual"
  self:AppearancePreview(d)
end

function UI:AppearanceAdapt()
  local det = ns.API.DetectInterface()
  self.appearanceDetected = det
  self:AppearancePreview(A.Adapt(det))
end

function UI:AppearanceSave()
  local saved = A:Save(self:AppearanceDraft())
  if self.appearanceDetected then A:Remember(self.appearanceDetected) end
  self.appearanceDraft = nil
  self:AppearanceApply(A.Resolve(saved))
  self:RefreshAppearance()
end

function UI:AppearanceCancel()
  self.appearanceDraft = nil
  self:AppearanceApply(A.Resolve(A:Profile()))
  self:RefreshAppearance()
end

function UI:AppearanceRestore()
  self.appearanceDraft = nil
  if A:Restore() then self:AppearanceApply(A.Resolve(A:Profile())) end
  self:RefreshAppearance()
end

-- "Take the style of a window": five seconds to point at it, then its backdrop colours are read (when it has one)
function UI:AppearancePick()
  local timer = ns.env.C_Timer
  if not (timer and timer.After) then return end
  self.appearancePickNote = L["Point at a window: its style is read in 5 seconds"]
  self:RefreshAppearance()
  timer.After(5, function()
    local st = ns.API.StyleUnderMouse()
    if st then
      local d = self:AppearanceDraft()
      d.overrides.colors = d.overrides.colors or {}
      d.overrides.colors.bg = st.bg
      d.overrides.colors.panel = { st.bg[1], st.bg[2], st.bg[3], math.min(1, (st.bg[4] or 1) + 0.05) }
      if st.border then d.overrides.colors.line = st.border end
      d.source = "manual"
      self.appearancePickNote = string.format(L["Style taken from %s"], st.name or L["that window"])
      self:AppearancePreview(d)
    else
      self.appearancePickNote = L["That window has no readable style: pick the colours below"]
      self:RefreshAppearance()
    end
  end)
end

function UI:BuildAppearance()
  local f = W.Panel("FLC_AppearanceFrame", nil, 300, 10)
  self.appearance = f
  W.Dialog(f)
  W.Movable(f, "appearance", { "CENTER", "CENTER", 0, 40 })
  f.title = W.Text(f, 13, W.C.ember)
  f.title:SetPoint("TOPLEFT", 8, -8)
  f.title:SetText(L["Appearance"])
  f.close = W.Button(f, "x", 18, 16, function() UI:AppearanceCancel(); f:Hide() end)
  f.close:SetPoint("TOPRIGHT", -4, -4)
  f.detected = W.Text(f, 11, W.C.muted)
  f.detected:SetPoint("TOPLEFT", 8, -28)
  f.detected:SetPoint("RIGHT", f, "RIGHT", -8, 0)
  f.state = W.Text(f, 11, W.C.text)
  f.state:SetPoint("TOPLEFT", f.detected, "BOTTOMLEFT", 0, -4)
  f.state:SetPoint("RIGHT", f, "RIGHT", -8, 0)

  local d = function() return UI:AppearanceDraft() end
  local function theme() return A.Resolve(d()) end
  f.rows = {
    { function() return L["Adapt to my interface"] end, function() UI:AppearanceAdapt() end, "adapt" },
    { function() return L["Skin"] .. ": " .. (A.THEMES[d().base] or A.THEMES.flc).name end, function()
        local p = d()
        p.base = nextIn(A.ORDER, p.base or "flc")
        p.overrides, p.source = {}, "built-in"
        UI:AppearancePreview(p)
      end, "skin" },
    { function() return L["Accent"] end, function()
        UI.appearanceAccent = nextIn(UI.APPEARANCE_ACCENTS, UI.appearanceAccent, function(a, b) return b and a[1] == b[1] end)
        local rgb = UI.appearanceAccent[2]
        if rgb == "class" then
          local cl = W.ClassColor(ns.API.GetPlayerInfo().class)
          rgb = { cl[1], cl[2], cl[3] }
        end
        UI:AppearanceColor("ember", { rgb[1], rgb[2], rgb[3], 1 })
      end, "accent" },
    { function() return L["Background opacity"] .. ": " .. string.format("%d%%", (theme().colors.bg[4] or 1) * 100) end, function()
        local bg = theme().colors.bg
        local a = nextIn(UI.APPEARANCE_OPACITY, bg[4], function(x, y) return y and math.abs(x - y) < 0.01 end)
        UI:AppearanceColor("bg", { bg[1], bg[2], bg[3], a })
      end, "opacity" },
    { function()
        for _, fo in ipairs(UI.APPEARANCE_FONTS) do if fo[2] == theme().font then return L["Font"] .. ": " .. fo[1] end end
        return L["Font"] .. ": " .. tostring(theme().font)
      end, function()
        local cur = theme().font
        local list = UI.APPEARANCE_FONTS
        local det = UI.appearanceDetected
        if det and det.media and det.media.font and A.Media(det.media.font) then
          list = { unpack(UI.APPEARANCE_FONTS) }
          list[#list + 1] = { det.name, det.media.font }
        end
        local nxt = nextIn(list, cur, function(a, b) return a[2] == b end)
        UI:AppearanceOverride("font", nxt[2])
      end, "font" },
    { function() return L["Text size"] .. ": " .. string.format("%d%%", theme().fontScale * 100) end, function()
        UI:AppearanceOverride("fontScale", nextIn(UI.APPEARANCE_TEXT, theme().fontScale,
          function(x, y) return math.abs(x - y) < 0.01 end))
      end, "text" },
    { function() return L["Window scale"] .. ": " .. string.format("%d%%", theme().scale * 100) end, function()
        UI:AppearanceOverride("scale", nextIn(UI.APPEARANCE_SCALE, theme().scale,
          function(x, y) return math.abs(x - y) < 0.01 end))
      end, "scale" },
    { function() return L["Borders"] .. ": " .. L[UI.APPEARANCE_EDGE_LABEL[theme().edge]] end, function()
        UI:AppearanceOverride("edge", nextIn(UI.APPEARANCE_EDGES, theme().edge))
      end, "edge" },
    { function() return L["Take the style of a window"] end, function() UI:AppearancePick() end, "pick" },
    { function()
        return L["Per character"] .. ": " .. ((ns.Config.char.appearance.perCharacter and L["on"]) or L["off"])
      end, function()
        A:SetPerCharacter(not ns.Config.char.appearance.perCharacter)
        UI.appearanceDraft = nil
        UI:AppearanceApply(A.Resolve(A:Profile()))
        UI:RefreshAppearance()
      end, "perchar" },
    { function() return L["Export"] end, function() UI:ShowReport(A.Export(d())) end, "export" },
    { function() return L["Import"] end, function() UI:ShowAppearanceImport() end, "import" },
    { function() return L["Welcome setup"] .. "..." end, function() UI:AppearanceCancel(); UI:ShowSetup() end, "setup" },
  }
  f.buttons = {}
  local y = -64
  for i, row in ipairs(f.rows) do
    local b = W.Button(f, "", 284, 18, row[2])
    b:SetPoint("TOPLEFT", 8, y - (i - 1) * 21)
    b.key = row[3]
    f.buttons[i] = b
    f.buttons[row[3]] = b
  end
  local by = y - #f.rows * 21 - 6
  f.apply = W.Button(f, L["Apply"], 90, 20, function() UI:AppearanceSave() end, W.C.ok)
  f.apply:SetPoint("TOPLEFT", 8, by)
  f.cancel = W.Button(f, L["Cancel"], 90, 20, function() UI:AppearanceCancel() end, W.C.ember)
  f.cancel:SetPoint("LEFT", f.apply, "RIGHT", 7, 0)
  f.restore = W.Button(f, L["Restore previous"], 90, 20, function() UI:AppearanceRestore() end, W.C.teal)
  f.restore:SetPoint("LEFT", f.cancel, "RIGHT", 7, 0)
  f:SetHeight(-by + 30)
  f:Hide()
end

function UI:ShowAppearanceImport()
  self:ShowReport("")
  local r = self.report
  r.hint:SetText(L["Paste an FLC appearance line, then press Enter"])
  r.edit:SetScript("OnEnterPressed", function(edit)
    local profile, err = A.Import(edit:GetText() or "")
    if profile then
      r:Hide()
      UI:AppearancePreview(profile)
    else
      r.hint:SetText(L["Not an FLC appearance line"] .. " (" .. tostring(err) .. ")")
    end
  end)
end

function UI:RefreshAppearance()
  local f = self.appearance
  if not f then return end
  local det = self.appearanceDetected
  if det then
    f.detected:SetText(L["Your interface"] .. ": " .. det.name .. (det.version and (" " .. det.version) or "")
      .. ((det.id == "other") and (" - " .. L["no adapter: choose a skin or pick the colours"]) or ""))
  else
    f.detected:SetText(L["Your interface"] .. ": " .. L["press Adapt to my interface"])
  end
  local saved = A:Profile()
  local previewing = self.appearanceDraft and A.Export(self.appearanceDraft) ~= A.Export(saved)
  f.state:SetText((self.appearancePickNote and (self.appearancePickNote .. "\n") or "")
    .. (previewing and W.Colorize(L["Preview: Apply keeps it, Cancel goes back"], W.C.warn) or L["Saved look in use"]))
  for _, b in ipairs(f.buttons) do
    for _, row in ipairs(f.rows) do if row[3] == b.key then b:SetLabel(row[1]()) end end
  end
end

function UI:ShowAppearance()
  if not self.appearance then self:BuildAppearance() end
  self.appearanceDetected = self.appearanceDetected or ns.API.DetectInterface()
  self.appearance:Show()
  self:RefreshAppearance()
end

-- At login: the saved look, and once, when the other interface changed since FLC adapted to it, the offer to adapt again
function UI:AppearanceLogin()
  local profile = A:Profile()
  if profile.base ~= "flc" or next(A.Sanitize(profile.overrides)) then W.ApplyTheme(A.Resolve(profile)) end
  local det = ns.API.DetectInterface()
  self.appearanceDetected = det
  if A:Changed(det) then
    ns.API.Print(string.format(L["%s looks different since FLC adapted to it: /flc appearance to adapt again"], det.name))
    A:Remember(det)   -- offered once per change
  end
end
