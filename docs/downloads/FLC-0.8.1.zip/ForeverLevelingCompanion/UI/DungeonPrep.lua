-- Dungeon preparation window (Engine/DungeonAdvisor.lua): why the dungeon, quests to pick up first (giver), quests in
-- the log, quests not open yet (and why), the entrance; Waypoint to the next place, the game's group finder, back to the
-- route. Nothing here searches for a group or plays for the player.
local _, ns = ...
local W, L = ns.W, ns.L
local UI = ns.UI
local DA = ns.DungeonAdvisor

local WIDTH = 400

-- The reasons of an evaluation as short sentences.
function UI.DungeonReasons(ev)
  local out = {}
  for _, code in ipairs(ev.reasons or {}) do
    if code == "pending" then
      out[#out + 1] = ev.pending == 1 and L["1 quest to do"] or string.format(L["%d quests to do"], ev.pending)
    elseif code == "first-visit" then
      out[#out + 1] = L["first visit"]
    elseif code == "xp-forever" or code == "xp-range" then
      local t = UI.DungeonXPText(ev)
      if t then
        out[#out + 1] = t .. " " .. (code == "xp-forever" and L["(Forever values, in review)"]
          or L["(normal quest XP up to the Forever bonus seen on other dungeon quests: not confirmed)"])
      end
    elseif code == "class-quest" and ev.classChain then
      out[#out + 1] = string.format(L["class quest: %s"], ev.classChain.title or "?")
    elseif code == "wishlist" then
      out[#out + 1] = string.format(L["%d of your wishlist"], #ev.wishlist)
    elseif code == "not-yet" then
      out[#out + 1] = string.format(L["%d not open yet"], #ev.notYet)
    end
  end
  if ev.xpUnknown > 0 then out[#out + 1] = string.format(L["%d without XP data"], ev.xpUnknown) end
  return out
end

-- Why a quest is not open yet, for the player.
function UI.DungeonBlocked(s, subject)
  local why = s.why or ""
  local prereq = string.match(why, "^prereq:(%d+)$")
  if prereq then
    return string.format(L["first: %s"], ns.Quest:Name(tonumber(prereq), subject) or ("#" .. prereq))
  end
  local active = string.match(why, "^requires%-active:(%d+)$")
  if active then
    return string.format(L["needs %s in your log"], ns.Quest:Name(tonumber(active), subject) or ("#" .. active))
  end
  if why == "level" then
    local m = ns.Quest.meta[s.quest]
    return string.format(L["from level %d"], m and m.minLevel or 0)
  end
  if why == "prereq-any" then return L["needs an earlier quest of its chain"] end
  return L["not known to be open"]
end

-- "Robe of Evocation (Jergosh the Invoker): better than yours, likely" for the Loot Advisor's upgrades (estimate).
function UI.LootLine(u)
  local name = ns.LootAtlas and ns.LootAtlas:Name(u.id, u.rec) or u.rec.n or ("#" .. u.id)
  local conf = u.confidence == "likely" and L["likely better"] or L["close: compare it when it drops"]
  local when = u.soon > 0 and (" " .. string.format(L["(in %d levels)"], u.soon)) or ""
  local boss = ns.LootAtlas and ns.LootAtlas:BossName({ name = u.boss or "?", npc = u.npc }) or u.boss or "?"
  return string.format("- %s (%s): %s%s", name, boss, conf, when)
end

-- "- Slaying the Beast: has it: Zug · can take it: Grok (share it if the game allows) · first Altered Beings: Mok ·
-- done: Lia · progress unknown: Rak"
function UI.PartyQuestLine(r, subject)
  local parts = {}
  if #r.inLog > 0 then parts[#parts + 1] = L["has it"] .. ": " .. table.concat(r.inLog, ", ") end
  if #r.canTake > 0 then
    parts[#parts + 1] = L["can take it"] .. ": " .. table.concat(r.canTake, ", ")
      .. (r.share and (" " .. L["(share it if the game allows)"]) or "")
  end
  for _, n in ipairs(r.needs) do
    parts[#parts + 1] = UI.DungeonBlocked({ why = n.why, quest = r.id }, subject) .. ": " .. n.name
  end
  if #r.done > 0 then parts[#parts + 1] = L["done"] .. ": " .. table.concat(r.done, ", ") end
  if #r.unknown > 0 then parts[#parts + 1] = L["progress unknown"] .. ": " .. table.concat(r.unknown, ", ") end
  return string.format("- %s: %s", ns.Quest:Name(r.id, subject) or ("#" .. r.id), table.concat(parts, " · "))
end

-- The window's lines for a plan.
function UI.DungeonPrepLines(plan, subject)
  local lines, ev = {}, plan.ev
  local why = UI.DungeonReasons(ev)
  if #why > 0 then lines[#lines + 1] = L["Why"] .. ": " .. table.concat(why, " · ") end
  local sections = { pickup = {}, inside = {}, carry = {}, blocked = {}, entrance = {} }
  for _, s in ipairs(plan.steps) do
    local name = s.quest and (ns.Quest:Name(s.quest, subject) or ("#" .. s.quest))
    if s.kind == "pickup" then
      sections.pickup[#sections.pickup + 1] = string.format("- %s (%s)", name, s.giver or "?")
    elseif s.kind == "inside" then
      sections.inside[#sections.inside + 1] = "- " .. name
    elseif s.kind == "carry" then
      sections.carry[#sections.carry + 1] = "- " .. name .. (s.ready and (" " .. W.Colorize(L["ready to turn in"], W.C.ok)) or "")
    elseif s.kind == "blocked" then
      sections.blocked[#sections.blocked + 1] = string.format("- %s: %s", name, UI.DungeonBlocked(s, subject))
    elseif s.kind == "entrance" then
      sections.entrance[#sections.entrance + 1] = L["Entrance: use Waypoint once the quests are picked up"]
    end
  end
  local function section(title, list, color)
    if #list == 0 then return end
    lines[#lines + 1] = W.Colorize(title, color)
    for _, l in ipairs(list) do lines[#lines + 1] = l end
  end
  section(L["Pick up first"], sections.pickup, W.C.ok)
  section(L["Started inside the dungeon (an NPC or an item there)"], sections.inside, W.C.ok)
  section(L["In your log"], sections.carry, W.C.teal)
  section(L["Not open yet"], sections.blocked, W.C.muted)
  section(L["Then"], sections.entrance, W.C.ember)
  -- the character's wishlist (Loot Atlas) here
  if #(ev.wishlist or {}) > 0 then
    lines[#lines + 1] = W.Colorize(L["Your wishlist here"], W.C.ember)
    for _, w in ipairs(ev.wishlist) do
      local where = w.src.boss or (w.src.kind == "quest" and (w.src.title or L["a quest"])) or L["world drop"]
      lines[#lines + 1] = string.format("- %s (%s)%s", ns.LootAtlas:Name(w.id, w.rec), where,
        w.state == "want" and "" or (" - " .. L["interested"]))
    end
  end
  -- the group (Party Mode): who has, can take or needs what before going in
  local members = ns.Session:GroupMembers()
  if #members > 1 then
    local rows = DA:PartyView(members, plan.dungeon)
    if #rows > 0 then
      lines[#lines + 1] = W.Colorize(L["Your party"], W.C.teal)
      for i, r in ipairs(rows) do
        if i > 6 then lines[#lines + 1] = string.format(L["... and %d more"], #rows - 6) break end
        lines[#lines + 1] = UI.PartyQuestLine(r, subject)
      end
    end
  end
  -- upgrades among the bosses' own items, for this character (Engine/LootAdvisor.lua: an estimate from stat weights)
  local gear, spec = UI:AdvisorInputs()
  local ups = ns.LootAdvisor:Upgrades(subject, gear, spec, plan.dungeon.id, 4)
  if #ups > 0 then
    lines[#lines + 1] = W.Colorize(L["Upgrades for you here (estimate from stat weights)"], W.C.ok)
    for _, u in ipairs(ups) do lines[#lines + 1] = UI.LootLine(u) end
  elseif not gear then
    lines[#lines + 1] = W.Colorize(L["Your equipment could not be read: no upgrade list"], W.C.muted)
  end
  lines[#lines + 1] = W.Colorize(L["Quest XP at your level (in review); kill XP is not counted. Group: the game's own group finder."],
    W.C.muted)
  return lines
end

function UI:BuildDungeonPrep()
  local f = W.Panel("FLC_DungeonPrepFrame", nil, WIDTH, 160)
  self.dungeonPrep = f
  W.Movable(f, "dungeonPrep", { "CENTER", "CENTER", 0, 60 })
  f.title = W.Text(f, 12, W.C.ok)
  f.title:SetPoint("TOPLEFT", 8, -7)
  f.close = W.Button(f, "x", 18, 16, function() f:Hide() end)
  f.close:SetPoint("TOPRIGHT", -4, -4)
  f.body = W.Text(f, 10, W.C.text)
  f.body:SetPoint("TOPLEFT", 8, -26)
  f.body:SetPoint("RIGHT", -8, 0)
  f.way = W.Button(f, L["Waypoint"], 70, 18, function() UI:DungeonWaypoint() end)
  f.group = W.Button(f, L["Group finder"], 86, 18, function() UI:DungeonGroup() end)
  f.route = W.Button(f, L["Back to route"], 96, 18, function() UI:DungeonEndPrep() end, W.C.ember)
  f.way:SetPoint("BOTTOMLEFT", 8, 6)
  f.group:SetPoint("LEFT", f.way, "RIGHT", 4, 0)
  f.route:SetPoint("LEFT", f.group, "RIGHT", 4, 0)
  f.guide = W.Button(f, L["Dungeon guide"], 96, 18, function() UI:StartDungeonGuide() end, W.C.ok)
  f.guide:SetPoint("LEFT", f.route, "RIGHT", 4, 0)
  f:Hide()
end

function UI:ShowDungeonPrep()
  if not self.dungeonPrep then self:BuildDungeonPrep() end
  self.dungeonPlanCache = nil
  self.dungeonPrep:Show()
  self:RefreshDungeonPrep()
end

function UI:RefreshDungeonPrep()
  local f = self.dungeonPrep
  if not f or not f:IsShown() then return end
  local plan = self:DungeonPlan()
  if not plan then f:Hide(); return end
  local subject = ns.Session.selfState
  f.title:SetText(string.format(L["%s: preparation"], L[plan.dungeon.name] or plan.dungeon.name))
  if ns.DungeonGuide:For(plan.dungeon.id) then f.guide:Show() else f.guide:Hide() end
  f.body:SetText(table.concat(UI.DungeonPrepLines(plan, subject), "\n"))
  local h = f.body.GetStringHeight and f.body:GetStringHeight()
  f:SetHeight(math.max(120, ((type(h) == "number" and h) or 100) + 60))
end
ns.Bus:On("DUNGEON_PREP_CHANGED", UI, function() UI:RefreshDungeonPrep() end)
ns.Bus:On("TRACKER_QUEST_ADDED", UI, function() UI.dungeonPlanCache = nil; UI:RefreshDungeonPrep() end)
ns.Bus:On("TRACKER_QUEST_TURNED_IN", UI, function() UI.dungeonPlanCache = nil; UI:RefreshDungeonPrep() end)
