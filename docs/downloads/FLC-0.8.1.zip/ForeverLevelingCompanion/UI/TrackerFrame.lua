-- Quest tracker: live objective counters from the client's quest log, plus synced party progress.
local _, ns = ...
local W, L, U = ns.W, ns.L, ns.U
local UI = ns.UI

local WIDTH = 260
local MAX_LINES = 40

UI.ANNOUNCE_LABELS = {
  off = "Announce: off",
  objectives = "Announce: objectives",
  pct25 = "Announce: every 25%",
  pct50 = "Announce: every 50%",
  every = "Announce: every update",
  default = "Announce: objectives + ready",
}

function UI:BuildTracker()
  local f = W.Panel("FLC_TrackerFrame", nil, WIDTH, 120)
  self.tracker = f
  -- By default right under the guide window: at the right edge it covered Blizzard's objective tracker, and to its
  -- left it covered the guide window (both seen in the automated client runs, 2026-10-24)
  if self.main then
    W.Movable(f, "tracker", { "TOPRIGHT", "BOTTOMRIGHT", 0, -10, relativeTo = self.main })
  else
    W.Movable(f, "tracker", { "RIGHT", "RIGHT", -40, 0 })
  end
  f.title = W.Text(f, 12, W.C.ember)
  f.title:SetPoint("TOPLEFT", 8, -7)
  f.title:SetText(L["Quests"])
  f.announce = W.Button(f, "", 150, 16, function() UI:CycleAnnounce() end, W.C.ember)
  f.announce:SetPoint("TOPRIGHT", -4, -4)
  f.lines = {}
  for i = 1, MAX_LINES do
    local fs = W.Text(f, 11, W.C.text)
    fs:SetWidth(WIDTH - 16)
    fs:SetWordWrap(false)
    fs:Hide()
    f.lines[i] = fs
  end
  if ns.Config:Get("ui.showTracker") then f:Show() else f:Hide() end
  self:ApplyBlizzardTracker()
end

function UI:CycleAnnounce()
  local list = ns.Config.ANNOUNCE_MODES
  local cur = ns.Config:Get("announce.mode")
  local idx = 1
  for i, m in ipairs(list) do if m == cur then idx = i end end
  ns.Config:Set("announce.mode", list[idx % #list + 1])
  self:Refresh()
end

local function objectiveLine(o)
  local text = o.text and o.text ~= "" and o.text or "?"
  if o.need and o.need > 1 then text = string.format("%s: %d/%d", text, o.have or 0, o.need) end
  if o.done then return W.Colorize(text, W.C.ok) .. " " .. W.CHECK end
  return W.Colorize(text, W.C.text)
end

-- Party progress for one objective: "Nico 4/10 · Gustavo ✓ · Ana ?"
local function partyLine(qid, idx)
  local parts = {}
  for _, m in ipairs(ns.Party:List()) do
    local st = m.state
    local q = st.log[qid]
    if q and q.objectives[idx] then
      local o = q.objectives[idx]
      parts[#parts + 1] = o.done and (W.Colorize(m.name, W.C.ok) .. " " .. W.CHECK) or string.format("%s %d/%d", m.name, o.have or 0, o.need or 0)
    elseif st:IsCompleted(qid) == true then
      parts[#parts + 1] = W.Colorize(m.name .. " " .. L["done"], W.C.muted)
    elseif st:IsOnQuest(qid) == true then
      parts[#parts + 1] = W.Colorize(m.name .. " ?", W.C.muted)
    end
  end
  if #parts == 0 then return nil end
  return "   " .. table.concat(parts, "  ·  ")
end

function UI:RefreshTracker()
  local f = self.tracker
  f.announce:SetLabel(L[UI.ANNOUNCE_LABELS[ns.Config:Get("announce.mode")] or "Announce"])
  local st = ns.Session.selfState
  local n = 0
  local function add(text)
    if n >= MAX_LINES then return end
    n = n + 1
    local fs = f.lines[n]
    fs:ClearAllPoints()
    fs:SetPoint("TOPLEFT", 8, -24 - (n - 1) * 14)
    fs:SetText(text)
    fs:Show()
  end
  if st then
    local ids = U.keys(st.log)
    for _, qid in ipairs(ids) do
      local q = st.log[qid]
      local title = q.title or ns.Quest:Name(qid)
      if q.complete then
        add(W.Colorize(title, W.C.ok) .. "  " .. W.Colorize(L["Ready to turn in"], W.C.ok))
      elseif q.failed then
        add(W.Colorize(title .. " (" .. L["failed"] .. ")", W.C.bad))
      else
        add(W.Colorize(title, W.C.ember))
      end
      if not q.complete then
        for idx, o in ipairs(q.objectives) do
          add("  " .. objectiveLine(o))
          local pl = partyLine(qid, idx)
          if pl then add(pl) end
        end
      end
    end
    if #ids == 0 then add(W.Colorize(L["No active quests"], W.C.muted)) end
  end
  for i = n + 1, MAX_LINES do f.lines[i]:Hide() end
  f:SetHeight(30 + n * 14)
end

-- The game's own quest tracker, hidden while FLC's is shown (ui.hideBlizzardTracker) and shown again when that is
-- turned off. Its quest item buttons are protected: nothing is hidden or shown in combat, it waits for the end of it.
UI.BLIZZARD_TRACKERS = { "ObjectiveTrackerFrame", "QuestWatchFrame", "WatchFrame" }
UI.blizzardHidden, UI.blizzardHooked = {}, {}

function UI:WantsBlizzardHidden()
  return ns.Config:Get("ui.hideBlizzardTracker") and ns.Config:Get("ui.showTracker") and true or false
end

function UI:ApplyBlizzardTracker()
  if ns.API.InCombat() then self.blizzardPending = true; return false end
  self.blizzardPending = nil
  local hide = self:WantsBlizzardHidden()
  for _, name in ipairs(UI.BLIZZARD_TRACKERS) do
    local f = ns.env[name]
    if type(f) == "table" and type(f.Hide) == "function" then
      if hide then
        -- the game shows it again on its own updates: hidden again then, outside combat
        if not self.blizzardHooked[name] and type(f.HookScript) == "function" then
          self.blizzardHooked[name] = true
          pcall(f.HookScript, f, "OnShow", function(fr)
            if UI:WantsBlizzardHidden() and not ns.API.InCombat() then fr:Hide() end
          end)
        end
        pcall(f.Hide, f)
        self.blizzardHidden[name] = true
      elseif self.blizzardHidden[name] then
        self.blizzardHidden[name] = nil
        pcall(f.Show, f)
      end
    end
  end
  return true
end

-- The recommended reward of a quest window, marked on its button (index nil: the mark goes away). The buttons are
-- the game's (QuestInfo); when this client names them otherwise only the chat line says it.
UI.REWARD_BUTTONS = { "QuestInfoRewardsFrameQuestInfoItem%d", "QuestRewardItem%d" }

function UI:MarkReward(index, why)
  local m = self.rewardMark
  if not index then
    if m then m:Hide() end
    return nil
  end
  local button
  for _, pattern in ipairs(UI.REWARD_BUTTONS) do
    button = button or ns.env[string.format(pattern, index)]
  end
  if type(button) ~= "table" then return nil end
  if not m then
    m = ns.env.CreateFrame("Frame", "FLC_RewardMark", ns.env.UIParent)
    m.edges = {}
    for i, p in ipairs({ { "TOPLEFT", "TOPRIGHT", true }, { "BOTTOMLEFT", "BOTTOMRIGHT", true },
        { "TOPLEFT", "BOTTOMLEFT" }, { "TOPRIGHT", "BOTTOMRIGHT" } }) do
      local t = m:CreateTexture(nil, "OVERLAY")
      t:SetPoint(p[1])
      t:SetPoint(p[2])
      if p[3] then t:SetHeight(2) else t:SetWidth(2) end
      m.edges[i] = t
    end
    m.label = W.Text(m, 10, W.C.ok, "RIGHT", "OVERLAY")
    m.label:SetPoint("TOPRIGHT", -4, -3)
    self.rewardMark = m
  end
  local c = why == "upgrade" and W.C.ok or W.C.ember
  for _, t in ipairs(m.edges) do t:SetColorTexture(c[1], c[2], c[3], 1) end
  m.label:SetText(why == "upgrade" and L["FLC: upgrade"] or L["FLC: sells best"])
  W.SetColor(m.label, c)
  m:SetParent(button)
  m:ClearAllPoints()
  m:SetAllPoints(button)
  m:SetFrameLevel((button.GetFrameLevel and button:GetFrameLevel() or 1) + 5)
  m:Show()
  m.index = index
  return m
end
