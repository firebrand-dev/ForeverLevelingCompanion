-- Boss card (Engine/BossGuide.lua): next to the main window, the next boss of a dungeon guide before the pull ("Next
-- boss: Taragaman the Hungerer") and the boss being fought during the fight ("Fighting: ..."), with More / Less for
-- the detailed lines and x to hide it until the next boss. What goes at the player's role is highlighted. Below the
-- abilities, the boss's own items that rate better for this character (the Loot Advisor's estimate) and Loot: the Loot
-- Atlas on this boss. Nothing here waits, times or plays.
local _, ns = ...
local W, L = ns.W, ns.L
local UI = ns.UI
local BG = ns.BossGuide

local WIDTH = 300

UI.ROLE_WORDS = { TANK = "Tank", HEALER = "Healer", DAMAGER = "Damage" }
function UI.MarkOwn(text) return W.Colorize(text, W.C.warn) end

function UI:BuildBossCard()
  local f = W.Panel("FLC_BossCard", nil, WIDTH, 80)
  self.bossCard = f
  W.Movable(f, "bossCard", { "TOPRIGHT", "TOPRIGHT", -260, -180 })
  f.title = W.Text(f, 12, W.C.ember)
  f.title:SetPoint("TOPLEFT", 8, -7)
  f.title:SetPoint("RIGHT", -96, 0)
  f.title:SetWordWrap(false)
  f.close = W.Button(f, "x", 18, 16, function()
    UI.bossCardHidden = f.encounter
    f:Hide()
  end)
  f.close:SetPoint("TOPRIGHT", -4, -4)
  f.more = W.Button(f, L["More"], 22, 16, function()
    UI.bossCardDetailed = not UI.bossCardDetailed
    UI:RefreshBossCard()
  end)
  f.more:SetPoint("RIGHT", f.close, "LEFT", -2, 0)
  f.loot = W.Button(f, L["Loot"], 44, 16, function()
    local b = ns.LootAdvisor:Boss(f.encounter)
    if b then UI:ShowLootAtlasAt(b.dungeon, f.encounter) end
  end)
  f.loot:SetPoint("RIGHT", f.more, "LEFT", -2, 0)
  f.body = W.Text(f, 10, W.C.text)
  f.body:SetPoint("TOPLEFT", 8, -24)
  f.body:SetPoint("RIGHT", -8, 0)
  f:Hide()
end

-- Shown, refreshed or hidden from the main window's refresh.
function UI:RefreshBossCard(current)
  local card = BG:Card(current or ns.Session:Current())
  local f = self.bossCard
  if not card or (self.bossCardHidden and self.bossCardHidden == card.encounter and not card.fighting) then
    if f then f:Hide() end
    return
  end
  if not f then self:BuildBossCard(); f = self.bossCard end
  f.encounter = card.encounter
  if card.fighting then self.bossCardHidden = nil end
  local s = card.step
  local name = s and BG.Name(s) or L["Boss"]
  f.title:SetText(string.format(card.fighting and L["Fighting: %s"] or L["Next boss: %s"], name))
  local detailed = UI.bossCardDetailed or BG:Mode() == "detailed"
  f.more:SetLabel(detailed and L["Less"] or L["More"])
  -- what goes at the player's role is highlighted (from the data's targets; no role, nothing highlighted)
  local role = BG:Role()
  local lines, marked = { L["This boss is not in FLC's dungeon guides"] }, {}
  if s then lines, marked = BG.Lines(s, detailed, L, role, UI.MarkOwn) end
  if role and #marked > 0 then
    table.insert(lines, 1, W.Colorize(string.format(L["Highlighted for your role (%s)"], L[UI.ROLE_WORDS[role]]), W.C.warn))
  end
  f.role, f.marked = role, marked
  -- its loot for this character (an estimate from stat weights; nothing decides need or greed)
  local LA, subject = ns.LootAdvisor, ns.Session.selfState
  local boss = card.encounter and LA:Boss(card.encounter)
  if boss and subject then
    local gear, spec = self:AdvisorInputs()
    local ups = LA:Upgrades(subject, gear, spec, nil, 2, card.encounter)
    if #ups > 0 then
      lines[#lines + 1] = W.Colorize(L["Its loot for you (estimate):"], W.C.ember)
      for _, u in ipairs(ups) do lines[#lines + 1] = UI.LootLine(u) end
    end
  end
  if boss then f.loot:Show() else f.loot:Hide() end
  f.body:SetText(table.concat(lines, "\n"))
  local h = f.body.GetStringHeight and f.body:GetStringHeight()
  f:SetHeight(math.max(48, ((type(h) == "number" and h) or 40) + 32))
  f:Show()
end
