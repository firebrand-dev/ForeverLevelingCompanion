-- FLC Loot Atlas window (Engine/LootAtlas.lua, /flc atlas): two ways in. Dungeons: a dungeon, then a boss, its rare
-- world drops or its quest rewards, then the items. For me: a slot, then the items this character (or a class planned
-- for later) can use, rated by the Loot Advisor's scoring. A search box (item, boss or dungeon name), quality and
-- "usable by me" filters, the wishlist (each item's button: Want, Interested, Got, Hide) and a wishlist-only view.
-- A boss's page starts with its abilities (the Boss Guide's lines, Engine/BossGuide.lua), and Guide starts the guide
-- of the dungeon or raid shown: one window for a boss's fight, its loot and what of it suits the character.
-- Built with the shared widgets: the Adaptive UI skins restyle it.
local _, ns = ...
local W, L = ns.W, ns.L
local UI = ns.UI
local LT = ns.LootAtlas

local WIDTH, HEIGHT, LEFT_ROWS, ITEM_ROWS = 600, 440, 16, 10
UI.ATLAS_QUALITY_HEX = { [0] = "9d9d9d", "ffffff", "1eff00", "0070dd", "a335ee", "ff8000" }
UI.ATLAS_SLOTS = { "head", "neck", "shoulder", "back", "chest", "wrist", "hands", "waist", "legs", "feet", "finger",
  "trinket", "main-hand", "one-hand", "two-hand", "off-hand", "shield", "held-in-off-hand", "ranged" }
UI.ATLAS_CLASSES = { "WARRIOR", "PALADIN", "HUNTER", "ROGUE", "PRIEST", "SHAMAN", "MAGE", "WARLOCK", "DRUID" }
UI.ATLAS_WISH_LABEL = { want = "Want", interest = "Interested", got = "Got", hide = "Hidden" }

local function view()
  UI.atlasView = UI.atlasView or { tab = "dungeons", page = 0, usable = true, text = "" }
  return UI.atlasView
end

-- item names in the player's language from the client (the pack's English name until the client has loaded it)
LT.localName = function(id, noLoad) return ns.API.GetItemName(id, noLoad) end
-- boss names in the player's language from the pack (Catalog_BossNames.lua)
LT.localNpc = function(id) return ns.Quest:SourceName("npc", id) end

function UI.AtlasItemName(rec, id)
  return "|cff" .. (UI.ATLAS_QUALITY_HEX[rec.q or 1] or "ffffff") .. LT:Name(id, rec) .. "|r"
end

-- "chest · cloth · level 13 · Jergosh the Invoker (Ragefire Chasm)"
-- A slot, weapon or armour id as words: the locale's, else the id made readable ("sword-1h" -> "one-handed sword",
-- "held-in-off-hand" -> "held in off hand")
function UI.AtlasLabel(id)
  local t = L[id]
  if t and t ~= id then return t end
  local base, hands = string.match(id, "^(%a+)%-([12])h$")
  if base then return (hands == "1" and "one-handed " or "two-handed ") .. base end
  return (string.gsub(id, "%-", " "))
end

function UI.AtlasItemLine(id, rec)
  local parts = { UI.AtlasLabel(rec.slot) }
  if rec.w then parts[#parts + 1] = UI.AtlasLabel(rec.w) elseif rec.a then parts[#parts + 1] = UI.AtlasLabel(rec.a) end
  if rec.dps then parts[#parts + 1] = string.format(L["%.1f DPS"], rec.dps) end
  if (rec.rl or 0) > 0 then parts[#parts + 1] = string.format(L["level %d"], rec.rl) end
  local src = LT:Sources(id)[1]
  if src then
    local inst = LT:Data().instances[src.instance]
    local where = src.boss or (src.kind == "quest" and (src.title or L["a quest"])) or L["world drop"]
    parts[#parts + 1] = string.format("%s (%s)", where, inst and (L[inst.name] or inst.name) or "?")
  end
  return table.concat(parts, " · ")
end

-- A boss's page: "Abilities" and the Boss Guide's basic lines for that encounter (the player's role's own highlighted) (at most ATLAS_ABILITY_LINES), or nil
-- on any other page or for a boss in no guide.
UI.ATLAS_ABILITY_LINES = 8
function UI.AtlasAbilityLines(v)
  if v.tab ~= "dungeons" or type(v.boss) ~= "number" then return nil end
  local step = ns.BossGuide:StepFor(v.boss)
  if not step then return nil end
  local lines = { W.Colorize(L["Abilities"], W.C.ember) }
  local all = ns.BossGuide.Lines(step, false, L, ns.BossGuide:Role(), UI.MarkOwn)
  for i, l in ipairs(all) do
    if i > UI.ATLAS_ABILITY_LINES then lines[#lines] = lines[#lines] .. " ..." break end
    lines[#lines + 1] = l
  end
  return lines
end

-- What the right column lists now: { { id, rec, verdict, confidence } }.
function UI:AtlasItems()
  local v, subject = view(), ns.Session.selfState
  local q = { text = v.text, minQuality = v.minQuality, wish = v.wishOnly and "any" or nil }
  if v.usable and subject and v.tab == "dungeons" then q.class, q.level = subject.class, (subject.level or 1) + 3 end
  if v.tab == "dungeons" then
    if v.boss == "world" or v.boss == "quest" then
      local inst = LT:Data().instances[v.instance] or {}
      local ids = {}
      if v.boss == "world" then for _, id in ipairs(inst.world or {}) do ids[id] = true end
      else for _, qq in ipairs(inst.quests or {}) do for _, id in ipairs(qq.items) do ids[id] = true end end end
      local out = {}
      for _, hit in ipairs(LT:Search(q)) do if ids[hit.id] then out[#out + 1] = hit end end
      return out
    end
    q.instance, q.boss = v.instance, v.boss
    return LT:Search(q)
  end
  -- For me: this character, or a class planned for later (level 60, no equipment to compare)
  if not subject then return {} end
  local own = not v.planClass or v.planClass == subject.class
  local who = own and subject or { class = v.planClass, level = 57 }
  local gear, spec = nil, v.planSpec
  if own then gear, spec = self:AdvisorInputs() end
  local list = LT:ForCharacter(who, gear, spec, v.slot)
  local text = v.text ~= "" and string.lower(v.text) or nil
  local out = {}
  for _, r in ipairs(list) do
    local wish = LT:Wish(r.id)
    local named = text and (string.find(string.lower(r.rec.n or ""), text, 1, true)
      or string.find(string.lower(LT:Name(r.id, r.rec)), text, 1, true))
    if (not text or named) and (not v.minQuality or (r.rec.q or 0) >= v.minQuality)
        and (not v.wishOnly or wish) and wish ~= "hide" then
      out[#out + 1] = r
    end
  end
  return out
end

function UI:BuildLootAtlas()
  local f = W.Panel("FLC_LootAtlas", nil, WIDTH, HEIGHT)
  -- above the guide window and its arrow, as the options window: in the client the guide covered the Atlas' corner
  -- (run 20261029-080052, screenshot boss)
  W.Dialog(f)
  self.atlas = f
  W.Movable(f, "lootAtlas", { "CENTER", "CENTER", 0, 40 })
  f.title = W.Text(f, 13, W.C.ember)
  f.title:SetPoint("TOPLEFT", 8, -7)
  f.title:SetText(L["Loot Atlas"])
  f.close = W.Button(f, "x", 18, 16, function() f:Hide() end)
  f.close:SetPoint("TOPRIGHT", -4, -4)
  f.guide = W.Button(f, L["Guide"], 60, 16, function() UI:StartDungeonGuide(view().instance) end, W.C.ok)
  f.guide:SetPoint("RIGHT", f.close, "LEFT", -6, 0)
  -- the boss's abilities above its items
  f.abilities = W.Text(f, 10, W.C.text)
  f.abilities:SetPoint("TOPLEFT", f, "TOPLEFT", 190, -56)
  f.abilities:SetPoint("RIGHT", f, "RIGHT", -8, 0)
  f.tabDungeons = W.Button(f, L["Dungeons"], 70, 18, function() local v = view(); v.tab, v.page = "dungeons", 0; UI:RefreshLootAtlas() end, W.C.teal)
  f.tabMe = W.Button(f, L["For me"], 60, 18, function() local v = view(); v.tab, v.page = "me", 0; UI:RefreshLootAtlas() end, W.C.teal)
  f.tabDungeons:SetPoint("TOPLEFT", 90, -5)
  f.tabMe:SetPoint("LEFT", f.tabDungeons, "RIGHT", 4, 0)
  -- search and filters
  f.search = ns.env.CreateFrame("EditBox", "FLC_LootAtlasSearch", f, "InputBoxTemplate")
  f.search:SetSize(150, 18)
  f.search:SetPoint("TOPLEFT", 14, -30)
  f.search:SetAutoFocus(false)
  f.search:SetScript("OnTextChanged", function(box) local v = view(); v.text, v.page = box:GetText() or "", 0; UI:RefreshLootAtlas() end)
  f.search:SetScript("OnEscapePressed", function(box) box:ClearFocus() end)
  f.quality = W.Button(f, L["Any quality"], 90, 18, function()
    local v = view()
    v.minQuality = (v.minQuality == nil and 2) or (v.minQuality < 4 and v.minQuality + 1) or nil
    v.page = 0
    UI:RefreshLootAtlas()
  end)
  f.quality:SetPoint("LEFT", f.search, "RIGHT", 8, 0)
  f.usable = W.Button(f, L["Usable by me"], 90, 18, function() local v = view(); v.usable, v.page = not v.usable, 0; UI:RefreshLootAtlas() end)
  f.usable:SetPoint("LEFT", f.quality, "RIGHT", 4, 0)
  f.wish = W.Button(f, L["Wishlist"], 70, 18, function() local v = view(); v.wishOnly, v.page = not v.wishOnly, 0; UI:RefreshLootAtlas() end, W.C.ember)
  f.wish:SetPoint("LEFT", f.usable, "RIGHT", 4, 0)
  f.plan = W.Button(f, "", 90, 18, function()
    local v, subject = view(), ns.Session.selfState
    local cur = v.planClass or (subject and subject.class)
    local i = 1
    for k, c in ipairs(UI.ATLAS_CLASSES) do if c == cur then i = k end end
    v.planClass = UI.ATLAS_CLASSES[i % #UI.ATLAS_CLASSES + 1]
    if subject and v.planClass == subject.class then v.planClass = nil end
    v.page = 0
    UI:RefreshLootAtlas()
  end)
  f.plan:SetPoint("LEFT", f.wish, "RIGHT", 4, 0)
  -- left column: dungeons and bosses, or slots
  f.left = W.RowPool(f, 20, function(parent)
    local b = W.Button(parent, "", 170, 18, function(self) if self.onPick then self.onPick() end end)
    return b
  end)
  -- right column: items with their wishlist button
  f.items = W.RowPool(f, 34, function(parent)
    local r = ns.env.CreateFrame("Frame", nil, parent)
    r.name = W.Text(r, 11, W.C.text)
    r.name:SetPoint("TOPLEFT", 0, 0)
    r.name:SetPoint("RIGHT", -80, 0)
    r.name:SetWordWrap(false)
    r.info = W.Text(r, 10, W.C.muted)
    r.info:SetPoint("TOPLEFT", r.name, "BOTTOMLEFT", 0, -2)
    r.info:SetPoint("RIGHT", -80, 0)
    r.info:SetWordWrap(false)
    r.wish = W.Button(r, "+", 74, 16, function() if r.id then LT:CycleWish(r.id); UI:RefreshLootAtlas() end end)
    r.wish:SetPoint("TOPRIGHT", 0, 0)
    return r
  end)
  f.prev = W.Button(f, "<", 20, 16, function() local v = view(); v.page = math.max(0, v.page - 1); UI:RefreshLootAtlas() end)
  f.next = W.Button(f, ">", 20, 16, function() local v = view(); v.page = v.page + 1; UI:RefreshLootAtlas() end)
  f.next:SetPoint("BOTTOMRIGHT", -8, 6)
  f.prev:SetPoint("RIGHT", f.next, "LEFT", -4, 0)
  f.count = W.Text(f, 10, W.C.muted)
  f.count:SetPoint("RIGHT", f.prev, "LEFT", -6, 0)
  f.note = W.Text(f, 9, W.C.muted)
  f.note:SetPoint("BOTTOMLEFT", 8, 8)
  f.note:SetText(L["Loot lists in review (no drop chances). Ratings are estimates from stat weights."])
  f:Hide()
end

-- The atlas on one boss of a dungeon or raid (from the Boss card).
function UI:ShowLootAtlasAt(dungeon, encounter)
  local v = view()
  local inst = LT:Data().instances[dungeon]
  v.tab, v.instance, v.boss, v.leftPage, v.page = "dungeons", inst and dungeon or nil, inst and encounter or nil, 0, 0
  v.kind = inst and inst.kind == "raid" and "raid" or nil
  self:ShowLootAtlas()
end

function UI:ShowLootAtlas(text)
  if not self.atlas then self:BuildLootAtlas() end
  if text and text ~= "" then
    view().text = text
    self.atlas.search:SetText(text)
  end
  self.atlas:Show()
  self:RefreshLootAtlas()
end

local function leftRows(v)
  local rows = {}
  if v.tab == "me" then
    rows[#rows + 1] = { label = L["All slots"], on = v.slot == nil, pick = function() v.slot = nil end }
    for _, s in ipairs(UI.ATLAS_SLOTS) do
      rows[#rows + 1] = { label = UI.AtlasLabel(s), on = v.slot == s, pick = function() v.slot = s end }
    end
    return rows
  end
  local raids = v.kind == "raid"
  if not v.instance then
    -- dungeons or raids (the raids only when the pack has some)
    if raids or #LT:Instances("raid") > 0 then
      rows[#rows + 1] = { label = raids and "< " .. L["Dungeons"] or L["Raids"] .. " >",
        pick = function() v.kind, v.leftPage = (not raids) and "raid" or nil, 0 end }
    end
    for _, x in ipairs(LT:Instances(raids and "raid" or "dungeon")) do
      rows[#rows + 1] = { label = L[x.inst.name] or x.inst.name, pick = function() v.instance, v.boss, v.leftPage = x.id, nil, 0 end }
    end
    return rows
  end
  local inst = LT:Data().instances[v.instance] or {}
  rows[#rows + 1] = { label = "< " .. (inst.kind == "raid" and L["All raids"] or L["All dungeons"]),
    pick = function() v.instance, v.boss, v.leftPage = nil, nil, 0 end }
  rows[#rows + 1] = { label = L[inst.name] or inst.name or "?", on = v.boss == nil, pick = function() v.boss = nil end }
  for _, b in ipairs(inst.bosses or {}) do
    rows[#rows + 1] = { label = "  " .. LT:BossName(b), on = v.boss == b.encounter, pick = function() v.boss = b.encounter end }
  end
  if inst.world then rows[#rows + 1] = { label = "  " .. L["Rare world drops"], on = v.boss == "world", pick = function() v.boss = "world" end } end
  if inst.quests then rows[#rows + 1] = { label = "  " .. L["Quest rewards"], on = v.boss == "quest", pick = function() v.boss = "quest" end } end
  return rows
end

function UI:RefreshLootAtlas()
  local f = self.atlas
  if not f or not f:IsShown() then return end
  local v, subject = view(), ns.Session.selfState
  f.quality:SetLabel(v.minQuality and L[LT.QUALITY[v.minQuality]] .. "+" or L["Any quality"])
  f.usable:SetLabel(v.usable and L["Usable by me"] or L["Every class"])
  f.wish:SetLabel(v.wishOnly and L["Wishlist only"] or L["Wishlist"])
  local planned = v.planClass or (subject and subject.class) or "?"
  -- the game's own class name ("Warrior", "Guerrero"), not the token
  local names = ns.env.LOCALIZED_CLASS_NAMES_MALE
  f.plan:SetLabel(names and names[planned] or L[planned] or planned)
  if v.tab == "me" then f.plan:Show(); f.usable:Hide() else f.plan:Hide(); f.usable:Show() end
  -- left column
  local rows = leftRows(v)
  if #rows > LEFT_ROWS then
    -- longer than the column (23 dungeons, Blackrock Depths' 17 bosses): pages, the last row turns them
    local per = LEFT_ROWS - 1
    local pages = math.ceil(#rows / per)
    local at = math.min(v.leftPage or 0, pages - 1)
    local slice = {}
    for i = at * per + 1, math.min(#rows, (at + 1) * per) do slice[#slice + 1] = rows[i] end
    slice[#slice + 1] = { label = string.format(L["More (%d/%d)"], at + 1, pages), pick = function() v.leftPage = (at + 1) % pages end }
    rows = slice
  end
  for i = 1, math.min(#rows, LEFT_ROWS) do
    local b = f.left:Get(i)
    local row = rows[i]
    b:SetLabel(row.on and W.Colorize(row.label, W.C.ok) or row.label)
    b.onPick = function() row.pick(); v.page = 0; UI:RefreshLootAtlas() end
    b:ClearAllPoints()
    b:SetPoint("TOPLEFT", f, "TOPLEFT", 8, -56 - (i - 1) * 21)
  end
  f.left:HideFrom(math.min(#rows, LEFT_ROWS) + 1)
  local DG = ns.DungeonGuide
  local g = v.tab == "dungeons" and v.instance and DG:For(v.instance)
  if g and DG:Active() ~= g then f.guide:Show() else f.guide:Hide() end
  -- right column: the boss's abilities, then the items in the rows left
  local lines = UI.AtlasAbilityLines(v)
  local reserved = 0
  if lines then
    f.abilities:SetText(table.concat(lines, "\n"))
    f.abilities:Show()
    local h = f.abilities.GetStringHeight and f.abilities:GetStringHeight()
    h = (type(h) == "number" and h > 0) and h or #lines * 13
    reserved = math.min(ITEM_ROWS - 4, math.ceil((h + 8) / 36))
  else
    f.abilities:Hide()
  end
  local per = ITEM_ROWS - reserved
  local items = self:AtlasItems()
  local pages = math.max(1, math.ceil(#items / per))
  v.page = math.min(v.page, pages - 1)
  local shown = 0
  for i = 1, per do
    local it = items[v.page * per + i]
    if not it then break end
    shown = i
    local r = f.items:Get(i)
    r.id = it.id
    r.name:SetText(UI.AtlasItemName(it.rec, it.id))
    local info = UI.AtlasItemLine(it.id, it.rec)
    if it.verdict == "better" then
      info = W.Colorize(it.confidence == "likely" and L["likely better"] or L["close: compare it when it drops"], W.C.ok) .. " · " .. info
    end
    r.info:SetText(info)
    local wish = LT:Wish(it.id)
    r.wish:SetLabel(wish and L[UI.ATLAS_WISH_LABEL[wish]] or ("+ " .. L["Wishlist"]))
    r:ClearAllPoints()
    r:SetPoint("TOPLEFT", f, "TOPLEFT", 190, -56 - (reserved + i - 1) * 36)
    r:SetPoint("RIGHT", f, "RIGHT", -8, 0)
  end
  f.items:HideFrom(shown + 1)
  f.count:SetText(#items == 0 and L["No item matches"] or string.format(L["%d items · page %d/%d"], #items, v.page + 1, pages))
end
ns.Bus:On("WISHLIST_CHANGED", UI, function() UI.dungeonNoticeCache = nil; UI.dungeonPlanCache = nil end)
