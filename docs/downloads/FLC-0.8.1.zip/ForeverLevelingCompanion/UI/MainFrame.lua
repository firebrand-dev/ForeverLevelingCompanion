-- Main guide window: compact current-step card, optional upcoming list, session banner and toasts.
local _, ns = ...
local W, L = ns.W, ns.L
local GE = ns.Guide

local UI = { built = false, toasts = {} }
ns.UI = UI

local WIDTH = 300
local UPCOMING = 5

local function badge(parent)
  local f = ns.env.CreateFrame("Frame", nil, parent)
  f:SetSize(18, 18)
  f.bg = W.Fill(f, W.C.panel, "ARTWORK")
  f.text = W.Text(f, 11, W.C.text, "CENTER")
  f.text:SetPoint("CENTER")
  function f:SetType(t)
    local b = W.TYPE_BADGE[t] or { "-", W.C.muted }
    self.text:SetText(b[1])
    W.SetColor(self.text, b[2])
  end
  return f
end

function UI:BuildMain()
  local f = W.Panel("FLC_MainFrame", nil, WIDTH, 96)
  self.main = f
  -- By default to the left of Blizzard's objective tracker (the right edge under the minimap), never over it
  -- (seen overlapping in the automated client runs, 2026-10-24); our tracker goes right under this window
  local blizzard = ns.env.ObjectiveTrackerFrame or ns.env.QuestWatchFrame
  if blizzard then
    W.Movable(f, "main", { "TOPRIGHT", "TOPLEFT", -16, 0, relativeTo = blizzard })
  else
    W.Movable(f, "main", { "TOPRIGHT", "TOPRIGHT", -220, -220 })
  end

  -- Accent strip: ember for the personal guide, teal while a party session is active.
  f.strip = f:CreateTexture(nil, "ARTWORK")
  f.strip:SetPoint("TOPLEFT")
  f.strip:SetPoint("BOTTOMLEFT")
  f.strip:SetWidth(2)

  f.title = W.Text(f, 11, W.C.muted)
  f.title:SetPoint("TOPLEFT", 10, -7)
  f.title:SetPoint("RIGHT", f, "RIGHT", -150, 0)
  f.title:SetWordWrap(false)

  f.counter = W.Text(f, 11, W.C.muted, "RIGHT")
  f.counter:SetPoint("TOPRIGHT", -122, -7)

  f.partyBtn = W.Button(f, L["Party"], 40, 16, function() UI:TogglePanel("party") end, W.C.teal)
  f.partyBtn:SetPoint("TOPRIGHT", -30, -4)
  -- the Guides window: choose the guide to follow (UI/GuidesFrame.lua)
  f.guidesBtn = W.Button(f, L["Guides"], 44, 16, function() UI:ToggleGuides() end, W.C.ember)
  f.guidesBtn:SetPoint("RIGHT", f.partyBtn, "LEFT", -4, 0)
  f.expandBtn = W.Button(f, "+", 22, 16, function()
    ns.Config:Set("ui.expanded", not ns.Config:Get("ui.expanded"))
    UI:Refresh()
  end)
  f.expandBtn:SetPoint("TOPRIGHT", -5, -4)

  -- Session banner: "Helping Nico - your progress is saved" + End.
  f.banner = ns.env.CreateFrame("Frame", nil, f)
  f.banner:SetHeight(20)
  f.banner:SetPoint("TOPLEFT", 2, -24)
  f.banner:SetPoint("TOPRIGHT", 0, -24)
  f.banner.bg = W.Fill(f.banner, W.Tint(W.C.teal, 0.18))
  f.banner.text = W.Text(f.banner, 11, W.C.teal)
  f.banner.text:SetPoint("LEFT", 8, 0)
  f.banner.text:SetPoint("RIGHT", -60, 0)
  f.banner.text:SetWordWrap(false)
  f.banner.stop = W.Button(f.banner, L["End"], 50, 16, function() UI:ReturnToGuide() end, W.C.teal)
  f.banner.stop:SetPoint("RIGHT", -4, 0)

  self:BuildAdvisorNotice(f)
  self:BuildDungeonNotice(f)

  f.card = ns.env.CreateFrame("Frame", nil, f)
  f.card:SetPoint("LEFT", 8, 0)
  f.card:SetPoint("RIGHT", -8, 0)
  f.card:SetHeight(48)
  f.badge = badge(f.card)
  f.badge:SetPoint("TOPLEFT", 0, -2)
  f.stepText = W.Text(f.card, 13, W.C.text)
  f.stepText:SetPoint("TOPLEFT", 24, 0)
  f.stepText:SetPoint("RIGHT", f.card, "RIGHT", 0, 0)
  f.detail = W.Text(f.card, 11, W.C.muted)
  f.detail:SetPoint("TOPLEFT", f.stepText, "BOTTOMLEFT", 0, -3)
  f.detail:SetPoint("RIGHT", f.card, "RIGHT", 0, 0)
  -- how to reach a far-away step: "Walk 300 yd > Fly to Orgrimmar > Zeppelin to Undercity (about 9 min)"
  f.route = W.Text(f.card, 11, W.C.teal)
  f.route:SetPoint("TOPLEFT", f.detail, "BOTTOMLEFT", 0, -3)
  f.route:SetPoint("RIGHT", f.card, "RIGHT", 0, 0)
  f.route:Hide()

  f.prev = W.Button(f, "<", 22, 18, function() UI:Step("prev") end)
  f.next = W.Button(f, L["Skip"], 54, 18, function() UI:Step("next") end, W.C.ember)
  f.done = W.Button(f, L["Done"], 54, 18, function() UI:Step("done") end, W.C.ok)
  f.way = W.Button(f, L["Waypoint"], 70, 18, function() UI:SetWaypoint() end)
  f.prev:SetPoint("BOTTOMLEFT", 8, 6)
  f.next:SetPoint("LEFT", f.prev, "RIGHT", 4, 0)
  f.done:SetPoint("LEFT", f.next, "RIGHT", 4, 0)
  f.way:SetPoint("BOTTOMRIGHT", -8, 6)
  -- the leveling path's next route (Engine/LevelingPath.lua), when this one is done or waits for a level
  f.nextZone = W.Button(f, L["Next zone"], 76, 18, function() UI:FollowPath() end, W.C.teal)
  f.nextZone:SetPoint("RIGHT", f.way, "LEFT", -4, 0)
  f.nextZone:Hide()

  f.toast = W.Text(f, 11, W.C.warn)
  f.toast:SetPoint("TOPLEFT", f, "BOTTOMLEFT", 2, -3)
  f.toast:SetPoint("RIGHT", f, "RIGHT", 0, 0)

  f.list = {}
  for i = 1, UPCOMING do
    local row = W.Text(f, 11, W.C.muted)
    row:SetWordWrap(false)
    f.list[i] = row
  end
end

-- What the player should know about a step's data (docs/DATA_FORMAT.md): nothing when the step was completed in the
-- game; "in review" while nobody has confirmed it in play, so the player can tell us (/flc review).
UI.DATA_LABELS = {
  unverified = "in review",
  ["extracted-db"] = "in review",
  ["static-validated"] = "in review",
  ["server-simulated"] = "in review",
  incomplete = "incomplete data (in review)",
}

-- A guide's title as shown: a later visit of a zone (generated routes split a zone by level) says which.
function UI.GuideTitle(g)
  local title = g.title and L[g.title] or g.id
  if g.visit and g.visit > 1 then title = string.format(L["%s (visit %d)"], title, g.visit) end
  return title
end

function UI.DataLabel(a)
  local s = a.step
  if not s then return nil end
  local status = s.status
  if not status and s.quest then
    local m = ns.Quest:Meta(s.quest)
    status = m and m.status
  end
  status = status or (a.guide and (a.guide.trust or a.guide.status))
  return UI.DATA_LABELS[status or ""]
end

-- /flc review: what the player sees now, for them to copy and send to FLC's authors when the game shows something
-- else (a step or ability in review). Nothing leaves the client: the text is shown to be copied.
-- /flc review and /flc bug: the step on screen, its data in review and FLC's latest errors, as text to copy and paste in
-- a report. Nothing leaves the client; no character or realm name is written.
function UI:ReviewReport()
  local a = ns.Session:Current()
  local out = { "FLC " .. ns.version .. " - " .. L["review"] }
  local info = ns.API.GetClientInfo and ns.API.GetClientInfo() or {}
  local p = ns.API.GetPlayerInfo and ns.API.GetPlayerInfo() or {}
  out[#out + 1] = string.format("%s %s (%s) %s - %s %s", L["Game"], tostring(info.version or "?"), tostring(info.build or "?"),
    tostring(info.locale or ns.locale or "?"), tostring(p.class or "?"), tostring(p.level or "?"))
  if a.guide then out[#out + 1] = L["Guide"] .. ": " .. UI.GuideTitle(a.guide) .. " (" .. a.guide.id .. ")" end
  if a.step then
    out[#out + 1] = L["Step"] .. ": " .. (a.step.id or "?") .. " - " .. GE:StepText(a.step, a.subject)
    local label = UI.DataLabel(a)
    if label then out[#out + 1] = L[label] end
    local review = {}
    for _, ab in ipairs(a.step.abilities or {}) do
      if ab.review then review[#review + 1] = ab.name end
    end
    if #review > 0 then out[#out + 1] = L["Abilities in review"] .. ": " .. table.concat(review, ", ") end
  end
  -- FLC's own errors (Core/Diagnostics.lua), the latest five, without the install folder
  local errs = ns.Diag and ns.Diag.errors or {}
  if #errs > 0 then
    out[#out + 1] = L["FLC errors"] .. ":"
    for i = math.max(1, #errs - 4), #errs do
      local e = errs[i]
      local msg = tostring(e.msg):gsub("Interface[\\/]AddOns[\\/]", "")
      out[#out + 1] = string.format("  x%d [%s] %s", e.count or 1, tostring(e.area), msg)
    end
  end
  out[#out + 1] = ""
  out[#out + 1] = L["What the game shows (write it here):"]
  out[#out + 1] = ""
  if ns.REPORT_URL then
    out[#out + 1] = L["Copy this text and paste it in a new report at:"]
    out[#out + 1] = ns.REPORT_URL
  else
    out[#out + 1] = L["Copy this text and send it to FLC's authors."]
  end
  return table.concat(out, "\n")
end

local function detailLine(a)
  local parts = {}
  local s, info = a.step, a.info or {}
  if a.status == "blocked" then
    if info.reason == "level" then parts[#parts + 1] = W.Colorize(string.format(L["Requires level %d"], info.need or 0), W.C.warn)
    elseif info.reason == "not-on-quest" then parts[#parts + 1] = W.Colorize(L["Quest not in log"], W.C.warn)
    else parts[#parts + 1] = W.Colorize(L["Requirements not met"], W.C.warn) end
  elseif a.status == "unknown" then
    parts[#parts + 1] = W.Colorize(L["Progress unknown: mark Done when finished"], W.C.muted)
  end
  -- With a "what to do" line on top, the counts go here with their own words: "Water Pitcher: 0/1".
  local progress = s.task and ns.Guide:ObjectiveProgress(s, a.subject)
  if progress then parts[#parts + 1] = progress
  elseif info.have and info.need then parts[#parts + 1] = string.format("%d/%d", info.have, info.need) end
  if s.type == "boss" then
    -- the boss's abilities by who they go at, "(?)" after the ones in review; no timers, no strategy that the data
    -- does not hold
    local groups, review = ns.DungeonGuide.AbilityGroups(s)
    local words = { tank = L["Tank"], around = L["Around it"], anyone = L["Anyone"], other = L["Other"] }
    local list = {}
    for _, g in ipairs(groups) do list[#list + 1] = words[g.group] .. ": " .. table.concat(g.names, ", ") end
    if #list > 0 then
      parts[#parts + 1] = table.concat(list, " · ")
      if review > 0 then
        parts[#parts + 1] = W.Colorize(L["(?) in review: tell us if the game shows something else (/flc review)"], W.C.muted)
      end
    end
    if s.noLoc then parts[#parts + 1] = W.Colorize(L["Position not known yet (in review): no arrow for this boss"], W.C.warn) end
    if s.noEvent then parts[#parts + 1] = W.Colorize(L["The game may not report this fight: press Done after the kill"], W.C.warn) end
    -- how the boss spawns (spawn pools and flags in the data): no chance is shown
    if s.rare then parts[#parts + 1] = W.Colorize(L["Rare: it is not always there (another creature may stand in its place)"], W.C.muted) end
    if s.places then parts[#parts + 1] = W.Colorize(string.format(L["Appears at one of %d places: the arrow shows one"], s.places), W.C.muted) end
    if s.patrol then parts[#parts + 1] = W.Colorize(L["It moves along a path: it may not be at the mark"], W.C.muted) end
    if s.scripted then parts[#parts + 1] = W.Colorize(L["Not attackable when you arrive: an event in the dungeon starts this fight"], W.C.muted) end
    if s.after then parts[#parts + 1] = W.Colorize(string.format(L["Appears or can be fought only after %s is defeated"], s.after), W.C.warn) end
  elseif s.noLoc then
    -- the data has no position for these objectives: the quest text says where (no arrow)
    parts[#parts + 1] = W.Colorize(L["Location not in FLC's data: see the quest text"], W.C.warn)
  end
  if s.loc then
    local pos = s.loc.cont ~= nil and UI.playerWorld or UI.playerPos
    local d = pos and ns.Nav.Distance(pos, s.loc)
    if d and ns.Nav.InArea(pos, s.loc) then
      parts[#parts + 1] = W.Colorize(L["In the area"], W.C.ok)
    elseif d then
      parts[#parts + 1] = ns.Nav.FormatDistance(d)
    elseif s.loc.cont == nil then
      parts[#parts + 1] = string.format("%.1f, %.1f", s.loc.x, s.loc.y)
    else
      local _, mx, my = ns.API.WorldToMap(s.loc)
      if mx then parts[#parts + 1] = string.format("%.1f, %.1f", mx, my) end
    end
  end
  if s.help and a.session then
    local who = a.session.targetName or "?"
    if s.note then parts[#parts + 1] = W.Colorize(string.format(L[s.note], who), W.C.teal) end
    if s.help.me == "progress" then parts[#parts + 1] = W.Colorize(L["also counts for you"], W.C.ok)
    elseif s.help.me == "help-completed" then parts[#parts + 1] = W.Colorize(L["you already completed it"], W.C.muted) end
  elseif s.who and a.session then
    local names = {}
    for _, key in ipairs(s.who) do names[#names + 1] = ns.U.shortName(key) end
    if #names > 0 then parts[#parts + 1] = W.Colorize(string.format(L["for %s"], table.concat(names, ", ")), W.C.teal) end
  end
  local mode = ns.Session.ctx.mode
  local alt = (mode == "group" and s.group) or (mode ~= "group" and s.solo)
  if alt and alt.text then parts[#parts + 1] = L[alt.text] end
  -- what the next steps ask for in this same place (Engine/GuideEngine.lua GE:AlsoHere)
  if a.guide and a.track and a.index then
    local also = {}
    for _, e in ipairs(ns.Guide:AlsoHere(a.guide, a.track, a.subject, ns.Session.ctx, a.index)) do
      local st = e.step
      also[#also + 1] = (not (st.type == "accept" or st.type == "turnin") and ns.Guide:ObjectiveProgress(st, a.subject))
        or ns.Guide:StepText(st, a.subject)
    end
    if #also > 0 then parts[#parts + 1] = W.Colorize(L["Also here"] .. ": " .. table.concat(also, "; "), W.C.teal) end
  end
  local label = UI.DataLabel(a)
  if label then parts[#parts + 1] = W.Colorize(L[label], W.C.muted) end
  return table.concat(parts, "  ·  ")
end

function UI:RefreshMain()
  local f = self.main
  if not f then return end
  local a = ns.Session:Current()
  self.current = a
  local session = a.session
  local inSession = session ~= nil
  local accent = inSession and W.C.teal or W.C.ember
  f.strip:SetColorTexture(accent[1], accent[2], accent[3], 1)

  local top = -24
  if inSession then
    f.banner:Show()
    local text
    if session.kind == "help" then
      text = string.format(L["Helping %s - your progress is saved"], session.targetName or "?")
      local st = session.status
      if st == "target-offline" then text = text .. " (" .. L["offline"] .. ")"
      elseif st == "target-left" then text = text .. " (" .. L["left the group"] .. ")"
      elseif st == "finished" then text = string.format(L["%s no longer needs help"], session.targetName or "?") end
    elseif session.kind == "detour" then
      text = string.format(L["Class quest: %s - your guide is saved"], session.title or "?")
    else
      text = string.format(L["%s - your guide is saved"], L[ns.Session.KIND_LABEL[session.kind] or session.kind])
    end
    f.banner.text:SetText(text)
    top = top - 22
  else
    f.banner:Hide()
  end
  top = top - self:RefreshAdvisorNotice(f, top)
  top = top - self:RefreshDungeonNotice(f, top)
  f.card:ClearAllPoints()
  f.card:SetPoint("TOPLEFT", 8, top)
  f.card:SetPoint("RIGHT", -8, 0)

  if not a.guide then
    f.title:SetText(L["Forever Leveling Companion"])
    f.counter:SetText("")
    f.badge:SetType(nil)
    f.stepText:SetText(L["No guide available for this character yet"])
    f.detail:SetText(L["No guide covers this character's level and place yet. See /flc help"])
  elseif not a.step then
    f.title:SetText(UI.GuideTitle(a.guide))
    f.counter:SetText("")
    f.badge:SetType("level")
    f.stepText:SetText(inSession and L["Route complete"] or L["Guide complete"])
    f.detail:SetText(inSession and L["Return to your guide when ready"] or "")
  else
    local title = UI.GuideTitle(a.guide)
    if session and session.kind == "help" then title = string.format(L["Route for %s"], session.targetName or "?") end
    f.title:SetText(title)
    local done, total = GE:Progress(a.guide, a.track, a.subject, ns.Session.ctx)
    f.counter:SetText(string.format("%d/%d", done, total))
    f.badge:SetType(a.step.type)
    f.stepText:SetText(GE:StepText(a.step, a.subject))
    W.SetColor(f.stepText, W.STATUS_COLOR[a.status] or W.C.text)
    f.detail:SetText(detailLine(a))
  end
  -- a boss step too: the game does not report every encounter (Engine/DungeonGuide.lua)
  local manual = a.step and (a.status == "unknown" or ns.Guide.STEP_TYPES[a.step.type] == "manual" or a.step.type == "goto"
    or a.step.type == "boss")
  if manual then f.done:Show() else f.done:Hide() end
  if a.step and a.step.loc then f.way:Show() else f.way:Hide() end
  -- one teal line: how to get there when far (travel plan), else the approach hint (stairs, floor, detour)
  local travel = a.step and self:TravelGuidance()
  local approach = not travel and a.step and self:ApproachGuidance()
  local line = (travel and travel.summary) or (approach and approach.text) or nil
  -- the leveling path: at the end of a route, or at a level the route waits for, say which route comes next
  local pathLine = not inSession and a.guide and self:PathHint(a)
  local showPath = pathLine and not line
  if showPath then line = pathLine end
  -- the button only with its line (a travel or approach line takes the place first)
  if showPath then f.nextZone:Show() else f.nextZone:Hide() end
  local lineHeight = 0
  if line then
    f.route:SetText(line)
    f.route:Show()
    local h = f.route.GetStringHeight and f.route:GetStringHeight()
    lineHeight = (type(h) == "number" and h > 0) and math.max(14, h + 3) or 14
  else
    f.route:SetText("")
    f.route:Hide()
  end

  -- Upcoming list
  local expanded = ns.Config:Get("ui.expanded") and not self.inCombat
  f.expandBtn:SetLabel(expanded and "-" or "+")
  -- the card grows with long step texts and detail lines (three objectives without names, a note and the data label
  -- wrapped onto the buttons in the client)
  local function height(fs)
    local h = fs.GetStringHeight and fs:GetStringHeight()
    return (type(h) == "number" and h > 0) and h or 0
  end
  local cardHeight = math.max(48, height(f.stepText) + 3 + height(f.detail) + 4)
  f.card:SetHeight(cardHeight)
  local listTop = top - cardHeight - 4 - lineHeight
  local shown = 0
  if expanded and a.guide and a.step then
    local up = GE:Upcoming(a.guide, a.track, a.subject, ns.Session.ctx, UPCOMING + 1)
    for i = 2, #up do
      shown = shown + 1
      local row = f.list[shown]
      row:ClearAllPoints()
      row:SetPoint("TOPLEFT", f, "TOPLEFT", 32, listTop - (shown - 1) * 15)
      row:SetPoint("RIGHT", f, "RIGHT", -8, 0)
      local color = up[i].status == "done" and W.C.ok or W.C.muted
      row:SetText(W.Colorize(GE:StepText(up[i].step, a.subject), color))
      row:Show()
    end
  end
  for i = shown + 1, UPCOMING do f.list[i]:Hide() end
  f:SetHeight(-listTop + shown * 15 + 28)
end

----------------------------------------------------------------------
-- Actions
----------------------------------------------------------------------
function UI:Step(action)
  local a = ns.Session:Current()
  if not a.guide then return end
  if action == "prev" then
    GE:Prev(a.guide, a.track)
  elseif action == "next" then
    GE:Next(a.guide, a.track, a.subject, ns.Session.ctx)
  elseif action == "done" and a.step then
    GE:MarkManual(a.track, a.step.id, true)
    GE:Release(a.guide, a.track)
  end
  ns.Party:BroadcastState()
  self:Refresh()
end

-- "Next on your path: The Barrens (levels 10-18)" when the current route is done, waits for a level, or is not the
-- route the path says to follow now; nil otherwise. Remembers the route for the Next zone button.
function UI:PathHint(a)
  self.pathNext = nil
  local pos = ns.Path and ns.Path:Position(a.subject, a.guide and a.guide.id)
  if not pos or not pos.next then return nil end
  local waiting = a.step and a.step.type == "level" and (a.subject.level or 1) < (a.step.level or 0)
  if a.step and not waiting and pos.current then return nil end
  local header = ns.Guide.guides[pos.next.guide]
  if not header then return nil end
  self.pathNext = pos.next.guide
  local name = UI.GuideTitle(header)
  if pos.grindTo then
    -- Quests only does not mention dungeons (Engine/Modes.lua)
    local fmt = ns.Modes:Get() == "quests" and L["Grind to level %d, then: %s (levels %d-%d)"]
      or L["Grind or do dungeons to level %d, then: %s (levels %d-%d)"]
    return string.format(fmt, pos.grindTo, name, pos.next.from, pos.next.to)
  end
  return string.format(L["Next on your path: %s (levels %d-%d)"], name, pos.next.from, pos.next.to)
end

-- Switches to the route the leveling path names next (the travel planner then says how to get there).
function UI:FollowPath()
  local id = self.pathNext
  if not id then return end
  local g = ns.Guide:Get(id)
  if not g then
    ns.API.Print(string.format(L["Unknown guide: %s"], id))
    return
  end
  local p = ns.Session:Personal()
  p.guideID = g.id
  if not p.cursors[g.id] and ns.Session.selfState then
    local i, step = ns.Guide:FindResumePoint(g, p, ns.Session.selfState, ns.Session.ctx)
    p.cursors[g.id] = { index = i, stepID = step and step.id }
  end
  ns.Party:BroadcastState()
  self:Refresh()
end

function UI:SetWaypoint()
  local a = self.current
  if not a or not a.step or not a.step.loc then return end
  local provider = ns.Config:Get("nav.waypointProvider") or "auto"
  local loc = a.step.loc
  local title = ns.Guide:StepText(a.step, a.subject)
  -- an approach being followed: the next via point first ("<step> (1/3)"); the button again gives the next one
  local ap = self:ApproachGuidance()
  if ap and ap.point then
    loc = ap.point
    title = string.format("%s (%d/%d)", title, ap.index, ap.total)
  end
  local map, x, y = loc.map, loc.x, loc.y
  if loc.cont ~= nil then map, x, y = ns.API.WorldToMap(loc) end
  local used = map and ns.API.SetWaypoint(map, x, y, title, provider)
  if not used then self:Toast(L["No waypoint provider available; follow the FLC arrow"]) end
end

function UI:ReturnToGuide()
  local restored = ns.Session:Stop("user")
  if restored then
    self:Toast(L["Back on your guide where you left it"])
  end
  self:Refresh()
end

function UI:Toast(text, seconds)
  if not self.main then
    ns.API.Print(text)
    return
  end
  self.main.toast:SetText(text)
  self.toastUntil = ns.Now() + (seconds or 8)
end

function UI:TickToast(now)
  if self.toastUntil and now > self.toastUntil and self.main then
    self.main.toast:SetText("")
    self.toastUntil = nil
  end
end

----------------------------------------------------------------------
-- Lifecycle
----------------------------------------------------------------------
function UI:Build()
  if self.built then return end
  self:BuildMain()
  self:BuildArrow()
  self:BuildParty()
  self:BuildTracker()
  self:BuildOptions()
  self:BuildMinimapButton()
  self.built = true
  self:AppearanceLogin()
  self:Refresh()
end

function UI:TogglePanel(which)
  local f = (which == "party" and self.party) or (which == "tracker" and self.tracker) or (which == "options" and self.options) or (which == "main" and self.main)
  if not f then return end
  if f:IsShown() then f:Hide() else f:Show() end
  self:Refresh()
end

function UI:ToggleGuides()
  if self.guidesFrame and self.guidesFrame:IsShown() then self.guidesFrame:Hide() else self:ShowGuides() end
end

function UI:SetCombat(inCombat)
  self.inCombat = inCombat
  if not self.built then return end
  if inCombat and ns.Config:Get("ui.compactInCombat") then
    self.restoreAfterCombat = { party = self.party:IsShown(), options = self.options:IsShown() }
    self.party:Hide()
    self.options:Hide()
  elseif not inCombat and self.restoreAfterCombat then
    if self.restoreAfterCombat.party then self.party:Show() end
    if self.restoreAfterCombat.options then self.options:Show() end
    self.restoreAfterCombat = nil
  end
  self:Refresh()
end

function UI:Refresh()
  self.arrowDirty = true
  if not self.built then return end
  ns.Diag:Measure("ui.refresh", function()
    self:RefreshMain()
    if self.party:IsShown() then self:RefreshParty() end
    if self.tracker:IsShown() then self:RefreshTracker() end
    if self.options:IsShown() then self:RefreshOptions() end
    if self.advisor and self.advisor:IsShown() then self:RefreshAdvisor() end
    if self.guidesFrame and self.guidesFrame:IsShown() then self:RefreshGuides() end
    self:RefreshBossCard()
  end)
end

ns.Bus:On("SESSION_CHANGED", UI, function() UI:Refresh() end)
ns.Bus:On("PARTY_CHANGED", UI, function() UI:Refresh() end)
ns.Bus:On("PARTY_MEMBER_DATA", UI, function() UI.dirty = true end)
ns.Bus:On("PARTY_OBJECTIVE", UI, function() UI.dirty = true end)
