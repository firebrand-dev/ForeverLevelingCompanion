-- Compact options panel (cycle buttons) and the diagnostics / export window.
local _, ns = ...
local W, L = ns.W, ns.L
local UI = ns.UI

local SHARE_LABEL = { ask = "Share progress: ask", yes = "Share progress: yes", no = "Share progress: no" }
local LOCALES = { "auto", "enUS", "esES" }

local function onoff(v) return v and L["on"] or L["off"] end

UI.QUEST_FLOW_LABELS = { guide = "Auto quests: the guide's", all = "Auto quests: all", off = "Auto quests: off" }

function UI:CycleQuestFlow()
  local list, cur = ns.QuestFlow.MODES, ns.QuestFlow:Mode()
  local idx = 1
  for i, m in ipairs(list) do if m == cur then idx = i end end
  ns.QuestFlow:SetMode(list[idx % #list + 1])
  self:Refresh()
end

function UI:BuildOptions()
  local f = W.Panel("FLC_OptionsFrame", nil, 240, 10)
  self.options = f
  W.Movable(f, "options", { "CENTER", "CENTER", 0, 80 })
  f.title = W.Text(f, 13, W.C.ember)
  f.title:SetPoint("TOPLEFT", 8, -8)
  f.title:SetText(L["Options"])
  f.close = W.Button(f, "x", 18, 16, function() f:Hide() end)
  f.close:SetPoint("TOPRIGHT", -4, -4)
  local function toggle(path) return function() ns.Config:Set(path, not ns.Config:Get(path)); UI:Refresh() end end
  f.rows = {
    { function() return L["Leveling mode"] .. ": " .. L[ns.Modes.LABEL[ns.Modes:Get()]] end, function() UI:CycleLevelingMode() end },
    { function() return L[UI.ANNOUNCE_LABELS[ns.Config:Get("announce.mode")]] end, function() UI:CycleAnnounce() end },
    { function() return L["Announce turn-ins"] .. ": " .. onoff(ns.Config:Get("announce.turnIn")) end, toggle("announce.turnIn") },
    { function() return L[SHARE_LABEL[ns.Config:Get("sync.share")] or "Share progress"] end, function()
        local cur = ns.Config:Get("sync.share")
        if cur == "yes" then ns.Party:SetShare(false) else ns.Party:SetShare(true) end
        UI:Refresh()
      end },
    { function() return L["Arrow"] .. ": " .. onoff(ns.Config:Get("ui.showArrow")) end, toggle("ui.showArrow") },
    { function() return L["Quest tracker"] .. ": " .. onoff(ns.Config:Get("ui.showTracker")) end, function()
        ns.Config:Set("ui.showTracker", not ns.Config:Get("ui.showTracker"))
        if ns.Config:Get("ui.showTracker") then UI.tracker:Show() else UI.tracker:Hide() end
        UI:ApplyBlizzardTracker()
        UI:Refresh()
      end },
    { function() return L["Game's quest tracker"] .. ": " .. (ns.Config:Get("ui.hideBlizzardTracker") and L["hidden"] or L["shown"]) end,
      function()
        ns.Config:Set("ui.hideBlizzardTracker", not ns.Config:Get("ui.hideBlizzardTracker"))
        UI:ApplyBlizzardTracker()
        UI:Refresh()
      end },
    { function() return L[UI.QUEST_FLOW_LABELS[ns.QuestFlow:Mode()]] end, function() UI:CycleQuestFlow() end },
    { function() return L["Minimap button"] .. ": " .. onoff(ns.Config:Get("ui.minimap.show")) end, function()
        UI:SetMinimapButtonShown(not ns.Config:Get("ui.minimap.show"))
        UI:Refresh()
      end },
    { function() return L["Lock frames"] .. ": " .. onoff(ns.Config:Get("ui.locked")) end, toggle("ui.locked") },
    { function() return L["Compact in combat"] .. ": " .. onoff(ns.Config:Get("ui.compactInCombat")) end, toggle("ui.compactInCombat") },
    { function() return L["Data recorder"] .. ": " .. onoff(ns.Config:Get("recorder")) end, toggle("recorder") },
    { function() return L["Language"] .. ": " .. ns.Config:Get("locale") .. " (" .. L["reload"] .. ")" end, function()
        local cur = ns.Config:Get("locale")
        local idx = 1
        for i, v in ipairs(LOCALES) do if v == cur then idx = i end end
        ns.Config:Set("locale", LOCALES[idx % #LOCALES + 1])
        UI:Refresh()
      end },
    { function() return L["Guides"] .. "..." end, function() UI:ShowGuides() end },
    { function() return L["Loot Atlas"] .. "..." end, function() UI:ShowLootAtlas() end },
    { function() return L["Appearance"] .. "..." end, function() UI:ShowAppearance() end },
    { function()
        return L["Welcome setup"] .. ((UI:SetupState() == "pending") and (" (" .. L["pending"] .. ")") or "") .. "..."
      end, function() UI:ShowSetup() end },
    { function() return L["Diagnostics report"] end, function() UI:ShowReport(ns.Diag:BuildReport(UI:StateLines())) end },
  }
  f.buttons = {}
  for i, row in ipairs(f.rows) do
    local b = W.Button(f, "", 224, 18, row[2])
    b:SetPoint("TOPLEFT", 8, -28 - (i - 1) * 21)
    f.buttons[i] = b
  end
  f:SetHeight(36 + #f.rows * 21)
  f:Hide()
end

function UI:RefreshOptions()
  for i, row in ipairs(self.options.rows) do self.options.buttons[i]:SetLabel(row[1]()) end
end

function UI:StateLines()
  local out = {}
  local a = ns.Session:Active()
  out[#out + 1] = "active: " .. tostring(a.kind) .. " guide " .. tostring(a.guide and a.guide.id)
  local p = ns.Session:Personal()
  if p.guideID then
    local c = p.cursors[p.guideID] or {}
    out[#out + 1] = string.format("personal: %s step %s (%s)", p.guideID, tostring(c.index), tostring(c.stepID))
  end
  local s = ns.Session:GetSession()
  if s then
    local saved = s.saved and s.saved.cursors and s.saved.cursors[s.saved.guideID] or {}
    out[#out + 1] = string.format("session: %s status %s target %s saved %s/%s", s.kind, tostring(s.status), tostring(s.target), tostring(saved.index), tostring(saved.stepID))
  end
  for _, m in ipairs(ns.Party:List()) do
    out[#out + 1] = string.format("member %s lvl %s addon %s share %s sync %s", m.key, tostring(m.level), tostring(m.hasAddon), tostring(m.share), tostring(m.syncState))
  end
  out[#out + 1] = "protocol queue " .. #ns.Protocol.queue .. " announce queue " .. #ns.Announcer.queue
  local bind = ns.Travel.store.bind or {}
  out[#out + 1] = string.format("travel: %d known flight masters with a position; bind %s (%s)", #ns.Travel:KnownNodes(),
    tostring(bind.name), bind.cont ~= nil and "position known" or "position unknown")
  local packs = ns.Packs:Summary()
  out[#out + 1] = "guide packs: " .. (#packs > 0 and #packs or "none (only the built-in sample guides)")
  for _, line in ipairs(packs) do out[#out + 1] = "  " .. line end
  return out
end

-- Read-only text window used for diagnostics and recorder export (copy with Ctrl+C).
function UI:ShowReport(text)
  if not self.report then
    local f = W.Panel("FLC_ReportFrame", nil, 520, 360)
    W.Dialog(f)
    W.Movable(f, "report", { "CENTER", "CENTER", 0, 0 })
    f.close = W.Button(f, "x", 18, 16, function() f:Hide() end)
    f.close:SetPoint("TOPRIGHT", -4, -4)
    f.hint = W.Text(f, 11, W.C.muted)
    f.hint:SetPoint("TOPLEFT", 8, -8)
    f.hint:SetText(L["Select all with Ctrl+A and copy with Ctrl+C. Nothing is sent automatically."])
    local scroll = ns.env.CreateFrame("ScrollFrame", "FLC_ReportScroll", f, "UIPanelScrollFrameTemplate")
    scroll:SetPoint("TOPLEFT", 8, -28)
    scroll:SetPoint("BOTTOMRIGHT", -28, 8)
    local edit = ns.env.CreateFrame("EditBox", nil, scroll)
    edit:SetMultiLine(true)
    edit:SetAutoFocus(false)
    edit:SetFontObject("ChatFontNormal")
    edit:SetWidth(480)
    edit:SetScript("OnEscapePressed", function(self) self:ClearFocus(); f:Hide() end)
    scroll:SetScrollChild(edit)
    f.edit = edit
    self.report = f
  end
  self.report.edit:SetText(text)
  self.report:Show()
  self.report.edit:HighlightText()
  self.report.edit:SetFocus()
end
