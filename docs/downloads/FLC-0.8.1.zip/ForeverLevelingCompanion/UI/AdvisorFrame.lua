-- Class Quest Advisor (Engine/Advisor.lua): the notice in the main window ("An important class quest is available")
-- with Now / Later / Skip / Details, and the details window: every chain that applies to the character, why, what it
-- gives, where it starts, solo or group, and the player's decision. Nothing here insists: Skip is final until the
-- player restores it, Later comes back a few levels later or near the start.
local _, ns = ...
local W, L = ns.W, ns.L
local UI = ns.UI
local AD = ns.Advisor

local WIDTH, ROWS = 420, 8

UI.TIER_LABELS = {
  critical = "Critical", ["very-recommended"] = "Very recommended", recommended = "Recommended",
  optional = "Optional", superseded = "Superseded",
}
UI.TIER_COLORS = { critical = "warn", ["very-recommended"] = "ember", recommended = "teal", optional = "muted",
  superseded = "muted" }
UI.ADVISOR_REFRESH = 5     -- seconds between equipment reads for the notice

-- One reason code of tools/catalog/advisor.py as a sentence for the player.
function UI.AdvisorReason(code)
  local kind, rest = string.match(code or "", "^([%w%-]+):?(.*)$")
  if kind == "core-ability" then return string.format(L["Unlocks: %s"], rest) end
  if kind == "teaches" then return string.format(L["Teaches: %s"], rest) end
  if kind == "totem" then return L["A shaman totem"] end
  if kind == "weapon" then
    local dps, _, ref = string.match(rest, "^([%d%.]+):([%d%.]+):([%d%.]+)$")
    if dps then return string.format(L["Weapon: %s DPS (quests of this level usually give %s)"], dps, ref) end
  end
  if kind == "stats" then return L["Stats well above what quests of this level give, for your class"] end
  if kind == "cosmetic-spell" then return string.format(L["Cosmetic: %s"], rest) end
  return nil
end

function UI:AdvisorContext()
  local a = self.current
  local waiting = a and a.guide and (not a.step or (a.step.type == "level" and (a.subject.level or 1) < (a.step.level or 0)))
  return { pos = self.playerWorld or ns.API.GetPlayerWorldPosition(), waiting = waiting and true or false }
end

-- The character's view for the advisor: equipment, specialisation and known spells, read at most every few seconds.
function UI:AdvisorInputs(force)
  local now = ns.Now()
  if force or not self.advisorRead or now - self.advisorRead > UI.ADVISOR_REFRESH then
    self.advisorRead = now
    self.advisorGear = ns.API.GetEquippedGear and ns.API.GetEquippedGear() or nil
    self.advisorSpec = ns.API.GetTalentSpec and ns.API.GetTalentSpec() or nil
  end
  local known = ns.API.KnowsSpell and function(name, id) return ns.API.KnowsSpell(name, id) end or nil
  return self.advisorGear, self.advisorSpec, known
end

-- The chain for the main window's notice, or nil. Worked out again only every few seconds or after a change (level,
-- equipment, a decision, a quest turned in): the main window refreshes far more often.
function UI:AdvisorNotice()
  local subject = ns.Session.selfState
  if not subject or not AD or #AD.entries == 0 or ns.Session:GetSession() then return nil end
  local now = ns.Now()
  local c = self.advisorNoticeCache
  if c and c.read == self.advisorRead and now - c.at < UI.ADVISOR_REFRESH and c.level == subject.level then
    return c.ev, c.dist
  end
  local gear, spec, known = self:AdvisorInputs()
  local ev, dist = AD:Notice(subject, gear, spec, known, self:AdvisorContext())
  self.advisorNoticeCache = { ev = ev, dist = dist, at = now, read = self.advisorRead, level = subject.level }
  return ev, dist
end
ns.Bus:On("ADVISOR_CHANGED", UI, function() UI.advisorNoticeCache = nil end)
ns.Bus:On("TRACKER_QUEST_TURNED_IN", UI, function() UI.advisorNoticeCache = nil end)

function UI:AdvisorDecide(id, state)
  -- a button of a notice that shows no chain (hidden, e.g. during a session) has no id: nothing to decide
  -- (a test click on it raised a Lua error in the client, 2026-10-26)
  if id == nil then return end
  local subject = ns.Session.selfState
  local ctx = self:AdvisorContext()
  AD:Decide(id, state, subject and subject.level, ctx)
  self.advisorList = nil
  if state == "now" then
    local e = AD.byId[id]
    local ok, why = ns.Session:StartDetour(e)
    if not ok then
      AD:Decide(id, "later", subject and subject.level, ctx)
      ns.API.Print(string.format(L["Could not build a route for %s: %s"], e and e.title or id, tostring(why)))
    end
  end
  self:Refresh()
end

-- Builds the notice inside the main window (called from UI:BuildMain).
function UI:BuildAdvisorNotice(f)
  local n = ns.env.CreateFrame("Frame", nil, f)
  n:SetHeight(40)
  n:SetPoint("LEFT", 2, 0)
  n:SetPoint("RIGHT", 0, 0)
  n.bg = W.Fill(n, W.Tint(W.C.ember, 0.14))
  n.text = W.Text(n, 11, W.C.text)
  n.text:SetPoint("TOPLEFT", 8, -3)
  n.text:SetPoint("RIGHT", -6, 0)
  n.text:SetWordWrap(false)
  n.now = W.Button(n, L["Do it now"], 70, 16, function() UI:AdvisorDecide(n.id, "now") end, W.C.ok)
  n.later = W.Button(n, L["Later"], 52, 16, function() UI:AdvisorDecide(n.id, "later") end)
  n.skip = W.Button(n, L["Skip it"], 52, 16, function() UI:AdvisorDecide(n.id, "skip") end, W.C.ember)
  n.details = W.Button(n, L["Details"], 60, 16, function() UI:ShowAdvisor(n.id) end, W.C.teal)
  n.now:SetPoint("BOTTOMLEFT", 8, 3)
  n.later:SetPoint("LEFT", n.now, "RIGHT", 4, 0)
  n.skip:SetPoint("LEFT", n.later, "RIGHT", 4, 0)
  n.details:SetPoint("LEFT", n.skip, "RIGHT", 4, 0)
  n:Hide()
  f.advice = n
end

-- Shows or hides the notice; returns the height it takes.
function UI:RefreshAdvisorNotice(f, top)
  local n = f.advice
  if not n then return 0 end
  local ev = self:AdvisorNotice()
  if not ev then
    n:Hide()
    n.id = nil
    return 0
  end
  local e = ev.entry
  n.id = e.id
  local label = e.classSpecific and L["Important class quest available"] or L["Quest with an important reward available"]
  n.text:SetText(string.format("%s: %s (%s)", W.Colorize(label, W.C[UI.TIER_COLORS[ev.tier]] or W.C.ember), e.title or "?",
    L[UI.TIER_LABELS[ev.tier] or ev.tier]))
  n:ClearAllPoints()
  n:SetPoint("TOPLEFT", f, "TOPLEFT", 2, top)
  n:SetPoint("RIGHT", f, "RIGHT", 0, 0)
  n:Show()
  return 42
end

----------------------------------------------------------------------
-- Details window
----------------------------------------------------------------------
function UI:BuildAdvisor()
  local f = W.Panel("FLC_AdvisorFrame", nil, WIDTH, 120)
  self.advisor = f
  W.Movable(f, "advisor", { "CENTER", "CENTER", 0, 80 })
  f.title = W.Text(f, 12, W.C.ember)
  f.title:SetPoint("TOPLEFT", 8, -7)
  f.title:SetText(L["Class quests and rewards"])
  f.close = W.Button(f, "x", 18, 16, function() f:Hide() end)
  f.close:SetPoint("TOPRIGHT", -4, -4)
  f.page = 0
  f.more = W.Button(f, ">", 18, 16, function() f.page = f.page + 1; UI:RefreshAdvisor() end)
  f.more:SetPoint("RIGHT", f.close, "LEFT", -4, 0)
  f.less = W.Button(f, "<", 18, 16, function() f.page = math.max(0, f.page - 1); UI:RefreshAdvisor() end)
  f.less:SetPoint("RIGHT", f.more, "LEFT", -2, 0)
  f.note = W.Text(f, 10, W.C.muted)
  f.note:SetPoint("TOPLEFT", 8, -24)
  f.note:SetPoint("RIGHT", -8, 0)
  f.rows = {}
  for i = 1, ROWS do
    local r = ns.env.CreateFrame("Frame", nil, f)
    r:SetHeight(44)
    r.head = W.Text(r, 11, W.C.text)
    r.head:SetPoint("TOPLEFT", 0, 0)
    r.head:SetPoint("RIGHT", -120, 0)
    r.head:SetWordWrap(false)
    r.body = W.Text(r, 10, W.C.muted)
    r.body:SetPoint("TOPLEFT", r.head, "BOTTOMLEFT", 0, -2)
    r.body:SetPoint("RIGHT", -120, 0)
    r.now = W.Button(r, L["Do it now"], 70, 16, function() UI:AdvisorDecide(r.id, "now") end, W.C.ok)
    r.later = W.Button(r, L["Later"], 46, 16, function() UI:AdvisorDecide(r.id, "later") end)
    r.skip = W.Button(r, L["Skip it"], 52, 16, function()
      if r.skipped then UI:AdvisorDecide(r.id, nil) else UI:AdvisorDecide(r.id, "skip") end
    end, W.C.ember)
    r.now:SetPoint("TOPRIGHT", 0, 0)
    r.later:SetPoint("TOPRIGHT", r.now, "BOTTOMRIGHT", -24, -2)
    r.skip:SetPoint("LEFT", r.later, "RIGHT", 2, 0)
    r:Hide()
    f.rows[i] = r
  end
  f:Hide()
end

function UI:ShowAdvisor(focusID)
  if not self.advisor then self:BuildAdvisor() end
  self.advisorFocus = focusID
  if focusID then self.advisor.page = 0 end
  self.advisor:Show()
  self:RefreshAdvisor()
end

-- The lines for one chain: what it gives, why, where it starts, solo or group, the detour.
function UI.AdvisorLines(ev, pos)
  local e, parts = ev.entry, {}
  local why = {}
  for _, code in ipairs(ev.reasons or {}) do
    local t = UI.AdvisorReason(code)
    if t then why[#why + 1] = t end
  end
  if ev.tier == "superseded" and ev.outgrown and not ev.compared then
    why[#why + 1] = L["Outgrown for your level"]
  elseif ev.tier == "superseded" then
    why[#why + 1] = L["What you have is already as good"]
  end
  if #why > 0 then parts[#parts + 1] = table.concat(why, " · ") end
  local items = {}
  for _, it in ipairs(ev.items or {}) do
    local i = it.item
    local t = i.name or "?"
    if i.dps then t = string.format("%s (%.1f DPS, %.1f)", t, i.dps, i.speed or 0) end
    if it.verdict == "better" then t = t .. " " .. W.Colorize(L["better than yours"], W.C.ok)
    elseif it.verdict == "superseded" then t = t .. " " .. W.Colorize(L["not better than yours"], W.C.muted)
    elseif it.verdict == "outgrown" then t = t .. " " .. W.Colorize(L["outgrown"], W.C.muted) end
    items[#items + 1] = t
  end
  if #items > 0 then parts[#parts + 1] = L["Reward"] .. ": " .. table.concat(items, ", ") end
  if not ev.compared and #items > 0 then parts[#parts + 1] = L["Your equipment could not be compared: general advice"] end
  local st = e.start or {}
  local where = st.name or "?"
  if st.zoneName then where = string.format("%s (%s)", where, L[st.zoneName]) end
  local d = AD.Distance(e, pos)
  local detour = d and ns.Nav.FormatDistance(d) or L["another continent or far away"]
  local own = ev.entry.classes and ns.Session.selfState and ev.entry.classes[ns.Session.selfState.class or ""]
  local chain = (own and own.chain) or e.chain or { e.quest }
  parts[#parts + 1] = string.format(L["Starts with %s · %d quests · %s"], where, #chain, detour)
  parts[#parts + 1] = e.group and L["Group recommended: use Party Mode"] or L["Can be done solo"]
  return parts
end

function UI:RefreshAdvisor()
  local f = self.advisor
  if not f or not f:IsShown() then return end
  local subject = ns.Session.selfState
  local list = {}
  if subject then
    local gear, spec, known = self:AdvisorInputs(true)
    list = AD:Candidates(subject, gear, spec, known, self.playerWorld or ns.API.GetPlayerWorldPosition())
  end
  if self.advisorFocus then
    for i, ev in ipairs(list) do
      if ev.entry.id == self.advisorFocus and i > 1 then table.remove(list, i); table.insert(list, 1, ev) break end
    end
  end
  local decisions = AD:Decisions()
  f.note:SetText(#list == 0 and L["No class quest or important reward for your level right now"]
    or L["Tiers are estimates (in review). Skip hides a chain until you restore it."])
  local pos = self.playerWorld or ns.API.GetPlayerWorldPosition()
  local pages = math.max(1, math.ceil(#list / ROWS))
  f.page = math.min(f.page or 0, pages - 1)
  if pages > 1 then f.more:Show(); f.less:Show() else f.more:Hide(); f.less:Hide() end
  local y = -42
  for i = 1, ROWS do
    local r, ev = f.rows[i], list[f.page * ROWS + i]
    if ev then
      local e, d = ev.entry, decisions[ev.entry.id]
      r.id = e.id
      r.skipped = d and d.state == "skip"
      local state = d and L[d.state == "later" and "postponed" or d.state == "skip" and "skipped" or "in progress"] or nil
      r.head:SetText(string.format("%s %s (%d-%d)%s", W.Colorize(L[UI.TIER_LABELS[ev.tier] or ev.tier],
        W.C[UI.TIER_COLORS[ev.tier]] or W.C.text), e.title or "?", e.minLevel or 0, e.level or 0,
        state and (" - " .. state) or ""))
      r.body:SetText(table.concat(UI.AdvisorLines(ev, pos), "\n"))
      r.skip:SetLabel(r.skipped and L["Restore"] or L["Skip it"])
      r:ClearAllPoints()
      r:SetPoint("TOPLEFT", f, "TOPLEFT", 8, y)
      r:SetPoint("RIGHT", f, "RIGHT", -8, 0)
      local h = r.body.GetStringHeight and r.body:GetStringHeight()
      h = math.max(44, ((type(h) == "number" and h) or 30) + 18)
      r:SetHeight(h)
      r:Show()
      y = y - h - 6
    else
      r:Hide()
    end
  end
  f:SetHeight(-y + 8)
end
