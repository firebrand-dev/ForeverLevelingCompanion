-- FLC visual identity and small widget toolkit. Flat panels built from color textures only
-- (no Blizzard templates beyond fonts and the optional backdrop mixin), so the code is client-agnostic.
-- Every texture, border and text remembers the colour role (a W.C table) it was made with, so a theme
-- (Engine/Appearance.lua) restyles every FLC window live: W.ApplyTheme.
local _, ns = ...

local W = {}
ns.W = W

W.C = {
  bg = { 0.055, 0.063, 0.082, 0.90 },
  panel = { 0.098, 0.110, 0.137, 0.95 },
  line = { 1, 1, 1, 0.08 },
  ember = { 0.965, 0.616, 0.235, 1 },     -- personal guide accent
  teal = { 0.247, 0.780, 0.737, 1 },      -- party accent
  text = { 0.925, 0.929, 0.945, 1 },
  muted = { 0.600, 0.624, 0.663, 1 },
  ok = { 0.420, 0.851, 0.471, 1 },
  warn = { 1.000, 0.800, 0.310, 1 },
  bad = { 1.000, 0.420, 0.380, 1 },
  hover = { 1, 1, 1, 0.07 },
}
W.STATUS_COLOR = {
  active = W.C.text, done = W.C.ok, blocked = W.C.warn, unknown = W.C.muted, skipped = W.C.muted, finished = W.C.ok,
}
W.TYPE_BADGE = {
  accept = { "A", W.C.warn }, turnin = { "T", W.C.ok }, complete = { "C", W.C.teal }, kill = { "K", W.C.bad },
  collect = { "C", W.C.teal }, ["goto"] = { "G", W.C.ember }, level = { "L", W.C.ember },
}

function W.Hex(c)
  return string.format("%02x%02x%02x", math.floor(c[1] * 255), math.floor(c[2] * 255), math.floor(c[3] * 255))
end

function W.Colorize(text, c) return "|cff" .. W.Hex(c) .. tostring(text) .. "|r" end

-- Inline glyphs built from textures every client ships; game fonts lack most symbols.
W.CHECK = "|TInterface\\RaidFrame\\ReadyCheck-Ready:12:12|t"
function W.Dot(c, size)
  size = size or 8
  return string.format("|TInterface\\Buttons\\WHITE8X8:%d:%d:0:0:8:8:0:8:0:8:%d:%d:%d|t", size, size,
    math.floor(c[1] * 255), math.floor(c[2] * 255), math.floor(c[3] * 255))
end

function W.ClassColor(class)
  local t = ns.env.RAID_CLASS_COLORS
  local c = t and class and t[class]
  if c then return { c.r, c.g, c.b, 1 } end
  return W.C.text
end

-- What every widget was made with, for W.ApplyTheme
W.reg = { fills = {}, borders = {}, texts = {}, panels = {} }
W.theme = nil

-- A colour role with its own alpha (a notice tinted with the accent): follows the theme like the role itself
function W.Tint(role, alpha) return { _role = role, _a = alpha } end

local function rgba(c)
  if c._role then return c._role[1], c._role[2], c._role[3], c._a end
  return c[1], c[2], c[3], c[4] or 1
end
W.RGBA = rgba

function W.Fill(frame, color, layer)
  local t = frame:CreateTexture(nil, layer or "BACKGROUND")
  t:SetAllPoints(frame)
  t:SetColorTexture(rgba(color))
  t._flcColor = color
  W.reg.fills[#W.reg.fills + 1] = t
  return t
end

-- 1px hairline border.
function W.Border(frame, color)
  color = color or W.C.line
  local function edge(p1, p2, horizontal)
    local t = frame:CreateTexture(nil, "BORDER")
    t:SetColorTexture(color[1], color[2], color[3], color[4])
    t:SetPoint(p1)
    t:SetPoint(p2)
    if horizontal then t:SetHeight(1) else t:SetWidth(1) end
    return t
  end
  local set = { color = color, edge("TOPLEFT", "TOPRIGHT", true), edge("BOTTOMLEFT", "BOTTOMRIGHT", true),
    edge("TOPLEFT", "BOTTOMLEFT", false), edge("TOPRIGHT", "BOTTOMRIGHT", false) }
  W.reg.borders[#W.reg.borders + 1] = set
  frame._flcBorder = set
end

function W.Panel(name, parent, width, height)
  -- the backdrop mixin (when the client has it) lets a theme use Blizzard's tooltip border instead of 1px lines
  local f = ns.env.CreateFrame("Frame", name, parent or ns.env.UIParent, ns.env.BackdropTemplateMixin and "BackdropTemplate" or nil)
  W.reg.panels[#W.reg.panels + 1] = f
  f._flcTop = parent == nil or parent == ns.env.UIParent
  f:SetSize(width, height)
  f:SetFrameStrata("MEDIUM")
  f.bg = W.Fill(f, W.C.bg)
  W.Border(f)
  f:SetClampedToScreen(true)
  return f
end

function W.Text(parent, size, color, justify, layer)
  local fs = parent:CreateFontString(nil, layer or "OVERLAY", "GameFontHighlight")
  local font = fs:GetFont()
  fs._flcBaseFont, fs._flcSize = font or ns.env.STANDARD_TEXT_FONT, size or 12
  local th = W.theme
  fs:SetFont(th and th.font or fs._flcBaseFont, fs._flcSize * (th and th.fontScale or 1), "")
  local c = color or W.C.text
  fs._flcColor = c
  fs:SetTextColor(rgba(c))
  W.reg.texts[#W.reg.texts + 1] = fs
  fs:SetJustifyH(justify or "LEFT")
  fs:SetWordWrap(true)
  return fs
end

function W.SetColor(fs, c) fs._flcColor = c; fs:SetTextColor(rgba(c)) end

function W.Button(parent, label, width, height, onClick, accent)
  local b = ns.env.CreateFrame("Button", nil, parent)
  b:SetSize(width, height or 20)
  b.bg = W.Fill(b, W.C.panel)
  b.hl = b:CreateTexture(nil, "HIGHLIGHT")
  b.hl:SetAllPoints(b)
  b.hl:SetColorTexture(rgba(W.C.hover))
  b.hl._flcColor = W.C.hover
  W.reg.fills[#W.reg.fills + 1] = b.hl
  b.accent = b:CreateTexture(nil, "ARTWORK")
  b.accent:SetPoint("BOTTOMLEFT")
  b.accent:SetPoint("BOTTOMRIGHT")
  b.accent:SetHeight(1)
  local a = accent or W.C.line
  b.accent:SetColorTexture(rgba(a))
  b.accent._flcColor = a
  W.reg.fills[#W.reg.fills + 1] = b.accent
  b.label = W.Text(b, 11, W.C.text, "CENTER")
  b.label:SetPoint("CENTER")
  b.label:SetText(label or "")
  b:SetScript("OnClick", function(self, button)
    ns.Diag:Guard("ui:click", onClick, self, button)
  end)
  function b:SetLabel(text) self.label:SetText(text) end
  return b
end

-- Makes a frame draggable and remembers its position in FLC_DB.layout[key].
function W.Movable(frame, key, defaultPoint)
  frame:SetMovable(true)
  frame:EnableMouse(true)
  frame:RegisterForDrag("LeftButton")
  frame:SetScript("OnDragStart", function(self)
    if not ns.Config:Get("ui.locked") then self:StartMoving() end
  end)
  frame:SetScript("OnDragStop", function(self)
    self:StopMovingOrSizing()
    local point, _, relPoint, x, y = self:GetPoint(1)
    ns.Config.account.layout[key] = { point = point, relPoint = relPoint, x = x, y = y }
  end)
  local saved = ns.Config.account.layout[key]
  frame:ClearAllPoints()
  if saved and saved.point then
    frame:SetPoint(saved.point, ns.env.UIParent, saved.relPoint or saved.point, saved.x or 0, saved.y or 0)
  else
    -- defaultPoint.relativeTo: next to another frame (e.g. Blizzard's objective tracker) instead of the screen
    frame:SetPoint(defaultPoint[1], defaultPoint.relativeTo or ns.env.UIParent, defaultPoint[2], defaultPoint[3], defaultPoint[4])
  end
end

function W.ResetLayout()
  ns.Config.account.layout = {}
end

-- Pool of single-line rows for lists that change size often.
function W.RowPool(parent, height, create)
  local pool = { rows = {}, parent = parent, height = height, create = create }
  function pool:Get(i)
    local r = self.rows[i]
    if not r then
      r = self.create(self.parent, i)
      r:SetHeight(self.height)
      self.rows[i] = r
    end
    r:Show()
    return r
  end
  function pool:HideFrom(i)
    for j = i, #self.rows do self.rows[j]:Hide() end
  end
  return pool
end

-- The bar texture of the current theme (status bars of later windows: dungeon progress, loot comparisons)
-- A window read over others (Loot Atlas, Appearance, the report): above FLC's other windows, raised when clicked, and
-- its background nearly opaque whatever the theme's opacity, so the text of a window behind it does not show through.
W.DIALOG_ALPHA = 0.97
function W.Dialog(f)
  f._flcDialog = true
  f:SetFrameStrata("DIALOG")
  if f.SetToplevel then f:SetToplevel(true) end
  if f.bg then
    f.bg._flcColor = W.Tint(W.C.bg, W.DIALOG_ALPHA)
    f.bg:SetColorTexture(rgba(f.bg._flcColor))
  end
  return f
end

function W.BarTexture() return W.theme and W.theme.bar or "Interface\\Buttons\\WHITE8X8" end

-- Restyles every FLC widget with a resolved theme (ns.Appearance.Resolve): colours in place (W.C keeps its tables,
-- so code that reads W.C later gets the new colours too), fonts, edges and the scale of FLC's own top windows.
-- Out of combat or in, it only touches FLC's frames, none of them protected.
function W.ApplyTheme(theme)
  if type(theme) ~= "table" or type(theme.colors) ~= "table" then return false end
  for role, col in pairs(theme.colors) do
    local dst = W.C[role]
    if dst then dst[1], dst[2], dst[3], dst[4] = col[1], col[2], col[3], col[4] or 1 end
  end
  W.theme = theme
  for _, t in ipairs(W.reg.fills) do t:SetColorTexture(rgba(t._flcColor)) end
  local lines = theme.edge == "line"
  for _, set in ipairs(W.reg.borders) do
    for i = 1, 4 do
      set[i]:SetColorTexture(rgba(set.color))
      if lines then set[i]:Show() else set[i]:Hide() end
    end
  end
  local A = ns.Appearance
  for _, f in ipairs(W.reg.panels) do
    if f.SetBackdrop then
      if theme.edge == "tooltip" then
        f:SetBackdrop({ bgFile = A.TOOLTIP_BG, edgeFile = A.TOOLTIP_EDGE, tile = true, tileSize = 16, edgeSize = 14,
          insets = { left = 3, right = 3, top = 3, bottom = 3 } })
        local r, g, b, a = rgba(W.C.bg)
        f:SetBackdropColor(r, g, b, f._flcDialog and W.DIALOG_ALPHA or a)
        f:SetBackdropBorderColor(rgba(W.C.line))
        if f.bg then f.bg:Hide() end
      else
        f:SetBackdrop(nil)
        if f.bg then f.bg:Show() end
      end
    end
    if f._flcTop and f.SetScale then f:SetScale(theme.scale or 1) end
  end
  for _, fs in ipairs(W.reg.texts) do
    fs:SetFont(theme.font or fs._flcBaseFont, fs._flcSize * (theme.fontScale or 1), "")
    fs:SetTextColor(rgba(fs._flcColor))
  end
  if ns.Bus then ns.Bus:Fire("APPEARANCE_CHANGED", theme) end
  return true
end
