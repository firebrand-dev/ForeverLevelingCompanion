-- Navigation arrow. Uses the client's map position and facing; hides itself when either is
-- unavailable (instances, restricted contexts) instead of pointing somewhere wrong.
local _, ns = ...
local W, L = ns.W, ns.L
local UI = ns.UI

local TEXTURE = "Interface\\AddOns\\ForeverLevelingCompanion\\Media\\Arrow"

function UI:BuildArrow()
  local f = ns.env.CreateFrame("Frame", "FLC_Arrow", ns.env.UIParent)
  f:SetSize(64, 78)
  f:SetFrameStrata("MEDIUM")
  f:SetClampedToScreen(true)
  W.Movable(f, "arrow", { "TOP", "TOP", 0, -140 })
  f.tex = f:CreateTexture(nil, "ARTWORK")
  f.tex:SetSize(48, 48)
  f.tex:SetPoint("TOP", 0, -2)
  f.tex:SetTexture(TEXTURE)
  f.dist = W.Text(f, 12, W.C.text, "CENTER")
  f.dist:SetPoint("TOP", f.tex, "BOTTOM", 0, -2)
  f.dist:SetWidth(120)
  f.dist:SetWordWrap(false)
  -- far-away steps: the travel leg the arrow points to ("Fly from Crossroads to Orgrimmar"); near ones with an
  -- approach: its hint ("Go up the stairs inside the tower - the NPC is on the upper floor")
  f.route = W.Text(f, 11, W.C.teal, "CENTER")
  f.route:SetPoint("TOP", f.dist, "BOTTOM", 0, -2)
  f.route:SetWidth(240)
  f.route:Hide()
  f:Hide()
  self.arrow = f
end

-- Called ~20 times per second from the ticker.
function UI:UpdateArrow()
  local f = self.arrow
  if not f then return end
  local map, x, y = ns.API.GetUnitPosition("player")
  local facing = ns.API.GetFacing()
  local a = self.current
  -- Runs 20 times a second: when the player, their facing and the step are as last time, there is nothing to redo.
  -- (Measured in the client: rebuilding it all made ~17 KB of garbage per second while standing still.)
  local step, status = a and a.step, a and a.status
  if not self.arrowDirty and map == f.lastMap and x == f.lastX and y == f.lastY and facing == f.lastFacing
      and step == f.lastStep and status == f.lastStatus then
    return
  end
  self.arrowDirty = false
  f.lastMap, f.lastX, f.lastY, f.lastFacing, f.lastStep, f.lastStatus = map, x, y, facing, step, status
  if map and x then
    local p = self.playerPos or {}
    p.map, p.x, p.y = map, x, y
    self.playerPos = p
  else
    self.playerPos = nil
  end
  self.playerWorld = ns.API.GetPlayerWorldPosition()
  local loc = a and a.step and a.step.loc
  if not ns.Config:Get("ui.showArrow") or not loc or (a.status == "done") then
    self:SetApproachHint(f, nil)
    f:Hide()
    return
  end
  -- Far away or on another continent: point at the next flight master, dock or portal instead (Engine/Travel.lua).
  local g = self.playerWorld and ns.Travel:Guidance(self.playerWorld, loc)
  if g then
    f:Show()
    self:DrawTravel(f, g, facing)
    return
  end
  self:ClearTravel(f)
  local pos = loc.cont ~= nil and self.playerWorld or self.playerPos
  if not pos then
    self:SetRouteLine(f, nil)
    f:Hide()
    return
  end
  f:Show()
  local elsewhere = (loc.cont ~= nil and pos.cont ~= loc.cont) or (loc.cont == nil and pos.map ~= loc.map)
  -- An approach (Engine/Approach.lua): follow its via points and say the hint (stairs, the floor, a detour).
  local ap = not elsewhere and loc.cont ~= nil and ns.Approach:Guidance(pos, a.step) or nil
  self:SetApproachHint(f, ap and ap.text)
  if ap and ap.point and not ns.Nav.InArea(pos, loc) then
    self:PointAt(f, pos, ap.point, facing, ap.remaining)
    return
  end
  if elsewhere then
    -- Different zone or continent: no angle, just tell the player where to go.
    f.tex:SetVertexColor(W.C.muted[1], W.C.muted[2], W.C.muted[3], 0.6)
    f.tex:SetRotation(0)
    local name = loc.map and ns.API.GetMapName(loc.map)
    if not name and loc.cont ~= nil then
      local targetMap = ns.API.WorldToMap(loc)
      name = targetMap and ns.API.GetMapName(targetMap)
    end
    f.lastYards = nil
    f.dist:SetText(name and string.format(L["Travel to %s"], name) or L["Different zone"])
    return
  end
  local angle = ns.Nav.RelativeAngle(pos, loc, facing)
  local d = ns.Nav.Distance(pos, loc)
  if ns.Nav.InArea(pos, loc) then
    -- among the targets already: the centre of their spawn area is not where to walk
    f.tex:SetRotation(0)
    f.tex:SetVertexColor(W.C.ok[1], W.C.ok[2], W.C.ok[3], 1)
    f.lastYards = nil
    f.dist:SetText(L["In the area"])
    return
  end
  local yards = d and math.floor(d + 0.5)
  if yards ~= f.lastYards then
    f.lastYards = yards
    f.dist:SetText(ns.Nav.FormatDistance(d))
  end
  if not angle then
    f.tex:SetRotation(0)
    f.tex:SetVertexColor(W.C.ok[1], W.C.ok[2], W.C.ok[3], 1)
    return
  end
  f.tex:SetRotation(angle)
  -- Green when roughly ahead, ember otherwise.
  local off = math.min(angle, 2 * math.pi - angle)
  local c = off < 0.35 and W.C.ok or W.C.ember
  f.tex:SetVertexColor(c[1], c[2], c[3], 1)
end

-- The arrow towards `point` (a via point of an approach), with the yards left along the whole way.
function UI:PointAt(f, pos, point, facing, yardsLeft)
  local d = yardsLeft or ns.Nav.Distance(pos, point)
  local yards = d and math.floor(d + 0.5)
  if yards ~= f.lastYards then
    f.lastYards = yards
    f.dist:SetText(ns.Nav.FormatDistance(d))
  end
  local angle = ns.Nav.RelativeAngle(pos, point, facing)
  if not angle then
    f.tex:SetRotation(0)
    f.tex:SetVertexColor(W.C.ok[1], W.C.ok[2], W.C.ok[3], 1)
    return
  end
  f.tex:SetRotation(angle)
  local off = math.min(angle, 2 * math.pi - angle)
  local c = off < 0.35 and W.C.ok or W.C.ember
  f.tex:SetVertexColor(c[1], c[2], c[3], 1)
end

-- The line under the arrow (a travel instruction or an approach hint); only touched when it changes.
function UI:SetRouteLine(f, text)
  if text == f.routeText then return end
  f.routeText = text
  if text then
    f.route:SetText(text)
    f.route:Show()
  else
    f.route:SetText("")
    f.route:Hide()
  end
end

function UI:SetApproachHint(f, text)
  self:SetRouteLine(f, text)
  if text ~= self.approachHint then
    self.approachHint = text
    self.dirty = true -- the main window shows the hint too
  end
end

-- The current step's approach (via point and hint), or nil (Engine/Approach.lua). Travel guidance comes first.
function UI:ApproachGuidance()
  local a = self.current
  local step = a and a.status ~= "done" and a.step
  local pos = self.playerWorld or ns.API.GetPlayerWorldPosition()
  if not step or not step.approach or not pos then return nil end
  if self:TravelGuidance() then return nil end
  return ns.Approach:Guidance(pos, step)
end

-- The travel plan for the current step, or nil when the arrow points straight at it (Engine/Travel.lua).
function UI:TravelGuidance()
  local a = self.current
  local loc = a and a.step and a.status ~= "done" and a.step.loc
  if not loc then return nil end
  local pos = self.playerWorld or ns.API.GetPlayerWorldPosition()
  if not pos then return nil end
  return ns.Travel:Guidance(pos, loc)
end

function UI:ClearTravel(f)
  if self.routeSummary then
    self.routeSummary = nil
    self.dirty = true -- the main window drops its route line
  end
end

-- Travel mode: the arrow points at the start of the plan's first travel leg; the text says what to do there.
function UI:DrawTravel(f, g, facing)
  local onTaxi = ns.API.OnTaxi and ns.API.OnTaxi()
  local text = onTaxi and L["In flight"] or g.text
  if self.approachHint then
    self.approachHint = nil
    self.dirty = true
  end
  self:SetRouteLine(f, text)
  if g.summary ~= self.routeSummary then
    self.routeSummary = g.summary
    self.dirty = true -- the main window shows the whole plan
  end
  local pos = self.playerWorld
  if onTaxi or not g.point then
    -- in the air, or a Hearthstone to use where the player stands: nothing to point at
    f.tex:SetRotation(0)
    f.tex:SetVertexColor(W.C.teal[1], W.C.teal[2], W.C.teal[3], 0.8)
    if f.lastYards ~= -1 then
      f.lastYards = -1
      f.dist:SetText("")
    end
    return
  end
  local d = ns.Nav.Distance(pos, g.point)
  local yards = d and math.floor(d + 0.5)
  if yards ~= f.lastYards then
    f.lastYards = yards
    f.dist:SetText(ns.Nav.FormatDistance(d))
  end
  local angle = ns.Nav.RelativeAngle(pos, g.point, facing)
  if not angle then
    f.tex:SetRotation(0)
    f.tex:SetVertexColor(W.C.ok[1], W.C.ok[2], W.C.ok[3], 1)
    return
  end
  f.tex:SetRotation(angle)
  local off = math.min(angle, 2 * math.pi - angle)
  local c = off < 0.35 and W.C.ok or W.C.ember
  f.tex:SetVertexColor(c[1], c[2], c[3], 1)
end
