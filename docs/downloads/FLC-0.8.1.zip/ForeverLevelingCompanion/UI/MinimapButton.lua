-- Minimap button (0.8.1, docs/release/BACKLOG_0.8.1.md, /flc minimap): left click shows or hides FLC's main window,
-- right click a quick menu that opens FLC's own windows (Guides, Loot Atlas, Party Mode, Appearance, Options, the bug
-- report), Shift + drag moves it around the minimap. Its angle and whether it is shown are account settings
-- (FLC_DB ui.minimap), the same for every character. Until the player moves it, it takes the first place around the
-- minimap that no other shown button covers (the minimap's own and other addons'), looked at again a moment after
-- login, when other addons have made theirs.
-- FLC's own button, no library: it follows the minimap's shape (GetMinimapShape, which square minimaps such as
-- ElvUI's define) and its size, round on a round minimap and flat on a square one, in the theme's colours. When
-- another addon has loaded LibDataBroker-1.1 (ElvUI's datatexts, Titan Panel...), FLC is also a launcher there.
local _, ns = ...
local W, L = ns.W, ns.L
local UI = ns.UI

local ICON = "Interface\\AddOns\\ForeverLevelingCompanion\\Media\\Arrow"
local ROUND_SIZE, FLAT_SIZE = 31, 24
local GAP = 4   -- between two buttons: a round button's ring is drawn a little outside its frame
UI.MINIMAP_ANGLE = 200

-- The corners of each minimap shape that are round (the names GetMinimapShape returns); a corner left out is square.
-- A TRICORNER is round but for the corner across from the one it names.
local ALL = { TL = true, TR = true, BL = true, BR = true }
UI.MINIMAP_SHAPES = {
  ROUND = ALL, SQUARE = {},
  ["CORNER-TOPLEFT"] = { TL = true }, ["CORNER-TOPRIGHT"] = { TR = true },
  ["CORNER-BOTTOMLEFT"] = { BL = true }, ["CORNER-BOTTOMRIGHT"] = { BR = true },
  ["SIDE-TOP"] = { TL = true, TR = true }, ["SIDE-BOTTOM"] = { BL = true, BR = true },
  ["SIDE-LEFT"] = { TL = true, BL = true }, ["SIDE-RIGHT"] = { TR = true, BR = true },
  ["TRICORNER-TOPLEFT"] = { TL = true, TR = true, BL = true }, ["TRICORNER-TOPRIGHT"] = { TL = true, TR = true, BR = true },
  ["TRICORNER-BOTTOMLEFT"] = { TL = true, BL = true, BR = true }, ["TRICORNER-BOTTOMRIGHT"] = { TR = true, BL = true, BR = true },
}

local function shape()
  local get = ns.env.GetMinimapShape
  local s = type(get) == "function" and get()
  return UI.MINIMAP_SHAPES[s or "ROUND"] or ALL, s == "SQUARE"
end

-- Where the button's centre goes for an angle (degrees, 0 = right, counter-clockwise), from the minimap's centre:
-- on the rim of a round corner; on the edge of a square one, inside it so it does not cover what borders the minimap.
function UI.MinimapOffset(angle, width, roundCorners)
  local a = math.rad(angle or UI.MINIMAP_ANGLE)
  local x, y = math.cos(a), math.sin(a)
  local corner = (y >= 0 and "T" or "B") .. (x < 0 and "L" or "R")
  local half = (width or 140) / 2
  if roundCorners[corner] then
    local r = half + 10
    return x * r, y * r
  end
  local r = half - FLAT_SIZE / 2
  local m = math.max(math.abs(x), math.abs(y))
  return x / m * r, y / m * r
end

-- The minimap's other buttons: shown frames of a button's size around it (its own children, those of its backdrop and
-- cluster), each as { x, y, radius } from the minimap's centre.
local function others(b, map)
  local out, seen = {}, { [b] = true, [map] = true }
  local mx, my = map:GetCenter()
  if not mx then return out end
  local ms = map:GetEffectiveScale()
  local function scan(parent)
    if not (parent and parent.GetChildren) then return end
    for _, c in ipairs({ parent:GetChildren() }) do
      if not seen[c] and c.IsShown and c:IsShown() and c.GetCenter then
        seen[c] = true
        local w = c:GetWidth() or 0
        local cx, cy = c:GetCenter()
        if cx and w > 8 and w <= 64 then
          local k = c:GetEffectiveScale() / ms
          out[#out + 1] = { x = cx * k - mx, y = cy * k - my, r = w * k / 2 }
        end
      end
    end
  end
  scan(map)
  scan(ns.env.MinimapBackdrop)
  scan(ns.env.MinimapCluster)
  return out
end

-- The first angle from the default, every 15 degrees, where the button covers no other button.
function UI:FreeMinimapAngle(map, corners)
  local list, half = others(self.minimapButton, map), (self.minimapButton:GetWidth() or ROUND_SIZE) / 2
  for i = 0, 23 do
    local angle = (self.MINIMAP_ANGLE + i * 15) % 360
    local x, y = UI.MinimapOffset(angle, map:GetWidth(), corners)
    local free = true
    for _, o in ipairs(list) do
      local dx, dy = x - o.x, y - o.y
      if math.sqrt(dx * dx + dy * dy) < half + o.r + GAP then free = false; break end
    end
    if free then return angle end
  end
  return self.MINIMAP_ANGLE
end

-- How many other buttons the button covers where it is now (none, on a free place).
function UI:MinimapOverlaps()
  local b, map = self.minimapButton, ns.env.Minimap
  if not (b and map and b.angle) then return 0 end
  local x, y = UI.MinimapOffset(b.angle, map:GetWidth(), (shape()))
  local n = 0
  for _, o in ipairs(others(b, map)) do
    local dx, dy = x - o.x, y - o.y
    if math.sqrt(dx * dx + dy * dy) < (b:GetWidth() or ROUND_SIZE) / 2 + o.r + GAP then n = n + 1 end
  end
  return n
end

function UI:PlaceMinimapButton()
  local b, map = self.minimapButton, ns.env.Minimap
  if not (b and map) then return end
  local corners, square = shape()
  local flat = square or not corners.TL and not corners.TR and not corners.BL and not corners.BR
  b.flat = flat
  local size = flat and FLAT_SIZE or ROUND_SIZE
  b:SetSize(size, size)
  for _, t in ipairs(b.roundParts) do if flat then t:Hide() else t:Show() end end
  for _, t in ipairs(b.flatParts) do if flat then t:Show() else t:Hide() end end
  b.icon:ClearAllPoints()
  b.icon:SetPoint("CENTER", b, "CENTER", 0, 0)
  b.icon:SetSize(flat and 16 or 18, flat and 16 or 18)
  local mm = ns.Config.settings.ui.minimap
  b.angle = mm.moved and mm.angle or self:FreeMinimapAngle(map, corners)
  local x, y = UI.MinimapOffset(b.angle, map:GetWidth(), corners)
  b:ClearAllPoints()
  b:SetPoint("CENTER", map, "CENTER", x, y)
end

-- The theme's colours: the flat look's background and edge, the icon in the accent.
function UI:StyleMinimapButton()
  local b = self.minimapButton
  if not b then return end
  b.icon:SetVertexColor(W.RGBA(W.C.ember))
  for _, t in ipairs(b.edges) do t:SetColorTexture(W.RGBA(W.C.line)) end
end

-- Shown or hidden as the setting says (Options, /flc minimap).
function UI:RefreshMinimapButton()
  local b = self.minimapButton
  if not b then return end
  if ns.Config:Get("ui.minimap.show") then
    self:PlaceMinimapButton()
    b:Show()
  else
    b:Hide()
    if self.minimapMenu then self.minimapMenu:Hide() end
  end
end

-- /flc minimap [show | hide]: without a word it switches.
function UI:SetMinimapButtonShown(show)
  if show == nil then show = not ns.Config:Get("ui.minimap.show") end
  ns.Config:Set("ui.minimap.show", show and true or false)
  self:RefreshMinimapButton()
  ns.API.Print(L["Minimap button"] .. ": " .. (show and L["shown"] or L["hidden"]))
end

-- What a click does, from the button or from a LibDataBroker display.
function UI:MinimapClick(owner, button)
  if button == "RightButton" then return self:ToggleMinimapMenu(owner) end
  if self.minimapMenu then self.minimapMenu:Hide() end
  self:TogglePanel("main")
end

-- movable false: a LibDataBroker display, whose own frame does not move around the minimap
function UI:MinimapTooltip(tt, movable)
  local p = ns.Session:Personal()
  local g = p.guideID and ns.Guide.guides[p.guideID]
  tt:AddLine("Forever Leveling Companion", W.RGBA(W.C.ember))
  if g then tt:AddLine(string.format(L["Following: %s"], UI.GuideTitle(g)), W.RGBA(W.C.text)) end
  tt:AddLine(L["Left click: show or hide FLC"], W.RGBA(W.C.muted))
  tt:AddLine(L["Right click: quick menu"], W.RGBA(W.C.muted))
  if movable ~= false then tt:AddLine(L["Shift + drag: move it around the minimap"], W.RGBA(W.C.muted)) end
  tt:AddLine(L["Hide it from Options or with /flc minimap"], W.RGBA(W.C.muted))
end

-- The quick menu: FLC's windows, each opened as its own button or command does. An entry whose module this build
-- lacks is not listed; one that cannot open now is greyed out and says why.
UI.MINIMAP_MENU = {
  { key = "guides", label = "Guides", open = function() UI:ShowGuides() end, has = function() return UI.ShowGuides end },
  { key = "atlas", label = "Loot Atlas", open = function() UI:ShowLootAtlas() end,
    has = function() return UI.ShowLootAtlas and ns.LootAtlas end,
    -- without loading the data: a loader registered, or data already built with dungeons in it
    why = function()
      local LT = ns.LootAtlas
      if LT.loader or (LT.data and next(LT.data.instances or {})) then return nil end
      return L["no loot data in this install"]
    end },
  { key = "party", label = "Party Mode", open = function() UI.party:Show(); UI:Refresh() end,
    has = function() return UI.party end },
  { key = "appearance", label = "Appearance", open = function() UI:ShowAppearance() end,
    has = function() return UI.ShowAppearance end },
  { key = "options", label = "Options", open = function() UI.options:Show(); UI:Refresh() end,
    has = function() return UI.options end },
  { key = "report", label = "Report a bug", open = function() UI:ShowReport(UI:ReviewReport()) end,
    has = function() return UI.ShowReport and UI.ReviewReport end },
}

function UI:BuildMinimapMenu()
  local f = W.Panel("FLC_MinimapMenu", nil, 176, 10)
  W.Dialog(f)
  f:SetFrameStrata("TOOLTIP")
  self.minimapMenu = f
  f.title = W.Text(f, 12, W.C.ember)
  f.title:SetPoint("TOPLEFT", 8, -6)
  f.title:SetText("FLC")
  f.buttons = {}
  f:SetScript("OnUpdate", function(self, elapsed)
    -- closes a moment after the pointer leaves it and the button (once it has been on them)
    local over = (self.IsMouseOver and self:IsMouseOver()) or (self.owner and self.owner.IsMouseOver and self.owner:IsMouseOver())
    if over then self.wasOver = true end
    self.away = (over or not self.wasOver) and 0 or (self.away or 0) + (elapsed or 0)
    if self.away > 2 then self:Hide() end
  end)
  f:Hide()
end

function UI:RefreshMinimapMenu()
  local f = self.minimapMenu
  local shown = 0
  for _, e in ipairs(self.MINIMAP_MENU) do
    if e.has() then
      shown = shown + 1
      local b = f.buttons[shown]
      if not b then
        b = W.Button(f, "", 160, 18, function(btn)
          if btn.why then return ns.API.Print(L[btn.entry.label] .. ": " .. btn.why) end
          f:Hide()
          btn.entry.open()
        end)
        f.buttons[shown] = b
      end
      b.entry, b.why = e, e.why and e.why() or nil
      b:SetLabel(b.why and W.Colorize(L[e.label] .. " (" .. b.why .. ")", W.C.muted) or L[e.label] .. "...")
      b:ClearAllPoints()
      b:SetPoint("TOPLEFT", f, "TOPLEFT", 8, -24 - (shown - 1) * 20)
      b:Show()
    end
  end
  for i = shown + 1, #f.buttons do f.buttons[i]:Hide() end
  f:SetHeight(30 + shown * 20)
end

function UI:ToggleMinimapMenu(owner)
  if not self.minimapMenu then self:BuildMinimapMenu() end
  local f = self.minimapMenu
  if f:IsShown() then return f:Hide() end
  if ns.env.GameTooltip then ns.env.GameTooltip:Hide() end
  self:RefreshMinimapMenu()
  f.owner, f.away, f.wasOver = owner, 0, false
  f:ClearAllPoints()
  if owner then f:SetPoint("TOPRIGHT", owner, "BOTTOMLEFT", 0, 0) else f:SetPoint("CENTER", ns.env.UIParent, "CENTER") end
  f:Show()
end

-- Follows the cursor around the minimap while dragged with Shift.
local function drag(b)
  local map, cursor = ns.env.Minimap, ns.env.GetCursorPosition
  if not (map and cursor) then return end
  local mx, my = map:GetCenter()
  local cx, cy = cursor()
  if not (mx and cx) then return end
  local scale = map:GetEffectiveScale()
  UI:SetMinimapAngle(math.deg(math.atan2(cy / scale - my, cx / scale - mx)))
end

-- Its place around the minimap, in degrees (a drag, /flctest minimap angle): kept in the account's settings, where it
-- stays; without an angle, back to the first free place (/flctest minimap angle free).
function UI:SetMinimapAngle(angle)
  local mm = ns.Config.settings.ui.minimap
  angle = tonumber(angle)
  mm.moved = angle ~= nil
  if angle then mm.angle = math.floor(angle % 360 * 10 + 0.5) / 10 end
  self:PlaceMinimapButton()
end

-- A moment after login and after each loading screen: other addons' buttons are there by then.
function UI:MinimapSoon() self.minimapAt = ns.API.Time() + 3 end
function UI:TickMinimap(now)
  if self.minimapAt and now >= self.minimapAt then
    self.minimapAt = nil
    self:RefreshMinimapButton()
  end
end

function UI:BuildMinimapButton()
  local map = ns.env.Minimap
  if not map then return end
  local b = ns.env.CreateFrame("Button", "FLC_MinimapButton", map)
  self.minimapButton = b
  b:SetFrameStrata("MEDIUM")
  b:SetFrameLevel((map.GetFrameLevel and map:GetFrameLevel() or 0) + 8)
  b:RegisterForClicks("LeftButtonUp", "RightButtonUp")
  b:RegisterForDrag("LeftButton")
  -- round: the game's minimap button look (background disc and ring), as the minimap's own buttons
  local disc = b:CreateTexture(nil, "BACKGROUND")
  disc:SetTexture("Interface\\Minimap\\UI-Minimap-Background")
  disc:SetSize(20, 20)
  disc:SetPoint("CENTER", b, "CENTER", 0, 0)
  local ring = b:CreateTexture(nil, "OVERLAY")
  ring:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder")
  ring:SetSize(53, 53)
  ring:SetPoint("TOPLEFT", b, "TOPLEFT", 0, 0)
  b.roundParts = { disc, ring }
  -- flat: the theme's background and a 1px edge, as FLC's windows
  local bg = W.Fill(b, W.C.bg)
  b.edges = {}
  for _, e in ipairs({ { "TOPLEFT", "TOPRIGHT", true }, { "BOTTOMLEFT", "BOTTOMRIGHT", true },
                       { "TOPLEFT", "BOTTOMLEFT" }, { "TOPRIGHT", "BOTTOMRIGHT" } }) do
    local t = b:CreateTexture(nil, "BORDER")
    t:SetPoint(e[1])
    t:SetPoint(e[2])
    if e[3] then t:SetHeight(1) else t:SetWidth(1) end
    b.edges[#b.edges + 1] = t
  end
  b.flatParts = { bg, b.edges[1], b.edges[2], b.edges[3], b.edges[4] }
  b.icon = b:CreateTexture(nil, "ARTWORK")
  b.icon:SetTexture(ICON)
  b:SetHighlightTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight")
  b:SetScript("OnClick", function(self, button)
    -- the click that ends a drag is not a click
    if self.dragEnd and ns.API.Time() - self.dragEnd < 0.3 then return end
    ns.Diag:Guard("ui:minimap", UI.MinimapClick, UI, self, button)
  end)
  b:SetScript("OnEnter", function(self)
    local tt = ns.env.GameTooltip
    if not tt or (UI.minimapMenu and UI.minimapMenu:IsShown()) then return end
    tt:SetOwner(self, "ANCHOR_LEFT")
    UI:MinimapTooltip(tt)
    tt:Show()
  end)
  b:SetScript("OnLeave", function() if ns.env.GameTooltip then ns.env.GameTooltip:Hide() end end)
  b:SetScript("OnDragStart", function(self)
    if not ns.API.ShiftDown() then return end
    self.dragging = true
    if ns.env.GameTooltip then ns.env.GameTooltip:Hide() end
    self:SetScript("OnUpdate", function(s) ns.Diag:Guard("ui:minimap-drag", drag, s) end)
  end)
  b:SetScript("OnDragStop", function(self)
    if not self.dragging then return end
    self.dragging = nil
    self:SetScript("OnUpdate", nil)
    self.dragEnd = ns.API.Time()
  end)
  -- a minimap resized by another interface: back on its edge
  if map.HookScript then map:HookScript("OnSizeChanged", function() ns.Diag:Guard("ui:minimap-size", UI.PlaceMinimapButton, UI) end) end
  self:StyleMinimapButton()
  self:RefreshMinimapButton()
  self:MinimapSoon()
  self:RegisterBroker()
end

-- A launcher for LibDataBroker displays, only when another addon already loaded the library (FLC does not ship it).
function UI:RegisterBroker()
  local stub = ns.env.LibStub
  local ldb = type(stub) == "table" and stub.GetLibrary and stub:GetLibrary("LibDataBroker-1.1", true)
  if not ldb or self.broker then return end
  self.broker = ldb:NewDataObject("ForeverLevelingCompanion", {
    type = "launcher", label = "FLC", icon = ICON,
    OnClick = function(frame, button) ns.Diag:Guard("ui:broker", UI.MinimapClick, UI, frame, button) end,
    OnTooltipShow = function(tt) ns.Diag:Guard("ui:broker-tooltip", UI.MinimapTooltip, UI, tt, false) end,
  })
end

ns.Bus:On("APPEARANCE_CHANGED", UI, function() UI:StyleMinimapButton() end)
