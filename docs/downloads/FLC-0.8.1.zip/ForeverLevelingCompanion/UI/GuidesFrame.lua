-- Guides window (0.8.1, docs/release/BACKLOG_0.8.1.md, /flc guides): the player chooses which guide to follow instead
-- of `/flc guide <id>`. Three tabs: leveling routes (by zone, the zone's visits together), dungeon guides and raid
-- guides, only those for this character (faction, race, class), each with its levels and how far the character is in
-- it. Follow switches to a route where the character stands in it and says how to get there; a dungeon or raid guide
-- starts from its way in, as from the dungeon's preparation. Automatic gives the choice back to FLC.
-- The list reads the guides' headers: a generated route is not built just to be listed (Engine/GuideEngine.lua).
local _, ns = ...
local W, L = ns.W, ns.L
local UI = ns.UI
local GE = ns.Guide

local WIDTH, HEIGHT, ROWS = 460, 410, 9
UI.GUIDE_TABS = { routes = "Routes", dungeons = "Dungeons", raids = "Raids" }

local function view()
  UI.guidesView = UI.guidesView or { tab = "routes", page = 0 }
  return UI.guidesView
end

-- The same checks as GE:SuggestGuide: a guide of the other faction, or for other races or classes, is not listed.
local function forCharacter(g, subject)
  if not subject then return true end
  local U = ns.U
  if g.faction and subject.faction and g.faction ~= subject.faction then return false end
  if g.races and subject.race and not U.contains(g.races, subject.race) then return false end
  if g.raceIDs and subject.raceID and not U.contains(g.raceIDs, subject.raceID) then return false end
  if g.classes and subject.class and not U.contains(g.classes, subject.class) then return false end
  return true
end

local function tabOf(g)
  if g.kind == "dungeon" then return g.raid and "raids" or "dungeons" end
  return "routes"
end

-- The guides of a tab for this character: { id, header, title, from, to }. Routes by zone, the zone with the lowest
-- level first and its visits in order; dungeons and raids by level.
function UI:GuideList(tab, subject)
  local list, zoneFrom = {}, {}
  for _, id in ipairs(GE.order) do
    local g = GE.guides[id]
    if g and tabOf(g) == tab and forCharacter(g, subject) then
      local lr = g.levelRange or {}
      local e = { id = id, header = g, title = UI.GuideTitle(g), from = lr[1], to = lr[2], visit = g.visit or 1,
        zone = tostring(g.zone or g.title or id) }
      list[#list + 1] = e
      local from = e.from or 99
      if not zoneFrom[e.zone] or from < zoneFrom[e.zone] then zoneFrom[e.zone] = from end
    end
  end
  table.sort(list, function(a, b)
    if tab == "routes" and a.zone ~= b.zone then
      if zoneFrom[a.zone] ~= zoneFrom[b.zone] then return zoneFrom[a.zone] < zoneFrom[b.zone] end
      return a.zone < b.zone
    end
    if tab == "routes" and a.visit ~= b.visit then return a.visit < b.visit end
    if (a.from or 99) ~= (b.from or 99) then return (a.from or 99) < (b.from or 99) end
    return a.title < b.title
  end)
  return list
end

-- How far the character is in a guide: the guide followed now counts its done steps; another one says the step its
-- saved cursor is on, out of the route's steps (a generated route's header has its count), without building it.
function UI:GuideProgress(e, p, subject)
  local g = e.header
  if p.guideID == e.id and subject and not g._loader and g.steps then
    local done, total = GE:Progress(g, p, subject, ns.Session.ctx)
    return string.format(L["%d of %d steps done"], done, total)
  end
  local c = p.cursors[e.id]
  if not c then return L["not started"] end
  local total = (g.steps and #g.steps) or g.stepCount
  local at = (c.stepID and g.index and g.index[c.stepID]) or tonumber(c.index) or 1
  if not total then return L["started"] end
  if at > total then return L["finished"] end
  return string.format(L["at step %d of %d"], at, total)
end

-- Follows a guide (the window's Follow, /flc guide <id>). A route: from where the character stands in it (its saved
-- cursor, else the first step not done yet); a dungeon or raid guide: from its way in. Then says how to get there
-- when it starts far away.
function UI:ChooseGuide(id)
  local header = GE.guides[id]
  if header and header.kind == "dungeon" then
    if not ns.DungeonGuide:Start(header.dungeon) then return false end
    self:Toast(L["Dungeon guide started: Back to route when you are done"])
  else
    local g = GE:Get(id)
    if not g then
      ns.API.Print(string.format(L["Unknown guide: %s"], tostring(id)))
      return false
    end
    local p = ns.Session:Personal()
    p.guideID, p.dungeonReturn = g.id, nil
    if not p.cursors[g.id] and ns.Session.selfState then
      local i, step = GE:FindResumePoint(g, p, ns.Session.selfState, ns.Session.ctx)
      p.cursors[g.id] = { index = i, stepID = step and step.id }
    end
  end
  ns.Party:BroadcastState()
  self:Refresh()
  local g = GE:Get(id)
  ns.API.Print(L["Guide"] .. ": " .. (g and string.format("%s (%s)", UI.GuideTitle(g), g.id) or "-"))
  local route = self:TravelGuidance()
  if route then ns.API.Print(L["How to get there"] .. ": " .. route.summary) end
  return true
end

-- Back to FLC's choice by level and place (/flc guide auto): the progress in every guide is kept.
function UI:AutoGuide()
  local p = ns.Session:Personal()
  p.guideID, p.dungeonReturn = nil, nil
  if ns.Session.selfState then ns.Session:SetSelfState(ns.Session.selfState) end
  ns.Party:BroadcastState()
  self:Refresh()
end

function UI:BuildGuides()
  local f = W.Panel("FLC_GuidesFrame", nil, WIDTH, HEIGHT)
  W.Dialog(f)
  self.guidesFrame = f
  W.Movable(f, "guides", { "CENTER", "CENTER", 0, 40 })
  f.title = W.Text(f, 13, W.C.ember)
  f.title:SetPoint("TOPLEFT", 8, -7)
  f.title:SetText(L["Guides"])
  f.close = W.Button(f, "x", 18, 16, function() f:Hide() end)
  f.close:SetPoint("TOPRIGHT", -4, -4)
  f.auto = W.Button(f, L["Automatic"], 76, 16, function() UI:AutoGuide() end, W.C.teal)
  f.auto:SetPoint("RIGHT", f.close, "LEFT", -6, 0)
  f.tabs = {}
  local last
  for _, tab in ipairs({ "routes", "dungeons", "raids" }) do
    local b = W.Button(f, L[UI.GUIDE_TABS[tab]], 70, 18, function()
      local v = view()
      v.tab, v.page = tab, 0
      UI:RefreshGuides()
    end, W.C.teal)
    if last then b:SetPoint("LEFT", last, "RIGHT", 4, 0) else b:SetPoint("TOPLEFT", 70, -5) end
    f.tabs[tab], last = b, b
  end
  -- the guide followed now
  f.current = W.Text(f, 11, W.C.muted)
  f.current:SetPoint("TOPLEFT", 8, -30)
  f.current:SetPoint("RIGHT", f, "RIGHT", -8, 0)
  f.current:SetWordWrap(false)
  f.rows = W.RowPool(f, 34, function(parent)
    local r = ns.env.CreateFrame("Frame", nil, parent)
    r.name = W.Text(r, 12, W.C.text)
    r.name:SetPoint("TOPLEFT", 0, 0)
    r.name:SetPoint("RIGHT", -84, 0)
    r.name:SetWordWrap(false)
    r.info = W.Text(r, 10, W.C.muted)
    r.info:SetPoint("TOPLEFT", r.name, "BOTTOMLEFT", 0, -2)
    r.info:SetPoint("RIGHT", -84, 0)
    r.info:SetWordWrap(false)
    r.follow = W.Button(r, L["Follow"], 78, 18, function() if r.id and not r.current then UI:ChooseGuide(r.id) end end, W.C.ok)
    r.follow:SetPoint("TOPRIGHT", 0, 0)
    return r
  end)
  f.prev = W.Button(f, "<", 20, 16, function() local v = view(); v.page = math.max(0, v.page - 1); UI:RefreshGuides() end)
  f.next = W.Button(f, ">", 20, 16, function() local v = view(); v.page = v.page + 1; UI:RefreshGuides() end)
  f.next:SetPoint("BOTTOMRIGHT", -8, 6)
  f.prev:SetPoint("RIGHT", f.next, "LEFT", -4, 0)
  f.count = W.Text(f, 10, W.C.muted)
  f.count:SetPoint("RIGHT", f.prev, "LEFT", -6, 0)
  f.note = W.Text(f, 9, W.C.muted)
  f.note:SetPoint("BOTTOMLEFT", 8, 8)
  f.note:SetText(L["Your progress in each guide is kept when you switch."])
  f:Hide()
end

-- Opens the window on the tab of the guide followed now.
function UI:ShowGuides()
  if not self.guidesFrame then self:BuildGuides() end
  local p = ns.Session:Personal()
  local g = p.guideID and GE.guides[p.guideID]
  local v = view()
  if g then v.tab = tabOf(g) end
  v.page = 0
  self.guidesFrame:Show()
  self:RefreshGuides()
end

function UI:RefreshGuides()
  local f = self.guidesFrame
  if not f or not f:IsShown() then return end
  local v, subject, p = view(), ns.Session.selfState, ns.Session:Personal()
  for tab, b in pairs(f.tabs) do
    b:SetLabel(tab == v.tab and W.Colorize(L[UI.GUIDE_TABS[tab]], W.C.ok) or L[UI.GUIDE_TABS[tab]])
  end
  local cur = p.guideID and GE.guides[p.guideID]
  f.current:SetText(cur and string.format(L["Following: %s"], UI.GuideTitle(cur)) or L["Following: none (FLC picks it by your level and place)"])
  local seg = subject and ns.Path and ns.Path:Suggest(subject)
  local list = self:GuideList(v.tab, subject)
  local pages = math.max(1, math.ceil(#list / ROWS))
  v.page = math.min(v.page, pages - 1)
  local shown = 0
  for i = 1, ROWS do
    local e = list[v.page * ROWS + i]
    if not e then break end
    shown = i
    local r = f.rows:Get(i)
    r.id, r.current = e.id, p.guideID == e.id
    r.name:SetText(r.current and W.Colorize(e.title, W.C.ok) or e.title)
    local parts = {}
    if e.from and e.to then
      local text = string.format(L["levels %d-%d"], e.from, e.to)
      local low = subject and subject.level and subject.level < e.from
      parts[#parts + 1] = low and W.Colorize(text, W.C.warn) or text
    end
    parts[#parts + 1] = self:GuideProgress(e, p, subject)
    if seg and seg.guide == e.id then parts[#parts + 1] = W.Colorize(L["suggested for your level"], W.C.teal) end
    r.info:SetText(table.concat(parts, " · "))
    local start = e.header.kind == "dungeon" and L["Start"] or L["Follow"]
    r.follow:SetLabel(r.current and W.Colorize(L["Following"], W.C.muted) or start)
    r:ClearAllPoints()
    r:SetPoint("TOPLEFT", f, "TOPLEFT", 8, -50 - (i - 1) * 36)
    r:SetPoint("RIGHT", f, "RIGHT", -8, 0)
  end
  f.rows:HideFrom(shown + 1)
  f.count:SetText(#list == 0 and L["No guide of this kind for this character"]
    or string.format(L["%d guides · page %d/%d"], #list, v.page + 1, pages))
end
