-- Party Mode panel: members, consent, Help Player, group modes, requests, proposals and insights.
local _, ns = ...
local W, L, U = ns.W, ns.L, ns.U
local UI = ns.UI

local WIDTH = 330
local ROW_H = 30

local SYNC_COLOR = {
  synced = W.C.ok, pending = W.C.warn, stale = W.C.warn, declined = W.C.muted,
  none = W.C.muted, incompatible = W.C.bad, offline = W.C.bad, left = W.C.bad,
}

local function memberRow(parent)
  local r = ns.env.CreateFrame("Frame", nil, parent)
  r:SetWidth(WIDTH - 16)
  r.bg = W.Fill(r, { 1, 1, 1, 0.03 })
  r.dot = W.Text(r, 12, W.C.muted)
  r.dot:SetPoint("TOPLEFT", 4, -3)
  r.name = W.Text(r, 12, W.C.text)
  r.name:SetPoint("TOPLEFT", 16, -3)
  r.name:SetWidth(170)
  r.name:SetWordWrap(false)
  r.info = W.Text(r, 10, W.C.muted)
  r.info:SetPoint("TOPLEFT", 16, -17)
  r.info:SetWidth(220)
  r.info:SetWordWrap(false)
  r.help = W.Button(r, L["Help"], 62, 18, function(self) UI:HelpMember(self:GetParent().key) end, W.C.teal)
  r.help:SetPoint("RIGHT", -4, 0)
  return r
end

local function lineRow(parent)
  local r = ns.env.CreateFrame("Frame", nil, parent)
  r:SetWidth(WIDTH - 16)
  r.text = W.Text(r, 11, W.C.text)
  r.text:SetPoint("LEFT", 2, 0)
  r.text:SetPoint("RIGHT", -132, 0)
  r.text:SetWordWrap(false)
  r.b1 = W.Button(r, "", 62, 18, function(self) if self.action then self.action() end end, W.C.ok)
  r.b1:SetPoint("RIGHT", -66, 0)
  r.b2 = W.Button(r, "", 62, 18, function(self) if self.action then self.action() end end, W.C.bad)
  r.b2:SetPoint("RIGHT", -2, 0)
  return r
end

function UI:BuildParty()
  local f = W.Panel("FLC_PartyFrame", nil, WIDTH, 300)
  self.party = f
  W.Movable(f, "party", { "TOPRIGHT", "TOPRIGHT", -530, -220 })
  f.title = W.Text(f, 13, W.C.teal)
  f.title:SetPoint("TOPLEFT", 8, -8)
  f.title:SetText(L["PARTY MODE"])
  f.close = W.Button(f, "x", 18, 16, function() f:Hide() end)
  f.close:SetPoint("TOPRIGHT", -4, -4)
  f.preset = W.Button(f, "", 140, 16, function() UI:CyclePreset() end, W.C.teal)
  f.preset:SetPoint("TOPRIGHT", -26, -4)

  f.consent = lineRow(f)
  f.consent:SetHeight(22)
  f.members = W.RowPool(f, ROW_H, memberRow)
  f.lines = W.RowPool(f, 22, lineRow)

  f.actions = {}
  local defs = {
    { L["Level together"], function() UI:StartGroup("together") end },
    { L["Group catch-up"], function() UI:StartGroup("catchup") end },
    { L["Find dungeon"], function() UI:ShowDungeons() end },
    { L["Return to my guide"], function() UI:ReturnToGuide() end },
  }
  for i, d in ipairs(defs) do
    f.actions[i] = W.Button(f, d[1], (WIDTH - 22) / 2, 20, d[2], i == 4 and W.C.ember or W.C.teal)
  end
  f.notes = W.Text(f, 10, W.C.muted)
  f.notes:SetWidth(WIDTH - 16)
  f:Hide()
end

function UI:CyclePreset()
  local list = ns.Config.PRESETS
  local cur = ns.Config:Get("party.preset")
  local idx = 1
  for i, p in ipairs(list) do if p == cur then idx = i end end
  ns.Config:Set("party.preset", list[idx % #list + 1])
  self:Refresh()
end

function UI:HelpMember(key)
  local m = ns.Party:Get(key)
  if not m then return end
  local session, err = ns.Session:StartHelp(key)
  if not session then
    self:Toast(L["Could not start help: "] .. tostring(err))
    return
  end
  if #session.route.quests == 0 then
    self.pickerFor = key
    self:Toast(string.format(L["No known quests for %s: pick one below"], m.name))
  else
    self.pickerFor = nil
    self:Toast(string.format(L["Helping %s - your progress is saved"], m.name))
  end
  self:Refresh()
end

function UI:StartGroup(kind)
  local preset = ns.Config:Get("party.preset")
  local session
  if ns.Party:Leader() == ns.selfKey and ns.Party:Size() > 1 then
    session = ns.Session:ProposeGroupRoute(kind, preset)
    if session then self:Toast(L["Route proposed to the group; members must accept it"]) end
  else
    session = ns.Session:StartGroup(kind, preset)
  end
  if session and #session.route.steps == 0 then
    self:Toast(L["No shared quests found with the data available"])
  end
  self.dungeons = nil
  self:Refresh()
end

function UI:ShowDungeons()
  local members = ns.Session:GroupMembers()
  local faction = ns.Session.selfState and ns.Session.selfState.faction
  self.dungeons = ns.Route.RecommendDungeons(members, faction)
  self:Refresh()
end

-- Quest picker for members whose progress we cannot read.
local function pickerQuests()
  local list, seen = {}, {}
  local st = ns.Session.selfState
  if st then for qid in pairs(st.log) do if not seen[qid] then seen[qid] = true; list[#list + 1] = qid end end end
  local p = ns.Session:Personal()
  local g = p.guideID and ns.Guide:Get(p.guideID)
  if g then
    local c = ns.Guide:Cursor(p, g)
    for i = math.max(1, c.index - 20), math.min(#g.steps, c.index + 10) do
      local q = g.steps[i].quest
      if q and not seen[q] then seen[q] = true; list[#list + 1] = q end
    end
  end
  return list
end

function UI:RefreshParty()
  local f = self.party
  local preset = ns.Config:Get("party.preset")
  f.preset:SetLabel(L["Preset"] .. ": " .. L[ns.Route.PRESETS[preset].label])
  local y = -28
  local lineIdx = 0
  local function line(text, b1, a1, b2, a2)
    lineIdx = lineIdx + 1
    local r = f.lines:Get(lineIdx)
    r:ClearAllPoints()
    r:SetPoint("TOPLEFT", 8, y)
    r.text:SetText(text)
    r.b1:SetLabel(b1 or ""); r.b1.action = a1
    r.b2:SetLabel(b2 or ""); r.b2.action = a2
    if b1 then r.b1:Show() else r.b1:Hide() end
    if b2 then r.b2:Show() else r.b2:Hide() end
    y = y - 24
  end

  local members = ns.Party:List()
  local anyAddon = false
  for _, m in ipairs(members) do if m.hasAddon then anyAddon = true end end
  if ns.Party:GetShare() == nil and anyAddon then
    line(L["Share your quest progress with this party?"],
      L["Share"], function() ns.Party:SetShare(true); UI:Refresh() end,
      L["No"], function() ns.Party:SetShare(false); UI:Refresh() end)
  end

  for _, req in ipairs(ns.Party.requests) do
    local m = ns.Party:Get(req.from)
    if m then
      line(string.format(L["%s asks for help"], m.name),
        L["Help"], function() UI:HelpMember(req.from) end,
        L["Dismiss"], function()
          for i = #ns.Party.requests, 1, -1 do if ns.Party.requests[i] == req then table.remove(ns.Party.requests, i) end end
          UI:Refresh()
        end)
    end
  end
  for id, p in pairs(ns.Party.proposals) do
    if p.status == "pending" then
      line(string.format(L["Leader proposes: %s (%d quests)"], L[ns.Session.KIND_LABEL[p.mode] or p.mode], #p.quests),
        L["Accept"], function() ns.Session:AcceptProposal(id); UI:Refresh() end,
        L["Decline"], function() ns.Session:DeclineProposal(id); UI:Refresh() end)
    end
  end

  -- Members (self first)
  local rowIdx = 0
  local function memberLine(key, name, class, level, infoText, dot, dotColor, canHelp)
    rowIdx = rowIdx + 1
    local r = f.members:Get(rowIdx)
    r.key = key
    r:ClearAllPoints()
    r:SetPoint("TOPLEFT", 8, y)
    r.name:SetText(W.Colorize(name, W.ClassColor(class)) .. "  " .. W.Colorize(string.format(L["Level %s"], level or "?"), W.C.muted))
    r.info:SetText(infoText)
    r.dot:SetText(W.Dot(dotColor))
    if canHelp then r.help:Show() else r.help:Hide() end
    local session = ns.Session:GetSession()
    if session and session.kind == "help" and session.target == key then r.help:SetLabel(L["Helping"]) else r.help:SetLabel(L["Help"]) end
    y = y - ROW_H - 2
  end
  local me = ns.Session.selfState
  if me then
    local d = ns.Session:DescribeSelf()
    local info = d.guideID and string.format(L["Step %d/%d"], d.index or 0, d.total or 0) or L["No guide"]
    memberLine(ns.selfKey, me.name or "?", me.class, me.level, info .. "  ·  " .. string.format(L["%d quests"], U.count(me.log)), nil, W.C.ember, false)
  end
  for _, m in ipairs(members) do
    local parts = {}
    if m.map then parts[#parts + 1] = ns.API.GetMapName(m.map) or ("map " .. m.map) end
    if m.guide and m.guide.total and m.guide.total > 0 then
      parts[#parts + 1] = string.format(L["Step %d/%d"], m.guide.index or 0, m.guide.total)
    end
    if m.state.logKnown then parts[#parts + 1] = string.format(L["%d quests"], U.count(m.state.log))
    else parts[#parts + 1] = L["quests: unknown"] end
    local state = m.connected and m.syncState or "offline"
    parts[#parts + 1] = W.Colorize(L[ns.Party.SYNC[state] or state], SYNC_COLOR[state] or W.C.muted)
    memberLine(m.key, m.name, m.class, m.level, table.concat(parts, "  ·  "),
      nil, m.hasAddon and W.C.teal or W.C.muted, true)
  end
  f.members:HideFrom(rowIdx + 1)

  -- Manual quest picker (member without data)
  if self.pickerFor and ns.Party:Get(self.pickerFor) then
    local target = ns.Party:Get(self.pickerFor)
    for _, qid in ipairs(pickerQuests()) do
      if lineIdx >= 14 then break end
      line(ns.Quest:Name(qid, ns.Session.selfState), L["Has it"], function()
        ns.Party:SetManualQuest(target.key, qid, true)
        ns.Session:Recalculate()
        UI:Refresh()
      end)
    end
  end

  -- Dungeon recommendations
  if self.dungeons then
    for i = 1, math.min(3, #self.dungeons) do
      local d = self.dungeons[i]
      local notes = {}
      for _, n in ipairs(d.notes) do notes[#notes + 1] = L[n] end
      line(string.format("%s (%d-%d) %s", L[d.dungeon.name], d.dungeon.minLevel, d.dungeon.maxLevel, table.concat(notes, ", ")))
    end
    if #self.dungeons == 0 then line(L["No dungeon fits this group's levels"]) end
  end
  f.lines:HideFrom(lineIdx + 1)

  -- Actions
  y = y - 4
  for i, b in ipairs(f.actions) do
    b:ClearAllPoints()
    local col = (i - 1) % 2
    local row = math.floor((i - 1) / 2)
    b:SetPoint("TOPLEFT", 8 + col * ((WIDTH - 22) / 2 + 6), y - row * 24)
  end
  local session = ns.Session:GetSession()
  if session then f.actions[4]:Show() else f.actions[4]:Hide() end
  y = y - 52

  -- Insights
  local myMap = UI.playerPos and UI.playerPos.map
  local cur = UI.current and UI.current.step and UI.current.step.quest
  local notes = {}
  for _, ins in ipairs(ns.Insights:Compute(myMap, cur)) do
    notes[#notes + 1] = (ins.basis == "estimate" and "~ " or "- ") .. ins.text
    if #notes >= 5 then break end
  end
  if #members == 0 then notes[#notes + 1] = L["Join a party to use Party Mode"] end
  f.notes:ClearAllPoints()
  f.notes:SetPoint("TOPLEFT", 8, y)
  f.notes:SetText(table.concat(notes, "\n"))
  f:SetHeight(-y + #notes * 13 + 12)
end
