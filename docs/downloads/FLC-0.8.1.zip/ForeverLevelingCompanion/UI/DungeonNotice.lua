-- Leveling modes (Engine/Modes.lua) in the main window: the dungeon notice ("Dungeon worth a visit: Wailing Caverns,
-- 4 quests to do, first visit, ~3,100-6,800 XP") with Quests / Prepare / Group / Later / Skip, and while a dungeon is
-- being prepared (Engine/DungeonAdvisor.lua) "Preparing Wailing Caverns: 2 to pick up" with Steps / Waypoint / Route.
-- The route under it goes on: nothing here waits for a group. Quests only shows no notice (a preparation the player
-- started still shows).
local _, ns = ...
local W, L = ns.W, ns.L
local UI = ns.UI
local MO = ns.Modes
local DA = ns.DungeonAdvisor

UI.DUNGEON_REFRESH = 5     -- seconds between dungeon checks for the notice (the main window refreshes far more often)

-- The suggestion for the notice, or nil; worked out again every few seconds or after a change (level, mode, a
-- decision, a quest turned in).
function UI:DungeonNotice()
  local subject = ns.Session.selfState
  if not subject or ns.Session:GetSession() then return nil end
  local now = ns.Now()
  local c = self.dungeonNoticeCache
  if c and now - c.at < UI.DUNGEON_REFRESH and c.level == subject.level then return c.pick, c.ev end
  local pick = MO:Dungeon(subject)
  local ev = pick and DA:Evaluate(subject, pick.dungeon)
  self.dungeonNoticeCache = { pick = pick, ev = ev, at = now, level = subject.level }
  return pick, ev
end
local function dropCache() UI.dungeonNoticeCache = nil; UI.dungeonPlanCache = nil end
ns.Bus:On("LEVELING_MODE_CHANGED", UI, function() dropCache(); UI:Refresh() end)
ns.Bus:On("TRACKER_QUEST_TURNED_IN", UI, dropCache)
ns.Bus:On("TRACKER_QUEST_ADDED", UI, dropCache)
ns.Bus:On("DUNGEON_PREP_CHANGED", UI, function() dropCache(); UI:Refresh() end)

function UI:DungeonDecide(id, what)
  if id == nil then return end
  local subject = ns.Session.selfState
  MO:Decide(id, what, subject and subject.level)
  self.dungeonNoticeCache = nil
  self:Refresh()
end

-- "~3100 XP" or "~3100-6800 XP": the quests' XP at the character's level (a range when the Forever bonus is not
-- confirmed for some of them); nil without data
function UI.DungeonXPText(ev)
  if not ev or ev.xpMax <= 0 then return nil end
  if ev.xpMin == ev.xpMax then return string.format(L["~%d XP"], ev.xpMin) end
  return string.format(L["~%d-%d XP"], ev.xpMin, ev.xpMax)
end

-- The dungeon's quests the character can do now, in chat (pick them up before going in).
function UI:DungeonQuests(id)
  local subject = ns.Session.selfState
  if id == nil or not subject then return end
  for _, d in ipairs(ns.Route.dungeons) do
    if d.id == id then
      local names = {}
      for _, qid in ipairs(ns.Route.DungeonQuests(d)) do
        if ns.Quest:IsPending((ns.Quest:Availability(subject, qid))) then
          names[#names + 1] = ns.Quest:Name(qid, subject) or ("#" .. qid)
        end
      end
      -- the ranges are approximate (Data/Dungeons.lua): "~" says so
      ns.API.Print(string.format(L["%s (levels ~%d-%d): quests you can do: %s"], L[d.name] or d.name, d.minLevel,
        d.maxLevel, table.concat(names, ", ")))
      return
    end
  end
end

-- Prepare: the preparation starts and its window opens.
function UI:DungeonPrepare(id)
  if id == nil then return end
  local subject = ns.Session.selfState
  DA:Prepare(id, subject and subject.level)
  self:ShowDungeonPrep()
end

-- Group: the game's own group finder; FLC never searches or queues.
function UI:DungeonGroup()
  self.lastGroupFinder = ns.API.OpenGroupFinder() or false
  if not self.lastGroupFinder then
    self:Toast(L["Open the game's group finder, or play it with your party"])
  end
end

-- The dungeon guide (Engine/DungeonGuide.lua) of the dungeon being prepared becomes the active guide.
function UI:StartDungeonGuide(id)
  id = id or (DA:Preparing() or {}).id
  if ns.DungeonGuide:Start(id) then
    if self.dungeonPrep then self.dungeonPrep:Hide() end
    self:Toast(L["Dungeon guide started: Back to route when you are done"])
    self:Refresh()
  end
end

-- Back to the normal route: the preparation ends.
function UI:DungeonEndPrep()
  DA:EndPrep()
  ns.DungeonGuide:End()
  if self.dungeonPrep then self.dungeonPrep:Hide() end
  self:Toast(L["Back on your route"])
end

-- The plan of the dungeon being prepared, worked out again every few seconds; nil when none is being prepared.
-- When nothing is left to do there, the preparation ends by itself and the route goes on.
function UI:DungeonPlan()
  local prep, subject = DA:Preparing(), ns.Session.selfState
  if not prep or not subject then return nil end
  local now = ns.Now()
  local c = self.dungeonPlanCache
  if c and c.id == prep.id and now - c.at < UI.DUNGEON_REFRESH then return c.plan end
  local plan = DA:Steps(subject, prep.id)
  self.dungeonPlanCache = { id = prep.id, plan = plan, at = now }
  if plan and plan.done then
    DA:EndPrep()
    self:Toast(string.format(L["%s: nothing left to do there, back on your route"], L[plan.dungeon.name] or plan.dungeon.name))
    return nil
  end
  return plan
end

function UI:DungeonWaypoint()
  local plan = self:DungeonPlan()
  local s = DA.NextPlace(plan)
  if not s then self:Toast(L["No place known for the next step"]); return end
  local title = s.kind == "entrance" and string.format(L["%s: entrance"], L[plan.dungeon.name] or plan.dungeon.name)
    or string.format("%s: %s", ns.Quest:Name(s.quest, ns.Session.selfState) or ("#" .. s.quest), s.giver or "?")
  local map, x, y = ns.API.WorldToMap(s.loc)
  local used = map and ns.API.SetWaypoint(map, x, y, title, ns.Config:Get("nav.waypointProvider") or "auto")
  if not used then self:Toast(L["No waypoint provider available; follow the FLC arrow"]) end
end

function UI:CycleLevelingMode()
  local mode = MO:Cycle()
  ns.API.Print(L["Leveling mode"] .. ": " .. L[MO.LABEL[mode]])
  self:Refresh()
end

-- Builds the notice inside the main window (called from UI:BuildMain).
function UI:BuildDungeonNotice(f)
  local n = ns.env.CreateFrame("Frame", nil, f)
  n:SetHeight(40)
  n:SetPoint("LEFT", 2, 0)
  n:SetPoint("RIGHT", 0, 0)
  n.bg = W.Fill(n, { W.C.teal[1], W.C.teal[2], W.C.teal[3], 0.14 })
  n.text = W.Text(n, 11, W.C.text)
  n.text:SetPoint("TOPLEFT", 8, -3)
  n.text:SetPoint("RIGHT", -6, 0)
  n.text:SetWordWrap(false)
  -- the suggestion
  n.quests = W.Button(n, L["Quests"], 52, 16, function() UI:DungeonQuests(n.id) end, W.C.teal)
  n.prep = W.Button(n, L["Prepare"], 58, 16, function() UI:DungeonPrepare(n.id) end, W.C.ok)
  n.group = W.Button(n, L["Group"], 48, 16, function() UI:DungeonGroup() end)
  n.later = W.Button(n, L["Later"], 46, 16, function() UI:DungeonDecide(n.id, "later") end)
  n.skip = W.Button(n, L["Skip it"], 48, 16, function() UI:DungeonDecide(n.id, "skip") end, W.C.ember)
  n.quests:SetPoint("BOTTOMLEFT", 8, 3)
  n.prep:SetPoint("LEFT", n.quests, "RIGHT", 3, 0)
  n.group:SetPoint("LEFT", n.prep, "RIGHT", 3, 0)
  n.later:SetPoint("LEFT", n.group, "RIGHT", 3, 0)
  n.skip:SetPoint("LEFT", n.later, "RIGHT", 3, 0)
  -- the preparation
  n.steps = W.Button(n, L["Steps"], 52, 16, function() UI:ShowDungeonPrep() end, W.C.teal)
  n.way = W.Button(n, L["Waypoint"], 64, 16, function() UI:DungeonWaypoint() end)
  n.route = W.Button(n, L["Back to route"], 86, 16, function() UI:DungeonEndPrep() end, W.C.ember)
  n.steps:SetPoint("BOTTOMLEFT", 8, 3)
  n.way:SetPoint("LEFT", n.steps, "RIGHT", 3, 0)
  n.route:SetPoint("LEFT", n.way, "RIGHT", 3, 0)
  n.guide = W.Button(n, L["Guide"], 48, 16, function() UI:StartDungeonGuide(n.id) end, W.C.ok)
  n.guide:SetPoint("LEFT", n.route, "RIGHT", 3, 0)
  n:Hide()
  f.dungeonNotice = n
end

local function showButtons(n, preparing)
  for _, k in ipairs({ "quests", "prep", "group", "later", "skip" }) do
    if preparing then n[k]:Hide() else n[k]:Show() end
  end
  for _, k in ipairs({ "steps", "way", "route" }) do
    if preparing then n[k]:Show() else n[k]:Hide() end
  end
  -- the dungeon guide, when the pack has one and it is not running yet
  if preparing and ns.DungeonGuide:For(n.id) and not ns.DungeonGuide:Active() then n.guide:Show() else n.guide:Hide() end
end

-- Shows or hides the notice; returns the height it takes.
function UI:RefreshDungeonNotice(f, top)
  local n = f.dungeonNotice
  if not n then return 0 end
  local plan = not ns.Session:GetSession() and self:DungeonPlan()
  if plan then
    local ev = plan.ev
    n.id = plan.dungeon.id
    n.preparing = true
    local parts, pick, inside = {}, 0, 0
    for _, s in ipairs(plan.steps) do
      if s.kind == "pickup" then pick = pick + 1 elseif s.kind == "inside" then inside = inside + 1 end
    end
    if pick > 0 then parts[#parts + 1] = string.format(L["%d to pick up"], pick) end
    if inside > 0 then parts[#parts + 1] = string.format(L["%d start inside"], inside) end
    if #ev.inLog > 0 then parts[#parts + 1] = string.format(L["%d in your log"], #ev.inLog) end
    n.text:SetText(string.format("%s %s: %s", W.Colorize(L["Preparing"], W.C.ok), L[plan.dungeon.name] or plan.dungeon.name,
      table.concat(parts, ", ")))
    showButtons(n, true)
  else
    local pick, ev = self:DungeonNotice()
    if not pick then
      n:Hide()
      n.id, n.preparing = nil, nil
      return 0
    end
    local d = pick.dungeon
    n.id, n.preparing = d.id, nil
    local what = pick.pending == 1 and L["1 quest to do"] or string.format(L["%d quests to do"], pick.pending)
    if pick.firstVisit then what = what .. ", " .. L["first visit"] end
    local xp = UI.DungeonXPText(ev)
    if xp then what = what .. ", " .. xp end
    -- one line, cut at the window's edge in the client: what matters first (the range is in the Quests list)
    n.text:SetText(string.format("%s: %s, %s", W.Colorize(L["Dungeon worth a visit"], W.C.teal), L[d.name] or d.name, what))
    showButtons(n, false)
  end
  n:ClearAllPoints()
  n:SetPoint("TOPLEFT", f, "TOPLEFT", 2, top)
  n:SetPoint("RIGHT", f, "RIGHT", 0, 0)
  n:Show()
  return 42
end
