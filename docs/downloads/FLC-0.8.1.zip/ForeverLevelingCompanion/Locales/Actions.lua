-- What to do in an objective step, in the other client languages (the names next to them come from the generated
-- name files, already in the client's language). Only these strings: everything else falls back to English.
-- Spanish lives in esES.lua; esMX uses the Spanish table.
local _, ns = ...

ns:RegisterLocale("deDE", {
  ["Kill: %s"] = "Töten: %s", ["Kill and loot: %s"] = "Töten und plündern: %s", ["Loot the object: %s"] = "Objekt plündern: %s",
  ["Talk to: %s"] = "Sprechen mit: %s", ["Buy from: %s"] = "Kaufen bei: %s",
})
ns:RegisterLocale("frFR", {
  ["Kill: %s"] = "Tuer : %s", ["Kill and loot: %s"] = "Tuer et fouiller : %s", ["Loot the object: %s"] = "Fouiller l'objet : %s",
  ["Talk to: %s"] = "Parler à : %s", ["Buy from: %s"] = "Acheter à : %s",
})
ns:RegisterLocale("itIT", {
  ["Kill: %s"] = "Uccidi: %s", ["Kill and loot: %s"] = "Uccidi e saccheggia: %s", ["Loot the object: %s"] = "Saccheggia l'oggetto: %s",
  ["Talk to: %s"] = "Parla con: %s", ["Buy from: %s"] = "Compra da: %s",
})
ns:RegisterLocale("ptBR", {
  ["Kill: %s"] = "Matar: %s", ["Kill and loot: %s"] = "Matar e saquear: %s", ["Loot the object: %s"] = "Saquear o objeto: %s",
  ["Talk to: %s"] = "Falar com: %s", ["Buy from: %s"] = "Comprar de: %s",
})
ns:RegisterLocale("ruRU", {
  ["Kill: %s"] = "Убить: %s", ["Kill and loot: %s"] = "Убить и обыскать: %s", ["Loot the object: %s"] = "Обыскать объект: %s",
  ["Talk to: %s"] = "Поговорить: %s", ["Buy from: %s"] = "Купить у: %s",
})
ns:RegisterLocale("koKR", {
  ["Kill: %s"] = "처치: %s", ["Kill and loot: %s"] = "처치 후 획득: %s", ["Loot the object: %s"] = "물체에서 획득: %s",
  ["Talk to: %s"] = "대화: %s", ["Buy from: %s"] = "구입: %s",
})
ns:RegisterLocale("zhCN", {
  ["Kill: %s"] = "击杀：%s", ["Kill and loot: %s"] = "击杀并拾取：%s", ["Loot the object: %s"] = "拾取物体：%s",
  ["Talk to: %s"] = "交谈：%s", ["Buy from: %s"] = "购买：%s",
})
ns:RegisterLocale("zhTW", {
  ["Kill: %s"] = "擊殺：%s", ["Kill and loot: %s"] = "擊殺並拾取：%s", ["Loot the object: %s"] = "拾取物件：%s",
  ["Talk to: %s"] = "交談：%s", ["Buy from: %s"] = "購買：%s",
})
