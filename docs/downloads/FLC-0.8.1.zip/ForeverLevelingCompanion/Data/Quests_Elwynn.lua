-- Quest metadata: Northshire Valley / Elwynn Forest (sample coverage).
-- Format: docs/DATA_FORMAT.md.
-- STATUS: unverified. Quest IDs, NPC IDs, levels and coordinates are Classic Era (1.15) reference
-- values written from the author's knowledge. Forever 1.60.1 keeps Era quest IDs for original quests
-- (per QuestieDB's Forever notes) but some zones changed map frames, so every coordinate below must
-- be confirmed in the client (use the data recorder: /flc record on).
local _, ns = ...

local ELWYNN = 1429 -- uiMapID Elwynn Forest (Classic Era)

local SOURCE = "flc-author:classic-era-reference"

ns.Quest:RegisterQuests({
  { id = 783, name = "A Threat Within", level = 1, minLevel = 1, faction = "Alliance",
    start = { map = ELWYNN, x = 48.2, y = 42.0, npc = 823 }, finish = { map = ELWYNN, x = 48.9, y = 41.6, npc = 197 },
    objectives = {} },
  { id = 7, name = "Kobold Camp Cleanup", level = 2, minLevel = 1, faction = "Alliance", prereq = { 783 },
    start = { map = ELWYNN, x = 48.9, y = 41.6, npc = 197 }, finish = { map = ELWYNN, x = 48.9, y = 41.6, npc = 197 },
    area = { map = ELWYNN, x = 47.8, y = 34.5 }, objectives = { { kind = "kill", label = "Kobold Vermin" } } },
  { id = 5261, name = "Eagan Peltskinner", level = 1, minLevel = 1, faction = "Alliance",
    start = { map = ELWYNN, x = 48.2, y = 42.0, npc = 823 }, finish = { map = ELWYNN, x = 48.9, y = 40.2, npc = 196 },
    objectives = {} },
  { id = 33, name = "Wolves Across the Border", level = 2, minLevel = 1, faction = "Alliance", prereq = { 5261 },
    start = { map = ELWYNN, x = 48.9, y = 40.2, npc = 196 }, finish = { map = ELWYNN, x = 48.9, y = 40.2, npc = 196 },
    area = { map = ELWYNN, x = 46.0, y = 38.5 }, objectives = { { kind = "loot", label = "Tough Wolf Meat" } } },
  { id = 18, name = "Brotherhood of Thieves", level = 4, minLevel = 2, faction = "Alliance",
    start = { map = ELWYNN, x = 48.2, y = 42.0, npc = 823 }, finish = { map = ELWYNN, x = 48.2, y = 42.0, npc = 823 },
    area = { map = ELWYNN, x = 54.5, y = 43.0 }, objectives = { { kind = "loot", label = "Red Burlap Bandana" } } },
  { id = 15, name = "Investigate Echo Ridge", level = 3, minLevel = 2, faction = "Alliance", prereq = { 7 },
    start = { map = ELWYNN, x = 48.9, y = 41.6, npc = 197 }, finish = { map = ELWYNN, x = 48.9, y = 41.6, npc = 197 },
    area = { map = ELWYNN, x = 47.5, y = 32.0 }, objectives = { { kind = "kill", label = "Kobold Worker" } } },
  { id = 21, name = "Skirmish at Echo Ridge", level = 5, minLevel = 3, faction = "Alliance", prereq = { 15 },
    start = { map = ELWYNN, x = 48.9, y = 41.6, npc = 197 }, finish = { map = ELWYNN, x = 48.9, y = 41.6, npc = 197 },
    area = { map = ELWYNN, x = 47.0, y = 30.5 }, objectives = { { kind = "kill", label = "Kobold Laborer" } } },
  { id = 6, name = "Bounty on Garrick Padfoot", level = 5, minLevel = 3, faction = "Alliance", prereq = { 18 },
    start = { map = ELWYNN, x = 48.2, y = 42.0, npc = 823 }, finish = { map = ELWYNN, x = 48.2, y = 42.0, npc = 823 },
    area = { map = ELWYNN, x = 57.5, y = 48.2 }, objectives = { { kind = "loot", label = "Garrick's Head" } } },
  { id = 54, name = "Report to Goldshire", level = 5, minLevel = 4, faction = "Alliance", prereq = { 21 },
    start = { map = ELWYNN, x = 48.9, y = 41.6, npc = 197 }, finish = { map = ELWYNN, x = 42.1, y = 65.9, npc = 240 },
    objectives = {}, shareable = false },
  -- Class letters (human starting area). Giver not verified.
  { id = 3100, name = "Simple Letter", level = 1, minLevel = 1, classes = { "WARRIOR" }, races = { "Human" },
    finish = { map = ELWYNN, x = 50.2, y = 42.3, npc = 911 }, objectives = {}, shareable = false },
  { id = 3101, name = "Consecrated Letter", level = 1, minLevel = 1, classes = { "PALADIN" }, races = { "Human" },
    finish = { map = ELWYNN, x = 50.4, y = 42.1, npc = 925 }, objectives = {}, shareable = false },
  { id = 3102, name = "Encrypted Letter", level = 1, minLevel = 1, classes = { "ROGUE" }, races = { "Human" },
    finish = { map = ELWYNN, x = 50.3, y = 39.9, npc = 915 }, objectives = {}, shareable = false },
  { id = 3103, name = "Hallowed Letter", level = 1, minLevel = 1, classes = { "PRIEST" }, races = { "Human" },
    finish = { map = ELWYNN, x = 49.8, y = 39.5, npc = 375 }, objectives = {}, shareable = false },
  { id = 3104, name = "Glyphic Letter", level = 1, minLevel = 1, classes = { "MAGE" }, races = { "Human" },
    finish = { map = ELWYNN, x = 49.7, y = 39.4, npc = 198 }, objectives = {}, shareable = false },
  { id = 3105, name = "Tainted Letter", level = 1, minLevel = 1, classes = { "WARLOCK" }, races = { "Human" },
    finish = { map = ELWYNN, x = 49.9, y = 42.6, npc = 459 }, objectives = {}, shareable = false },
  -- Group content example for Party Mode planning (elite).
  { id = 176, name = "Wanted: \"Hogger\"", level = 11, minLevel = 8, faction = "Alliance", elite = true, groupSize = 3,
    start = { map = ELWYNN, x = 42.1, y = 65.9 }, finish = { map = ELWYNN, x = 42.1, y = 65.9, npc = 240 },
    area = { map = ELWYNN, x = 26.5, y = 89.0 }, objectives = { { kind = "loot", label = "Huge Gnoll Claw" } } },
}, SOURCE)
