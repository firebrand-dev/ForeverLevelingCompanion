-- Dungeon list for Dungeon Focus. Level ranges are approximate recommendations.
-- STATUS: unverified. Classic entries use commonly cited Classic Era ranges; Forever entries come from
-- warcraft.wiki.gg "World of Warcraft: Forever" (fetched 2026-10-23). Map IDs are left out until
-- confirmed in the client.
local _, ns = ...

local ERA = "classic-era-reference"
local WIKI = "warcraft.wiki.gg/wiki/Forever 2026-10-23"
local NEWS = "Blizzard news 'Explore the New Dungeons of World of Warcraft: Forever' 2026-10-20"

ns.Route.RegisterDungeons({
  { id = "rfc", name = "Ragefire Chasm", minLevel = 13, maxLevel = 18, faction = "Horde", source = ERA },
  { id = "thanes", name = "Hall of Thanes", minLevel = 13, maxLevel = 18, source = WIKI, forever = true },
  { id = "lordaeron", name = "Ruins of Lordaeron", minLevel = 15, maxLevel = 22, source = WIKI, forever = true },
  { id = "wc", name = "Wailing Caverns", minLevel = 17, maxLevel = 24, source = ERA },
  { id = "dm", name = "The Deadmines", minLevel = 17, maxLevel = 26, source = ERA },
  { id = "sfk", name = "Shadowfang Keep", minLevel = 22, maxLevel = 30, source = ERA },
  { id = "bfd", name = "Blackfathom Deeps", minLevel = 24, maxLevel = 32, source = ERA },
  { id = "excav", name = "Excavation Site: Wetlands", minLevel = 24, maxLevel = 29, source = NEWS, forever = true },
  { id = "dalaran", name = "City of Dalaran", minLevel = 28, maxLevel = 33, source = NEWS, forever = true },
  { id = "stocks", name = "The Stockade", minLevel = 24, maxLevel = 32, faction = "Alliance", source = ERA },
  { id = "gnomer", name = "Gnomeregan", minLevel = 29, maxLevel = 38, source = ERA },
  { id = "rfk", name = "Razorfen Kraul", minLevel = 29, maxLevel = 38, source = ERA },
  { id = "sm", name = "Scarlet Monastery", minLevel = 34, maxLevel = 45, source = ERA },
  { id = "rfd", name = "Razorfen Downs", minLevel = 37, maxLevel = 46, source = ERA },
  { id = "krold", name = "Krol'dok Stronghold", minLevel = 40, maxLevel = 45, source = WIKI, forever = true },
  { id = "ulda", name = "Uldaman", minLevel = 41, maxLevel = 51, source = ERA },
  { id = "zf", name = "Zul'Farrak", minLevel = 44, maxLevel = 54, source = ERA },
  { id = "mara", name = "Maraudon", minLevel = 46, maxLevel = 55, source = ERA },
  { id = "alcaz", name = "Alcaz Prison", minLevel = 48, maxLevel = 53, source = WIKI, forever = true },
  { id = "st", name = "Sunken Temple", minLevel = 50, maxLevel = 60, source = ERA },
  { id = "brd", name = "Blackrock Depths", minLevel = 52, maxLevel = 60, source = ERA },
  { id = "lbrs", name = "Lower Blackrock Spire", minLevel = 55, maxLevel = 60, source = ERA },
  { id = "dmaul", name = "Dire Maul", minLevel = 55, maxLevel = 60, source = ERA },
  { id = "scholo", name = "Scholomance", minLevel = 58, maxLevel = 60, source = ERA },
  { id = "strat", name = "Stratholme", minLevel = 58, maxLevel = 60, source = ERA },
})
