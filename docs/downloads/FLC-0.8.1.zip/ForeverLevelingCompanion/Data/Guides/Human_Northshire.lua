-- Original FLC sample guide: Northshire Valley, human characters, levels 1-5.
-- Route order and texts are original FLC content. STATUS: unverified on WoW Forever.
-- Step fields: docs/DATA_FORMAT.md.
local _, ns = ...

local M = 1429 -- Elwynn Forest
local WILLEM = { name = "Deputy Willem", id = 823 }
local MCBRIDE = { name = "Marshal McBride", id = 197 }
local EAGAN = { name = "Eagan Peltskinner", id = 196 }

local function at(x, y) return { map = M, x = x, y = y } end

local steps = {
  { id = "ns-001", type = "accept", quest = 783, npc = WILLEM, loc = at(48.2, 42.0) },
  { id = "ns-002", type = "accept", quest = 3100, npc = WILLEM, loc = at(48.2, 42.0), when = { class = "WARRIOR" } },
  { id = "ns-003", type = "accept", quest = 3101, npc = WILLEM, loc = at(48.2, 42.0), when = { class = "PALADIN" } },
  { id = "ns-004", type = "accept", quest = 3102, npc = WILLEM, loc = at(48.2, 42.0), when = { class = "ROGUE" } },
  { id = "ns-005", type = "accept", quest = 3103, npc = WILLEM, loc = at(48.2, 42.0), when = { class = "PRIEST" } },
  { id = "ns-006", type = "accept", quest = 3104, npc = WILLEM, loc = at(48.2, 42.0), when = { class = "MAGE" } },
  { id = "ns-007", type = "accept", quest = 3105, npc = WILLEM, loc = at(48.2, 42.0), when = { class = "WARLOCK" } },
  { id = "ns-008", type = "accept", quest = 5261, npc = WILLEM, loc = at(48.2, 42.0) },
  { id = "ns-009", type = "turnin", quest = 783, npc = MCBRIDE, loc = at(48.9, 41.6) },
  { id = "ns-010", type = "accept", quest = 7, npc = MCBRIDE, loc = at(48.9, 41.6) },
  { id = "ns-011", type = "turnin", quest = 3100, npc = { name = "Llane Beshere" }, loc = at(50.2, 42.3), when = { class = "WARRIOR" } },
  { id = "ns-012", type = "turnin", quest = 3101, npc = { name = "Brother Sammuel" }, loc = at(50.4, 42.1), when = { class = "PALADIN" } },
  { id = "ns-013", type = "turnin", quest = 3102, npc = { name = "Jorik Kerridan" }, loc = at(50.3, 39.9), when = { class = "ROGUE" } },
  { id = "ns-014", type = "turnin", quest = 3103, npc = { name = "Priestess Anetta" }, loc = at(49.8, 39.5), when = { class = "PRIEST" } },
  { id = "ns-015", type = "turnin", quest = 3104, npc = { name = "Khelden Bremen" }, loc = at(49.7, 39.4), when = { class = "MAGE" } },
  { id = "ns-016", type = "turnin", quest = 3105, npc = { name = "Drusilla La Salle" }, loc = at(49.9, 42.6), when = { class = "WARLOCK" } },
  { id = "ns-017", type = "turnin", quest = 5261, npc = EAGAN, loc = at(48.9, 40.2) },
  { id = "ns-018", type = "accept", quest = 33, npc = EAGAN, loc = at(48.9, 40.2) },
  { id = "ns-019", type = "kill", quest = 7, objective = 1, loc = at(47.8, 34.5),
    group = { text = "Split up: one player pulls vermin north, the other south of the camp" } },
  { id = "ns-020", type = "collect", quest = 33, objective = 1, loc = at(46.0, 38.5),
    group = { text = "Each player loots their own wolf meat" } },
  { id = "ns-021", type = "turnin", quest = 7, npc = MCBRIDE, loc = at(48.9, 41.6) },
  { id = "ns-022", type = "accept", quest = 15, npc = MCBRIDE, loc = at(48.9, 41.6) },
  { id = "ns-023", type = "turnin", quest = 33, npc = EAGAN, loc = at(48.9, 40.2) },
  { id = "ns-024", type = "accept", quest = 18, npc = WILLEM, loc = at(48.2, 42.0), requires = { level = 2 } },
  { id = "ns-025", type = "goto", label = "Echo Ridge Mine", loc = at(47.6, 32.4), radius = 25 },
  { id = "ns-026", type = "kill", quest = 15, objective = 1, loc = at(47.5, 32.0) },
  { id = "ns-027", type = "collect", quest = 18, objective = 1, loc = at(54.5, 43.0) },
  { id = "ns-028", type = "turnin", quest = 15, npc = MCBRIDE, loc = at(48.9, 41.6) },
  { id = "ns-029", type = "accept", quest = 21, npc = MCBRIDE, loc = at(48.9, 41.6) },
  { id = "ns-030", type = "turnin", quest = 18, npc = WILLEM, loc = at(48.2, 42.0) },
  { id = "ns-031", type = "accept", quest = 6, npc = WILLEM, loc = at(48.2, 42.0) },
  { id = "ns-032", type = "kill", quest = 21, objective = 1, loc = at(47.0, 30.5),
    difficulty = { solo = "medium", group = "low" } },
  { id = "ns-033", type = "collect", quest = 6, objective = 1, loc = at(57.5, 48.2),
    difficulty = { solo = "medium", group = "low" },
    solo = { text = "Clear the thugs near Garrick before pulling him" },
    group = { text = "Pull Garrick together; only players on the quest get the head" } },
  { id = "ns-034", type = "turnin", quest = 6, npc = WILLEM, loc = at(48.2, 42.0) },
  { id = "ns-035", type = "turnin", quest = 21, npc = MCBRIDE, loc = at(48.9, 41.6) },
  { id = "ns-036", type = "accept", quest = 54, npc = MCBRIDE, loc = at(48.9, 41.6) },
  { id = "ns-037", type = "level", level = 5, optional = true },
  { id = "ns-038", type = "goto", label = "Goldshire", loc = at(42.5, 64.0), radius = 30 },
  { id = "ns-039", type = "turnin", quest = 54, npc = { name = "Marshal Dughan", id = 240 }, loc = at(42.1, 65.9) },
}

ns.Guide:Register({
  id = "flc.human.northshire",
  format = 1,
  version = 1,
  title = "Northshire Valley",
  faction = "Alliance",
  races = { "Human" },
  levelRange = { 1, 6 },
  status = "unverified",
  source = "FLC original route; quest IDs and coordinates from Classic Era reference, pending Forever verification",
  steps = steps,
})
